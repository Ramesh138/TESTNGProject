package stepDefinations;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.gherkin.model.Feature;
import com.aventstack.extentreports.gherkin.model.Scenario;
import com.cucumber.listener.Reporter;
import com.rntbci.base.SeleniumBase;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition extends SeleniumBase {
	ExtentTest logInfo = null;

	
	@BeforeSuite
	public void user_already_on_login_page() throws InterruptedException, ClassNotFoundException {
		System.setProperty("webdriver.chrome.driver", ".//driver//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://trv-app.gke.int.gcp.renault.com/");
		System.out.println(" login");
		Thread.sleep(5000);
		
	}
	@Test
	@When("^title of login page is Travaux$")
	public void title_of_login_page_is_free_CRM() throws Exception {
		Thread.sleep(5000);
		String title = driver.getTitle();
		System.out.println(title);
		Reporter.addStepLog(" tittle conformation "+title);
	}

	@AfterSuite
	public void close_the_browser() {
		driver.quit();
	
	}

}
