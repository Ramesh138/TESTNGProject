package stepDefinations;

import org.testng.annotations.Test;

import com.renault.flows.SitemanagementFlow;
import com.rntbci.base.SeleniumBase;

import cucumber.api.java.en.Given;

public class SitemanagementDefinition extends SeleniumBase {
	
	SitemanagementFlow sf= new SitemanagementFlow();
	
	
	@Test
	@Given("^Click on the sitemanagement submenu tab$")
	public void clickSitemanagemenetsubmenu() throws InterruptedException, ClassNotFoundException {
				sf.click_Sitemanagement_Submenu();
	}

}
