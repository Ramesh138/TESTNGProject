package com.renault.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.rntbci.base.SeleniumBase;

public class AdminPage  extends SeleniumBase{
	
	@FindBy(id = "au_site")
	WebElement btn_au_site;
	
	public AdminPage() {
		PageFactory.initElements(driver, this);
	}

	public WebElement getBtn_au_site() {
		return btn_au_site;
	}

	public void setBtn_au_site(WebElement btn_au_site) {
		this.btn_au_site = btn_au_site;
	}

}
