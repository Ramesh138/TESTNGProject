package com.renault.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.rntbci.base.SeleniumBase;

public class SitemanagementPage extends SeleniumBase {
	
	@FindBy(xpath  = ".//sites/div/h3")
	WebElement lbl_sitepageheader;

	@FindBy(xpath  = ".//sites/div/div[1]/form/label[1]")
	WebElement lbl_status;
	
	@FindBy(xpath  = ".//sites/div/div[1]/form/label[2]")
	WebElement lbl_active;
	
	@FindBy(xpath  = ".//sites/div/div[1]/form/label[3]")
	WebElement lbl_inactive;
	
	@FindBy(xpath  = ".//sites/div/div[1]/form/label[4]")
	WebElement lbl_all;
	
	@FindBy(xpath  = ".//sites/div/div[1]/form/label[4]")
	WebElement lbl_listoftypedata;
	
	@FindBy(xpath  = ".//datatable-header-cell[1]/div/div/div")
	WebElement lbl_gridnameheader;
	
	@FindBy(xpath  = ".//datatable-header-cell[2]/div/div/div")
	WebElement lbl_gridstatusheader;
	
	@FindBy(xpath  = ".//datatable-header-cell[3]/div/div/div")
	WebElement lbl_gridDescriptionheader;
	
	@FindBy(xpath  = ".//datatable-header-cell[4]/div/div/div")
	WebElement lbl_gridOrderheader;
	
	@FindBy(id = "au_active")
	WebElement rb_active;
	
	@FindBy(id = "au_inactive")
	WebElement rb_inactive;
	
	@FindBy(id = "au_all")
	WebElement rb_all;
	
	@FindBy(id = "au_add_btn")
	WebElement btn_add;
	
	@FindBy(id = "au_order_btn")
	WebElement btn_sort;
	
	@FindBy(id = "au_cancel_btn")
	WebElement btn_cacncel;
	
	@FindBy(id = "au_save_bottom")
	WebElement btn_siteadd;
	
	@FindBy(id = "au_cancel_bottom")
	WebElement btn_sitecancel;
	
	@FindBy(xpath = ".//*[@formcontrolname='par_actif']/../span[1]")
	WebElement btn_statusyesorno;
	
	@FindBy(xpath = ".//*[@formcontrolname='par_intitule_Fr']")
	WebElement tbx_NameFr;
	
	@FindBy(xpath = ".//*[@formcontrolname='par_intitule_En']")
	WebElement tbx_NameEn;
	
	@FindBy(xpath = ".//*[@formcontrolname='par_intitule_Es']")
	WebElement tbx_NameEs;
	
	@FindBy(xpath = ".//*[@formcontrolname='par_intitule_Po']")
	WebElement tbx_NamePo;
	
	@FindBy(xpath = ".//*[@formcontrolname='par_intitule_Ro']")
	WebElement tbx_NameRo;
	
	@FindBy(xpath = ".//*[@formcontrolname='par_intitule_Br']")
	WebElement tbx_NameBr;
	
	@FindBy(xpath = ".//*[@formcontrolname='par_intitule_RU']")
	WebElement tbx_NameRu;
	
	@FindBy(xpath = ".//*[@formcontrolname='par_intitule_RU']")
	WebElement tbx_NameTu;
	
	public WebElement getLbl_sitepageheader() {
		return lbl_sitepageheader;
	}

	public void setLbl_sitepageheader(WebElement lbl_sitepageheader) {
		this.lbl_sitepageheader = lbl_sitepageheader;
	}

	public WebElement getLbl_status() {
		return lbl_status;
	}

	public void setLbl_status(WebElement lbl_status) {
		this.lbl_status = lbl_status;
	}

	public WebElement getLbl_active() {
		return lbl_active;
	}

	public void setLbl_active(WebElement lbl_active) {
		this.lbl_active = lbl_active;
	}

	public WebElement getLbl_inactive() {
		return lbl_inactive;
	}

	public void setLbl_inactive(WebElement lbl_inactive) {
		this.lbl_inactive = lbl_inactive;
	}

	public WebElement getLbl_all() {
		return lbl_all;
	}

	public void setLbl_all(WebElement lbl_all) {
		this.lbl_all = lbl_all;
	}

	public WebElement getLbl_listoftypedata() {
		return lbl_listoftypedata;
	}

	public void setLbl_listoftypedata(WebElement lbl_listoftypedata) {
		this.lbl_listoftypedata = lbl_listoftypedata;
	}

	public WebElement getLbl_gridnameheader() {
		return lbl_gridnameheader;
	}

	public void setLbl_gridnameheader(WebElement lbl_gridnameheader) {
		this.lbl_gridnameheader = lbl_gridnameheader;
	}

	public WebElement getLbl_gridstatusheader() {
		return lbl_gridstatusheader;
	}

	public void setLbl_gridstatusheader(WebElement lbl_gridstatusheader) {
		this.lbl_gridstatusheader = lbl_gridstatusheader;
	}

	public WebElement getLbl_gridDescriptionheader() {
		return lbl_gridDescriptionheader;
	}

	public void setLbl_gridDescriptionheader(WebElement lbl_gridDescriptionheader) {
		this.lbl_gridDescriptionheader = lbl_gridDescriptionheader;
	}

	public WebElement getLbl_gridOrderheader() {
		return lbl_gridOrderheader;
	}

	public void setLbl_gridOrderheader(WebElement lbl_gridOrderheader) {
		this.lbl_gridOrderheader = lbl_gridOrderheader;
	}

	public WebElement getRb_active() {
		return rb_active;
	}

	public void setRb_active(WebElement rb_active) {
		this.rb_active = rb_active;
	}

	public WebElement getRb_inactive() {
		return rb_inactive;
	}

	public void setRb_inactive(WebElement rb_inactive) {
		this.rb_inactive = rb_inactive;
	}

	public WebElement getRb_all() {
		return rb_all;
	}

	public void setRb_all(WebElement rb_all) {
		this.rb_all = rb_all;
	}

	public WebElement getBtn_add() {
		return btn_add;
	}

	public void setBtn_add(WebElement btn_add) {
		this.btn_add = btn_add;
	}

	public WebElement getBtn_sort() {
		return btn_sort;
	}

	public void setBtn_sort(WebElement btn_sort) {
		this.btn_sort = btn_sort;
	}

	public WebElement getBtn_cacncel() {
		return btn_cacncel;
	}

	public void setBtn_cacncel(WebElement btn_cacncel) {
		this.btn_cacncel = btn_cacncel;
	}

	public WebElement getBtn_siteadd() {
		return btn_siteadd;
	}

	public void setBtn_siteadd(WebElement btn_siteadd) {
		this.btn_siteadd = btn_siteadd;
	}

	public WebElement getBtn_sitecancel() {
		return btn_sitecancel;
	}

	public void setBtn_sitecancel(WebElement btn_sitecancel) {
		this.btn_sitecancel = btn_sitecancel;
	}

	public WebElement getBtn_statusyesorno() {
		return btn_statusyesorno;
	}

	public void setBtn_statusyesorno(WebElement btn_statusyesorno) {
		this.btn_statusyesorno = btn_statusyesorno;
	}

	public WebElement getTbx_NameFr() {
		return tbx_NameFr;
	}

	public void setTbx_NameFr(WebElement tbx_NameFr) {
		this.tbx_NameFr = tbx_NameFr;
	}

	public WebElement getTbx_NameEn() {
		return tbx_NameEn;
	}

	public void setTbx_NameEn(WebElement tbx_NameEn) {
		this.tbx_NameEn = tbx_NameEn;
	}

	public WebElement getTbx_NameEs() {
		return tbx_NameEs;
	}

	public void setTbx_NameEs(WebElement tbx_NameEs) {
		this.tbx_NameEs = tbx_NameEs;
	}

	public WebElement getTbx_NamePo() {
		return tbx_NamePo;
	}

	public void setTbx_NamePo(WebElement tbx_NamePo) {
		this.tbx_NamePo = tbx_NamePo;
	}

	public WebElement getTbx_NameRo() {
		return tbx_NameRo;
	}

	public void setTbx_NameRo(WebElement tbx_NameRo) {
		this.tbx_NameRo = tbx_NameRo;
	}

	public WebElement getTbx_NameBr() {
		return tbx_NameBr;
	}

	public void setTbx_NameBr(WebElement tbx_NameBr) {
		this.tbx_NameBr = tbx_NameBr;
	}

	public WebElement getTbx_NameRu() {
		return tbx_NameRu;
	}

	public void setTbx_NameRu(WebElement tbx_NameRu) {
		this.tbx_NameRu = tbx_NameRu;
	}

	public WebElement getTbx_NameTu() {
		return tbx_NameTu;
	}

	public void setTbx_NameTu(WebElement tbx_NameTu) {
		this.tbx_NameTu = tbx_NameTu;
	}

	
	
	public SitemanagementPage() {
		PageFactory.initElements(driver, this);
	}
}
