package com.renault.pages;

public class LoginPage {

}
