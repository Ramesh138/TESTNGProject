package com.renault.flows;

public class AdminFlow {

}
