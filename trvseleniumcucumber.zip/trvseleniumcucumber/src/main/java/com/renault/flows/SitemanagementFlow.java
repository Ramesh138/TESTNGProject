package com.renault.flows;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cucumber.listener.Reporter;
import com.renault.pages.AdminPage;
import com.renault.pages.SitemanagementPage;
import com.rntbci.base.SeleniumBase;

public class SitemanagementFlow extends SeleniumBase {
	
	SitemanagementPage sp= new SitemanagementPage();
	
	AdminPage ap= new AdminPage();
	
	public   void click_Sitemanagement_Submenu() {
		
		wait = new WebDriverWait(driver,60);
		
		wait.until(ExpectedConditions.elementToBeClickable(ap.getBtn_au_site()));
		
		ap.getBtn_au_site().click();
		
		Reporter.addStepLog(" click on the site management submenu ");
		
		sp.getBtn_add();
		
		Reporter.addStepLog(" click on the add button ");

	}

}
