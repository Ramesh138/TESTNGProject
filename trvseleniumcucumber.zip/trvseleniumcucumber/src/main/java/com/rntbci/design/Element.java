package com.rntbci.design;

import org.openqa.selenium.WebElement;

public interface Element {
	
	public void click(WebElement ele);
	
	//public void clear(WebElement ele);
	public void keyInValue(WebElement ele, String data);
	
	public void clearAndType(WebElement ele, String data);
	
	public void selectDropDownUsingText(WebElement ele, String text);
	
	public void moveAndClick(WebElement ele);
	
	public String getElementText(WebElement ele);
	
	public boolean verifyExactText(WebElement ele, String text);
	
	public boolean verifyPartialText(WebElement ele, String text);
	
	//public void selectDropDownUsingIndex(String WebElement, int index);
	
	//public void selectDropDownUsingValue(String WebElement, String value);
	
	
	
	
	

}
