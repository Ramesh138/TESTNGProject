package com.rntbci.design;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.ITestResult;

public interface Browser {
	
	public void startApp(String url);
	
	public void switchToParentWindow();
	
	public void switchToWindow(int index);
	
	//public void switchToWindow(String title);
	
	public void switchToFrame(int index);
	
	public void defaultContent();
	
	public void close();
	
	public void quit();


}
