package com.rntbci.base;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rntbci.design.Browser;
import com.rntbci.design.Element;


public class SeleniumBase  implements Browser, Element {
	public static WebDriver driver;
	public static WebDriverWait wait;
	public static Actions builder;
	public static JavascriptExecutor js;
	
	

	public void click(WebElement ele) {
		String text = "";
		try {
			wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(ele));
			text = ele.getText();
			System.out.println(text);
			ele.click();
		} catch (StaleElementReferenceException e) {
			throw new RuntimeException();
		}

	}

	public void moveAndClick(WebElement ele) {
		try {
			builder = new Actions(driver);
			wait = new WebDriverWait(driver, 40);
			wait.until(ExpectedConditions.elementToBeClickable(ele));
			String text = ele.getText();
			System.out.println(text);
			builder.moveToElement(ele).click(ele).perform();
		} catch (StaleElementReferenceException e) {
			throw new RuntimeException();
		}

	}

	public void keyInValue(WebElement ele, String data) {
		try {
			ele.sendKeys(data);
		} catch (ElementNotInteractableException e) {
			throw new RuntimeException();
		}

	}

	public void clearAndType(WebElement ele, String data) {
		try {
			ele.clear();
			ele.sendKeys(data);
		} catch (ElementNotInteractableException e) {
			throw new RuntimeException();
		}

	}

	public void selectDropDownUsingText(WebElement ele, String text) {
		new Select(ele).selectByVisibleText(text);

	}

	public void selectDropDownUsingIndex(WebElement ele, int index) {
		try {
			new Select(ele).selectByIndex(index);
			//reportStep("The dropdown is selected with index "+index,"PASS");
		} catch (WebDriverException e) {
			//reportStep("The element: "+ele+" could not be found.", "FAIL");
		} 
	}
	
	public void selectDropDownUsingValue(WebElement ele, String value) {
		new Select(ele).selectByValue(value);

	}

	public void selectAutoSuggestUsingText(List<WebElement> list, String text) {
		try {
			wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions
					.visibilityOfAllElementsLocatedBy((By.xpath("(//div[@class='autopopulate']//li)"))));
			System.out.println("Auto Suggest List ::" + list.size());

			for (int i = 0; i < list.size(); i++) {
				System.out.println(list.get(i).getText());

				if (list.get(i).getText().equals(text)) {
					list.get(i).click();
					break;
				}
			}
		} catch (Exception e) {
			throw new RuntimeException();
		}
	}

	public void startApp(String url) {
		try {
			System.setProperty("webdriver.chrome.silentOutput", "true");
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
			//startReport();
			/*
			 * System.setProperty("http.proxyHost", "10.244.3.249");
			 * System.setProperty("http.proxyPort", "3128");
			 * System.setProperty("http.proxyUser", "z028484");
			 * System.setProperty("http.proxyPassword", "Dinesh87");
			 */

			/*
			 * ChromeOptions options = new ChromeOptions();
			 * 
			 * Proxy proxy = new Proxy(); proxy.setHttpProxy("10.244.3.251:3128");
			 * proxy.setSocksUsername("z028484"); proxy.setSocksPassword("Dinesh87");
			 * options.setCapability("proxy", proxy); driver = new ChromeDriver(options);
			 */
			driver = new ChromeDriver();
			// driver.navigate().to(url);
			// Runtime.getRuntime().exec("C:/Users/z028484/OneDrive - Alliance/GDV/AutoIT
			// script/AuthenticationPopup.exe");
			driver.get(url);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			//reportStep("The browser: Chrome launched successfully", "PASS");

		} catch (WebDriverException e) {			
			//reportStep("The browser: Chrome could not be launched", "FAIL");
			System.out.println("failed");
		}
	}

	

	public void switchToParentWindow() {
		String windowHandle = driver.getWindowHandle();
		driver.switchTo().window(windowHandle);
	}

	public void switchToWindow(int index) {
		try {
			Set<String> allWindows = driver.getWindowHandles();
			List<String> allHandles = new ArrayList<String>(allWindows);
			String exWindow = allHandles.get(index);
			driver.switchTo().window(exWindow);
			System.out.println("The Window with index: " + index + "switched successfully");
		} catch (NoSuchWindowException e) {
			System.err.println("The Window with index: " + index + "not found");
		}

	}

	public void switchToWindow(String title) {
		try {
			Set<String> allWindows = driver.getWindowHandles();
			for (String eachWindow : allWindows) {
				driver.switchTo().window(eachWindow);
				if (driver.getTitle().equals(title)) {
					break;
				}
			}
			System.out.println("The Window with title: " + title + "switched successfully");
		} catch (NoSuchWindowException e) {
			System.err.println("The Window with title: " + title + "not found");
		}

	}

	public void switchToFrame(int index) {
		driver.switchTo().frame(index);
	}

	public void defaultContent() {
		driver.switchTo().defaultContent();
	}
	
	public String getElementText(WebElement ele) {
		String bReturn = "";
		try {
			bReturn = ele.getText();
			System.out.println(bReturn);
		} catch (WebDriverException e) {
			//reportStep("The element: "+ele+" could not be found.", "FAIL");
			System.out.println("The element: "+ele+" could not be found.");
		}
		return bReturn;	
	}

	public boolean verifyExactText(WebElement ele, String expectedText) {
		try {
			if(getElementText(ele).equals(expectedText)) {
				//reportStep("The text: "+getElementText(ele)+" matches with the value :"+expectedText,"PASS");
				System.out.println("The text: "+getElementText(ele)+" matches with the value :"+expectedText);
			}else {
				//reportStep("The text "+getElementText(ele)+" doesn't matches the actual "+expectedText,"FAIL");
				System.out.println("The text "+getElementText(ele)+" doesn't matches the actual "+expectedText);
			}
		} catch (WebDriverException e) {
			System.out.println("Unknown exception occured while verifying the Text");
		} 
		return false;
	}
	
	public boolean verifyPartialText(WebElement ele, String expectedText) {
		try {
			if (ele.getText().contains(expectedText)) {
				System.out.println("The expected text contains the actual " + expectedText);
				return true;
			} else {
				System.out.println("The expected text does not contain the actual " + expectedText);
			}
		} catch (WebDriverException e) {
			System.out.println("Unknown exception occurred while verifying the text");
		}
		return false;
	}

	public void close() {
		driver.close();

	}

	public void quit() {
		driver.quit();

	}

	
	public long takeSnap() {
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L; 
		try {
			FileUtils.copyFile(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE) , new File("./reports/images/"+number+".png"));
		} catch (WebDriverException e) {
			System.out.println("The browser has been closed.");
		} catch (IOException e) {
			System.out.println("The snapshot could not be taken");
		}
		return number;
	}

}
