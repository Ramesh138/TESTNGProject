$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("login.feature");
formatter.feature({
  "line": 1,
  "name": "Travaux Login Feature",
  "description": "",
  "id": "travaux-login-feature",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Travaux  Login Test Scenario",
  "description": "",
  "id": "travaux-login-feature;travaux--login-test-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "title of login page is Travaux",
  "keyword": "When "
});
formatter.match({
  "location": "LoginStepDefinition.title_of_login_page_is_free_CRM()"
});
formatter.result({
  "duration": 5108556900,
  "error_message": "java.lang.NullPointerException\r\n\tat stepDefinations.LoginStepDefinition.title_of_login_page_is_free_CRM(LoginStepDefinition.java:43)\r\n\tat ✽.When title of login page is Travaux(login.feature:5)\r\n",
  "status": "failed"
});
formatter.uri("sitemanagement.feature");
formatter.feature({
  "line": 1,
  "name": "Sitemanagemenet page validations",
  "description": "",
  "id": "sitemanagemenet-page-validations",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Free CRM Login Test Scenario",
  "description": "",
  "id": "sitemanagemenet-page-validations;free-crm-login-test-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "Click on the sitemanagement submenu tab",
  "keyword": "Given "
});
formatter.match({
  "location": "SitemanagementDefinition.clickSitemanagemenetsubmenu()"
});
formatter.result({
  "duration": 54553801,
  "error_message": "java.lang.IllegalArgumentException: Input must be set\r\n\tat org.openqa.selenium.internal.Require.nonNull(Require.java:51)\r\n\tat org.openqa.selenium.support.ui.FluentWait.\u003cinit\u003e(FluentWait.java:100)\r\n\tat org.openqa.selenium.support.ui.WebDriverWait.\u003cinit\u003e(WebDriverWait.java:128)\r\n\tat org.openqa.selenium.support.ui.WebDriverWait.\u003cinit\u003e(WebDriverWait.java:61)\r\n\tat org.openqa.selenium.support.ui.WebDriverWait.\u003cinit\u003e(WebDriverWait.java:48)\r\n\tat com.renault.flows.SitemanagementFlow.click_Sitemanagement_Submenu(SitemanagementFlow.java:20)\r\n\tat stepDefinations.SitemanagementDefinition.clickSitemanagemenetsubmenu(SitemanagementDefinition.java:18)\r\n\tat ✽.Given Click on the sitemanagement submenu tab(sitemanagement.feature:6)\r\n",
  "status": "failed"
});
});