package com.stta.SuiteOne;

import com.stta.TestSuiteBase.SuiteBase;

//SuiteOneBase Class Inherits From SuiteBase Class.
//So, SuiteOneBase Class Is Child Class Of SuiteBase Class.
public class SuiteOneBase extends SuiteBase{	
	
}
