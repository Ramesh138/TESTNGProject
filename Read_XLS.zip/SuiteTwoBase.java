package com.stta.SuiteTwo;

import com.stta.TestSuiteBase.SuiteBase;

//SuiteTwoBase Class Inherits From SuiteBase Class.
//So, SuiteTwoBase Class Is Child Class Of SuiteBase Class.
public class SuiteTwoBase extends SuiteBase{	
	
}
