import framework from './Framework'
import jsonutils from './JsonUtils'
import { Smartservice } from './Smartservice'
import { Constants } from './Constants';

var fw = new framework();
var ju = new jsonutils();
var ss = new Smartservice();

export default class Report {

    private isPassed: boolean = true
    private stepNo: number = 0

    executionStartTime: any
    suiteStartTime: any

    executableModules: any

    private failedOnlyScreenshot: boolean = false
    private needSmarTestReport: boolean = true
    private showOldIterations: boolean = false
    private reportFailureInJira: boolean = false

    constructor(config: any) {
        this.failedOnlyScreenshot = config.FailedOnlyScreenshot
        this.needSmarTestReport = config.SmarTestReport
        this.showOldIterations = config.OldIterations
        this.reportFailureInJira = config.ReportFailureInJIRA
    }


    jasmineStarted(jasmine: any) {
        if (this.needSmarTestReport) {
            var isReprotAvailableBefore = fw.reportCofiguration()
            var itrNo = 0
            if (isReprotAvailableBefore) {
                itrNo = fw.getPrevItrNo();
                if (this.showOldIterations)
                    fw.backUp(itrNo)
                fw.cleanCurrentFolder()
            }
            fw.createAndUpdateBasicContentJson(itrNo + 1)
            this.executionStartTime = new Date()
            fw.updateExecutionStartTime(new Date(Date.now()).toLocaleString())
        }
    }

    suiteStarted(suite: any) {
        fw.setCurrentRunDetails(suite.description.trim())
        if (this.needSmarTestReport) {
            this.suiteStartTime = new Date();
            fw.createTestCaseDirectory()
        }
    }

    specStarted(spec: any) {
        if (this.needSmarTestReport)
            this.stepNo = this.stepNo + 1
    }

    specDone(spec: any) {
        if (this.needSmarTestReport) {
            var stepStatus = spec.status
            var expNo = 1;

            if (stepStatus == 'passed')
                fw.updatePass(spec.description.trim(), this.stepNo, this.failedOnlyScreenshot)
            else {
                var exception = spec.failedExpectations[0].message
                updateLog("Failure : " + exception)
                fw.updateFail(spec.description.trim(), this.stepNo, exception)
                if(this.reportFailureInJira){
                    var obj = ju.readJsonFile(Constants.projectConfigJsonFile).JIRA
                    ss.reportBugInJira(obj.UserID, obj.Password, obj.ProjectKey, spec.description.trim(), "Medium", exception)
                }
                
                this.isPassed = false
            }
        }
    }

    suiteDone(suite: any) {
        if (this.needSmarTestReport) {
            let suiteEndTime: any = new Date()
            let totalSuiteTime = (suiteEndTime - this.suiteStartTime) / 1000;
            var tcStatus;

            if (this.isPassed)
                tcStatus = " Pass"
            else
                tcStatus = " Fail"

            this.stepNo = 0;
            this.isPassed = true;
            fw.updateTestCaseSummaryIntoContentJSON(this.suiteStartTime, totalSuiteTime, suite.description.trim(), tcStatus)
        }

    }

    jasmineDone() {
        if (this.needSmarTestReport) {
            let executionEndTime: any = new Date();
            let totalExecutionTime = (executionEndTime - this.executionStartTime) / 1000;
            var exTime = fw.getFormatedExecutionTime(totalExecutionTime)
            var project = fw.updateExecutionEndTime(new Date(Date.now()).toLocaleString(), exTime)
        }

    }
}

export function updateLog(str: string) {
    fw.updateLog(str)
}
