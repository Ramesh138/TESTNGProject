import * as fs from 'fs'
import folder from './Folderutils'
import jsonutils from './JsonUtils'
import { Constants } from './Constants'

var copydir = require('copy-dir');

var fl = new folder()
var ju = new jsonutils()
var XLSX = require('xlsx');

export default class Frameworkutils {

    cleanScreenshotsDir() {
        var dir: string = Constants.screenShotPath
        if (!fs.existsSync(dir)) {
            fl.createDir(dir)
        } else {
            fl.deleteFolderRecursive(dir)
            fl.createDir(dir)
        }
    }


    splitTCId(str: string): string {
        return str.split(":")[0].trim()
    }

    splitTCDescription(str: string): string {
        return str.split(":")[1].trim()
    }

    replaceSpaceByUnderScore(str: string): string {
        return str.replace(/ /g, "_")
    }


    modName: any;

    getModuleOf(tcId: string): string {
        var runlist = Constants.testCaseListByModule
        for (const run of runlist) {
            var mod = run.split("|");
            if (tcId === mod[1]) {
                this.modName = mod[0]
                break
            }
        }
        return this.modName
    }

    updateTestCaseObject(stepsObj: any, tcID: string, tcDesc: string, sTime: any, exTime: any, status: any): any {
        var testCaseObj = ju.readJsonFile(Constants.testCaseJsonTemplate)
        testCaseObj.Steps = stepsObj
        testCaseObj.ExecutionTime = exTime
        testCaseObj.TestDescription = tcDesc
        testCaseObj.EndTime = new Date()
        testCaseObj.TestScenario = tcDesc
        testCaseObj.StartTime = sTime
        testCaseObj.TestCaseName = tcID
        testCaseObj.TestCaseStatus = status
        return testCaseObj
    }

    updateModuleObjectForPass(tcArr: any, mod: any, startTime: any) {
        var moduleObj = ju.readJsonFile(Constants.moduleJsonTemplate)

        moduleObj.ExecutionTime = "execution time"
        moduleObj.EndTime = "endTime"
        moduleObj.ModuleDescription = mod
        moduleObj.ModuleName = mod
        moduleObj.TotalTestCase = 1
        moduleObj.TestCases = tcArr
        moduleObj.StartTime = startTime
        moduleObj.PassedTestcases = 1
        moduleObj.FailedTestcases = 0
        moduleObj.SkippedTestcases = 0
        moduleObj.NoRunTestcases = 0

        return moduleObj
    }

    updateModuleObjectForFail(tcArr: any, mod: any, startTime: any) {

        var moduleObj = ju.readJsonFile(Constants.moduleJsonTemplate)

        moduleObj.ExecutionTime = "execution time"
        moduleObj.EndTime = "endTime"
        moduleObj.ModuleDescription = mod
        moduleObj.ModuleName = mod
        moduleObj.TotalTestCase = 1
        moduleObj.TestCases = tcArr
        moduleObj.StartTime = startTime
        moduleObj.PassedTestcases = 0
        moduleObj.FailedTestcases = 1
        moduleObj.SkippedTestcases = 0
        moduleObj.NoRunTestcases = 0

        return moduleObj
    }

}