import jsonutils from './JsonUtils'
import configutils from './Configurationutils'
import { Constants } from './Constants';

var ju = new jsonutils()
var cu = new configutils()

class Testrunner {
    public executableModules: any = []
}

var tc = new Testrunner()

export function setUp() {
    var allModules = cu.createTestSuiteJson()
    tc.executableModules = cu.getExecutableModules(allModules)
    cu.updateExecutableModulesInConfiguration(tc.executableModules)

    var pcObj = ju.readJsonFile(Constants.projectConfigJsonFile)
    if (pcObj.DataInputType === 'excel')
        cu.convertExcelTestDataToJSON(tc.executableModules)
    else if (pcObj.DataInputType === 'json')
        Constants.inputType = 'json'

    cu.createTestCaseListByModule(tc.executableModules)
}

export function getBrowser(): string {
    return cu.browserToExecute()
}

export function getCapabilities(): any {
    return cu.getCapability()
}

export function executableTcs(): string[] {
    return cu.getExecutableTestCasesFromExecutableModules(tc.executableModules)
}