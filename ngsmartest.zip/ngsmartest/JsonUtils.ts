import * as fs from 'fs'
var copydir = require('copy-dir');
var jsonfile = require('jsonfile')

export default class Jsonutils {
    /**
     * This function is to read the json file in a syncronous way and it returns the json object
     * @param {!string} filePath Filepath to read
     *
     * @returns {!any} will return the json object
     */
    readJsonFile(filePath: string): any {
        return JSON.parse(fs.readFileSync(filePath).toString())
    }

    /**
     * This function is to write the json file in a syncronous way
     * @param {!string} filePath Filepath to write
     *
     * @param {!object} jsonObject JSONObject to write
     *
     */
    writeJson(path: string, obj: any) {
        jsonfile.writeFileSync(path, obj)
    }

}