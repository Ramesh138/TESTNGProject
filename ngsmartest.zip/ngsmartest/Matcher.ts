import { __ } from 'lodash/fp'
import { updateLog } from './Report';

export class Matcher {

    private actual: any

    constructor(actual: any) {
        this.actual = actual
    }

    public isEqualTo(expected: any, label: string = 'unnamed') {
        if (__.isEqual(this.actual, expected))
            updateLog("For " + label + ", '" + this.actual + "' is matching as expected")
        else
            throw "For " + label + ", expected is '" + expected + "' but found is '" + this.actual + "'"
    }

    public isString(label: string = 'unnamed') {
        if (__.isString(this.actual))
            updateLog("'" + label + "' is a string as expected")
        else
            throw "'" + label + "' is not a string as expected"
    }

    public isUndefined(label: string = 'unnamed') {
        if (__.isUndefined(this.actual))
            updateLog("'" + label + "' is undefined as expected")
        else
            throw "'" + label + "' is not undefined as expected"
    }

    public isObject(label: string = 'unnamed') {
        if (__.isObject(this.actual))
            updateLog("'" + label + "' is object as expected")
        else
            throw "'" + label + "' is not object as expected"
    }

    public isArray(label: string = 'unnamed') {
        if (__.isArray(this.actual))
            updateLog("'" + label + "' is an array as expected")
        else
            throw "'" + label + "' is not an array as expected"
    }

    public isInteger(label: string = 'unnamed') {
        if (__.isInteger(this.actual))
            updateLog("'" + label + "' is integer as expected")
        else
            throw "'" + label + "' is not integer as expected"
    }
}

