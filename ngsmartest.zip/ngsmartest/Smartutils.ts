import { browser, ExpectedConditions, ElementFinder } from 'protractor'

export function waitForVisibilityOf(locator:ElementFinder) {
    browser.wait(ExpectedConditions.visibilityOf(locator), 30000)
}

export function waitForPresenceOf(locator:ElementFinder) {
    browser.wait(ExpectedConditions.presenceOf(locator), 30000)
}

export function waitForInvisibilityOf(locator:ElementFinder) {
    browser.wait(ExpectedConditions.invisibilityOf(locator), 30000)
}

export function waitForStalenessOf(locator:ElementFinder) {
    browser.wait(ExpectedConditions.stalenessOf(locator), 30000)
}

export function waitForElementToBeClickable(locator:ElementFinder) {
    browser.wait(ExpectedConditions.elementToBeClickable(locator), 30000)
}

export function waitForTitleIs(title:string) {
    browser.wait(ExpectedConditions.titleIs(title), 30000)
}

export function switchToFrameFromDefault(element:ElementFinder) {
    browser.switchTo().defaultContent();
    browser.switchTo().frame(element)
}

export function switchToFrame(element:ElementFinder) {
    browser.switchTo().frame(element)
}

export function switchToDefault(element:ElementFinder) {
    browser.switchTo().defaultContent()
}

export function switchToWindow(windowTitle: string) {
}

