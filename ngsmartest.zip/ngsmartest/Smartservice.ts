//import * as rest from 'rest'
var rest = require('rest')
import request from 'request'
import framework from './Framework'
var fw = new framework()

export class Smartservice {

  constructor() { }
  public async getResponse(url: string) {
    const response = await rest(url)
    const data = await response.entity
    return JSON.parse(data).Result
  }


  public reportBugInJira(userid:string, password:string, projectKey:string, summary:string, priority:string, errorMsg:string){
    request({
      method: 'POST',
      auth: {
          'user': userid,
          'pass': password,
          'sendImmediately': true
      },
      rejectUnauthorized: false,
      strictSSL: false,
      uri: "https://jira.intra.renault.fr/rest/api/2/issue",
      json: true,
      headers: [
          { 'Content-Type': 'application/json' },
          { 'Accept': 'application/json' }
      ],
      body: {
          "fields": {

              "project": {
                  "key": projectKey
              },
              "summary": summary,
              "issuetype": {
                  "id": "10004",
                  "name": "Bug",
                  "subtask": false
              },
              "assignee": {
                  "name": userid
              },
              "reporter": {
                  "name": userid
              },
              "priority": {
                  "name": priority
              },
              "labels": [
              ],
              "timetracking": {
              },

              "versions": [],
              "environment": "",
              "description": errorMsg,
              "duedate": null,
              "fixVersions": [

              ],
              "components": [

              ]
          }
      }
  }, function (err:any, res:any, body:any) {
      if (err) {
          console.log(err);
      } else {
          console.log(body);
      }
  });



  }

}
