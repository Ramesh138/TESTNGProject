import { browser, protractor, ElementFinder, ElementArrayFinder, element, By, Browser } from 'protractor'
import { updateLog } from './Report'
import { isUndefined } from 'util'

export class Wrappers {


    public async sendKeys(locator: ElementFinder, value: string, log: string) {
        await locator.sendKeys(value)
        if (!isUndefined(log))
            updateLog(log)
    }

    public async clearSend(locator: ElementFinder, value: string, log: string) {
        await locator.clear()
        await locator.sendKeys(value)
        if (!isUndefined(log))
            updateLog(log)
    }

    public async click(locator: ElementFinder, log: string) {
        await locator.click()
        if (!isUndefined(log))
            updateLog(log)
    }

    public async enter() {
        await browser.actions().sendKeys(protractor.Key.ENTER).perform()
            .then(() => {
                updateLog("Enter action performed")
            })
    }

    public async selectByIndex(elements: ElementArrayFinder, index: number, log: string) {
        var count: number = await elements.count()
        if (index > count) {
            throw ("Index Out of bound Exception: Count is " + count + " but index is " + index)
        } else {
            await elements.get(index).click()
            if (!isUndefined(log))
                updateLog(log)
        }
    }

    public async selectByRandomValue(elements: ElementArrayFinder, log: string) {
        var count: number = await elements.count()
        if (count == 1) {
            await elements.get(0).click()
            if (!isUndefined(log))
                updateLog(log)
        } else {
            var rNo: number = Math.floor((Math.random() * (count - 1)) + 1);
            await elements.get(rNo).click()
            if (!isUndefined(log))
                updateLog(log)
        }
    }

    public clickOnMatchingText(elements: ElementArrayFinder, textToClick: string, log: string) {
        elements.filter((elem, index) => {
            return elem.getText().then((text) => {
                return text.trim() === textToClick.trim();
            });
        }).first().click().then(() => {
            if (!isUndefined(log))
                updateLog(log)
        })

    }

    public dragTo(sourcElement: ElementFinder, destElement: ElementFinder) {
        browser.actions().
            mouseDown(sourcElement).
            mouseMove(destElement).
            mouseUp().perform();
    }

    public dragToOfset(element: ElementFinder, xOfset: number, yOfset: number) {
        browser.actions().
            mouseMove(element).
            mouseMove({ x: xOfset, y: yOfset }).
            doubleClick().
            perform();
    }

}