export class Constants {
        static absolutePath: string = ""
        static reportsFolder: string = systemPath() + '/Reports'
        static inputType: string = ""
        static reportTemplate: string = systemPath() + '/ngsmartest/Reports'
        static contentJsonFile: string = systemPath() + '/Reports/Current/content.json'
        static currentFolderPath: string = systemPath() + '/Reports/Current'
        static previousItrnPath: string = systemPath() + '/Reports/PreviousRun/Iteration-'
        static tempFolderPath: string = systemPath() + '/Reports/PreviousRun/Current'
        static projectConfigJsonFile: string = systemPath() + '/config/config.json'
        static testSuiteJsonPath: string = systemPath() + '/input/json'
        static testSuiteExcelFile: string = systemPath() + '/input/Testsuite.xlsx'
        static testDataPath: string = systemPath() + '/data'
        static convertedTestDataJsonPath: string = systemPath() + '/data/json'
        static screenShotPath: string = systemPath() + '/Reports/Current/Screenshots'
        static contentJsonTemplate: string = systemPath() + '/ngsmartest/templates/content.json'
        static stepJsonTemplate: string = systemPath() + '/ngsmartest/templates/step.json'
        static testCaseJsonTemplate: string = systemPath() + '/ngsmartest/templates/testcase.json'
        static moduleJsonTemplate: string = systemPath() + '/ngsmartest/templates/module.json'
        static executableModulesList: string[] = []
        static testCaseListByModule: string[] = []
        static currentRunDetails: any = {
                testCaseID: "",
                moduleName: ""
        }
}

export function systemPath(): string {
        return process.cwd().split("\\bin")[0].trim()
}