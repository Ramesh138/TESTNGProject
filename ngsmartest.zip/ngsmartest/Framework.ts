import * as fs from 'fs'
import { browser } from 'protractor';
import folder from './Folderutils'
import frameworkutils from './Frameworkutils'
import jsonutils from './JsonUtils'
import { Constants } from './Constants'

var copydir = require('copy-dir');


var fl = new folder();
var fu = new frameworkutils();
var ju = new jsonutils();

export default class Framework {

    private allStepObj: any[] = []
    private stepLogs: string[] = [];
    private logStartWith: number = 1
    constructor() { }

    getTestDataJson(): any {
        if (Constants.inputType === 'json') {
            var filePath:string = Constants.testDataPath + "/" + this.getCurrentModule() + "/" + this.getCurrentTCName() + ".json"
            return ju.readJsonFile(filePath)
        } else {
            var filePath:string = Constants.convertedTestDataJsonPath + "/" + this.getCurrentModule() + "/" + this.getCurrentTCName() + ".json"
            return ju.readJsonFile(filePath).Testdata[0]
        }

    }

    setCurrentRunDetails(suiteDescription: string) {
        var tcID:string = fu.splitTCId(suiteDescription);
        this.setCurrentTCName(tcID)
        var mod:string = fu.getModuleOf(tcID)
        this.setCurrentModule(mod)
    }

    setCurrentTCName(tcName: string) {
        Constants.currentRunDetails.testCaseID = tcName;
    }

    getCurrentTCName(): string {
        return Constants.currentRunDetails.testCaseID
    }

    setCurrentModule(mName: string) {
        Constants.currentRunDetails.moduleName = mName
    }

    getCurrentModule(): string {
        return Constants.currentRunDetails.moduleName
    }

    updateExecutionStartTime(startTime: any) {
        var content = ju.readJsonFile(Constants.contentJsonFile)
        content.Project[7].TagName = startTime
        ju.writeJson(Constants.contentJsonFile, content)
    }

    updateExecutionEndTime(endTime: any, totalExecutionTime: any) {
        var content = ju.readJsonFile(Constants.contentJsonFile)
        content.Project[8].TagName = endTime
        content.Project[9].TagName = totalExecutionTime
        ju.writeJson(Constants.contentJsonFile, content)
    }

    createTestCaseDirectory() {
        var tcDir:string = Constants.screenShotPath + "/" + Constants.currentRunDetails.testCaseID;
        if (!fs.existsSync(tcDir)) {
            fs.mkdirSync(tcDir);
        }
    }

    updateLog(log: string) {
        this.stepLogs.push(this.logStartWith + "." + log)
        this.logStartWith = this.logStartWith + 1
    }

    getPrjectUrl(): string {
        var objProjectConfig = ju.readJsonFile(Constants.projectConfigJsonFile)
        var url = objProjectConfig.Url
        return url;
    }

    deleteLogs() {
        var istrue = true;
        while (istrue) {
            for (var i = 0; i < this.stepLogs.length; i++) {
                this.stepLogs.pop()
            }

            if (this.stepLogs.length == 1) {
                delete this.stepLogs[0]
                this.stepLogs = []
            }

            if (this.stepLogs.length < 1) {
                istrue = false
            }
        }
    }

    deleteStepObj() {
        var istrue = true;
        while (istrue) {
            for (var i = 0; i < this.allStepObj.length; i++) {
                this.allStepObj.pop()
            }

            if (this.allStepObj.length == 1) {
                delete this.allStepObj[0]
                this.allStepObj = []
            }

            if (this.allStepObj.length < 1) {
                istrue = false
            }
        }
    }

    updatePass(sName: string, sNo: number, failedOnlyScreenshot: boolean) {
        var _sName:string = fu.replaceSpaceByUnderScore(sName)
        var screenPath = 'Screenshots/' + this.getCurrentTCName() + '/' + _sName + ".jpg"

        if (!failedOnlyScreenshot)
            this.takeSnap(_sName, this.getCurrentTCName())

        var stepObj = ju.readJsonFile(Constants.stepJsonTemplate)

        stepObj.stepName = "step" + sNo
        stepObj.exception = "No Exception"
        stepObj.status = "Pass"
        stepObj.screenShot = screenPath
        stepObj.description = sName
        stepObj.logs = JSON.parse(JSON.stringify(this.stepLogs))

        this.allStepObj.push(stepObj)
        this.deleteLogs();
        this.logStartWith = 1;

    }

    updateFail(sName: string, sNo: number, exception: any) {
        var _sName:string = fu.replaceSpaceByUnderScore(sName)
        var screenPath = 'Screenshots/' + this.getCurrentTCName() + '/' + _sName + ".jpg"
        this.takeSnap(_sName, this.getCurrentTCName())

        var stepObj = ju.readJsonFile(Constants.stepJsonTemplate)

        stepObj.stepName = "step" + sNo
        stepObj.exception = exception
        stepObj.status = "Fail"
        stepObj.screenShot = screenPath
        stepObj.description = sName
        stepObj.logs = JSON.parse(JSON.stringify(this.stepLogs))

        this.allStepObj.push(stepObj)

        this.deleteLogs();
        this.logStartWith = 1;
    }


    takeSnap(fileName: string, cTC: string) {
        browser.takeScreenshot().then((img:any)=> {
            var stream = fs.createWriteStream(Constants.screenShotPath + "/" + cTC + "/" + fileName + ".jpg");
            stream.write(new Buffer(img, 'base64'));
            stream.end();
        });
    }

    updateTotalPassCount(contentJsonObject: any) {
        contentJsonObject.ProjectStatus[0].TotalTestcases = contentJsonObject.ProjectStatus[0].TotalTestcases + 1
        contentJsonObject.ProjectStatus[0].TotalPassedCount = contentJsonObject.ProjectStatus[0].TotalPassedCount + 1
    }

    updateTotalFailCount(contentJsonObject: any) {
        contentJsonObject.ProjectStatus[0].TotalTestcases = contentJsonObject.ProjectStatus[0].TotalTestcases + 1
        contentJsonObject.ProjectStatus[0].TotalFailedCount = contentJsonObject.ProjectStatus[0].TotalFailedCount + 1
    }

    updateTotalPassCountWithModule(contentJsonObject: any, moduleIndex: number) {
        contentJsonObject.ProjectStatus[0].TotalTestcases = contentJsonObject.ProjectStatus[0].TotalTestcases + 1
        contentJsonObject.ProjectStatus[0].TotalPassedCount = contentJsonObject.ProjectStatus[0].TotalPassedCount + 1
        contentJsonObject.Modules[moduleIndex].TotalTestCase = contentJsonObject.Modules[moduleIndex].TotalTestCase + 1
        contentJsonObject.Modules[moduleIndex].PassedTestcases = contentJsonObject.Modules[moduleIndex].PassedTestcases + 1
    }

    updateTotalFailCountWithModule(contentJsonObject: any, moduleIndex: number) {
        contentJsonObject.ProjectStatus[0].TotalTestcases = contentJsonObject.ProjectStatus[0].TotalTestcases + 1
        contentJsonObject.ProjectStatus[0].TotalFailedCount = contentJsonObject.ProjectStatus[0].TotalFailedCount + 1
        contentJsonObject.Modules[moduleIndex].TotalTestCase = contentJsonObject.Modules[moduleIndex].TotalTestCase + 1
        contentJsonObject.Modules[moduleIndex].FailedTestcases = contentJsonObject.Modules[moduleIndex].FailedTestcases + 1
    }

    updateTestCaseSummaryIntoContentJSON(startTime: any, suiteExecutionTime: any, description: string, status: any) {
        var tcId = fu.splitTCId(description)
        var tcDesc = fu.splitTCDescription(description)
        var mod = fu.getModuleOf(tcId)

        var contentJson = ju.readJsonFile(Constants.contentJsonFile)
        var modules = contentJson.Modules
        if (modules.length === 0) {
            var tcAarr = []
            var testCaseObj = fu.updateTestCaseObject(this.allStepObj, tcId, tcDesc, startTime, suiteExecutionTime, status)
            tcAarr.push(testCaseObj)
            var moduleObj;
            if (status === " Pass") {
                this.updateTotalPassCount(contentJson)
                moduleObj = fu.updateModuleObjectForPass(tcAarr, mod, startTime)
            } else if (status === " Fail") {
                this.updateTotalFailCount(contentJson)
                moduleObj = fu.updateModuleObjectForFail(tcAarr, mod, startTime)
            }

            contentJson.Modules.push(moduleObj)
            ju.writeJson(Constants.contentJsonFile, contentJson)

        } else {
            var flag = true;
            for (var i = 0; i < modules.length; i++) {
                if (contentJson.Modules[i].ModuleName === mod) {
                    var testCaseObj = fu.updateTestCaseObject(this.allStepObj, tcId, tcDesc, startTime, suiteExecutionTime, status)
                    contentJson.Modules[i].TestCases.push(testCaseObj)

                    if (status === " Pass")
                        this.updateTotalPassCountWithModule(contentJson, i)
                    else if (status === " Fail")
                        this.updateTotalFailCountWithModule(contentJson, i)

                    ju.writeJson(Constants.contentJsonFile, contentJson)
                    flag = false;
                    break
                }
            }

            if (flag) {
                var tcAarr = []
                var testCaseObj = fu.updateTestCaseObject(this.allStepObj, tcId, tcDesc, startTime, suiteExecutionTime, status)
                tcAarr.push(testCaseObj)
                var moduleObj;
                if (status === " Pass") {
                    this.updateTotalPassCount(contentJson)
                    moduleObj = fu.updateModuleObjectForPass(tcAarr, mod, startTime)
                } else if (status === " Fail") {
                    this.updateTotalFailCount(contentJson)
                    moduleObj = fu.updateModuleObjectForFail(tcAarr, mod, startTime)
                }

                contentJson.Modules.push(moduleObj)
                ju.writeJson(Constants.contentJsonFile, contentJson)
            }
        }
        this.deleteStepObj()
    }

    getFormatedExecutionTime(totalExecutionTime: any): String {
        var hours = Math.floor(totalExecutionTime / (60 * 60));

        var divisor_for_minutes = totalExecutionTime % (60 * 60);
        var minutes = Math.floor(divisor_for_minutes / 60);

        var divisor_for_seconds = divisor_for_minutes % 60;
        var seconds = Math.ceil(divisor_for_seconds);

        return hours + ":" + minutes + ":" + seconds
    }

    needToExecute(suiteDescription: string): boolean {
        var tcID:string = fu.splitTCId(suiteDescription);
        var tempFlag:boolean = true
        var content = ju.readJsonFile(Constants.testSuiteJsonPath + "/" + Constants.currentRunDetails.moduleName + ".json")
        for (var i = 0; i < content.Module.length; i++) {
            if (tcID === content.Module[i].ScriptID) {
                if (content.Module[i].Flag === "Yes")
                    tempFlag = true
                else
                    tempFlag = false
            }
        }
        return tempFlag
    }

    reportCofiguration(): boolean {
        if (!fs.existsSync(Constants.reportsFolder)) {
            copydir.sync(Constants.reportTemplate, Constants.reportsFolder)
            return false
        } else
            return true

    }

    getPrevItrNo(): any {
        var itrNo;
        var cObj;
        try {
            cObj = ju.readJsonFile(Constants.contentJsonFile)
            itrNo = cObj.Project[6].TagName
        } catch (err) {
            itrNo = 0;
        }
        return itrNo;
    }

    createAndUpdateBasicContentJson(itrNo: number) {
        var content = ju.readJsonFile(Constants.contentJsonTemplate)
        var projectObj = ju.readJsonFile(Constants.projectConfigJsonFile)

        content.Project[0].TagName = projectObj.ProjectName
        content.Project[1].TagName = projectObj.Domain
        content.Project[2].TagName = projectObj.SubDomain
        content.Project[3].TagName = projectObj.Platform
        content.Project[4].TagName = projectObj.Environment
        content.Project[5].TagName = projectObj.Language
        content.Project[6].TagName = itrNo

        ju.writeJson(Constants.contentJsonFile, content)
    }

    backUp(itrNo: number) {
        if (itrNo != 0) {
            copydir.sync(Constants.currentFolderPath, Constants.tempFolderPath)
            fs.renameSync(Constants.tempFolderPath, Constants.previousItrnPath + itrNo)
            try {
                fs.unlinkSync(Constants.contentJsonFile)
            } catch (err) { }
        }
    }

    cleanCurrentFolder(){
        fu.cleanScreenshotsDir()
    }
}