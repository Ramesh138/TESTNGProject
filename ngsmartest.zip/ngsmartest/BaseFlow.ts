import { browser } from 'protractor'
import { updateLog } from './Report'
import framework from './Framework'
import {Wrappers} from './Wrappers'
import {Matcher} from './Matcher';

var fw = new framework();
var wrap = new Wrappers()

export enum DO {
    SENDKEYS = 'SENDKEYS',
    CLEARSEND = 'CLEARSEND',
    CLICK = 'CLICK',
    HIT_ENTER = 'HIT_ENTER',
    CLICK_ON_MATCHING_TEXT = 'CLICK_ON_MATCHING_TEXT',
    SELECT_BY_INDEX = 'SELECT_BY_INDEX',
    SELECT_BY_VALUE = 'SELECT_BY_VALUE',
    SELECT_BY_RANDOM = 'SELECT_BY_RANDOM',
    MAXIMIZE = 'MAXIMIZE',
    NAV_TO = 'NAV_TO',
}

/**
     * Will fetch the value from JSON or excel file 
     * 
     * @param {!string} key key
     * 
     */
export function getData(key: string): any {
    var text;
    var result = fw.getTestDataJson()
    Object.keys(result).forEach(function (_key) {
        if (_key === key) {
            text = result[_key]
        }
    })
    return text
}

/**
     * This function is to perform an action on webbrowser
     * 
     * Action : SENDKEYS
     * -----------------------------------------------------------------------------
     * @param {!string} action What is the action to be performed on webbrowser
     * @param {!ElementFinder} element On which element the action to be performed
     * @param {!string} value the value to type in the textbox
     * @param {!string} log log text (optional)
     *
     *  Action : CLEARSEND
     * -----------------------------------------------------------------------------
     * @param {!string} action What is the action to be performed on webbrowser
     * @param {!ElementFinder} element On which element the action to be performed
     * @param {!string} value the value to type in the textbox
     * @param {!string} log log text (optional)
     * 
     * Action : CLICK
     * -----------------------------------------------------------------------------
     * @param {!string} action What is the action to be performed on webbrowser
     * @param {!ElementFinder} element On which element the action to be performed
     * @param {!string} log log text (optional)
     * 
     * Action : CLICK_ON_MATCHING_TEXT
     * -----------------------------------------------------------------------------
     * @param {!string} action What is the action to be performed on webbrowser
     * @param {!ElementArrayFinder} elements List of elements
     * @param {!string} value The value to be clicked on the list of elements
     * @param {!string} log log text (optional)
     * 
     * Action : SELECT_BY_INDEX
     * -----------------------------------------------------------------------------
     * @param {!string} action What is the action to be performed on webbrowser
     * @param {!ElementArrayFinder} elements List of elements
     * @param {!number} value index to be selected
     * @param {!string} log log text (optional)
     * 
     * Action : SELECT_BY_VALUE
     * -----------------------------------------------------------------------------
     * @param {!string} action What is the action to be performed on webbrowser
     * @param {!ElementArrayFinder} elements List of elements
     * @param {!string} value value to be selected
     * @param {!string} log log text (optional)
     * 
     * Action : SELECT_BY_RANDOM
     * -----------------------------------------------------------------------------
     * @param {!string} action What is the action to be performed on webbrowser
     * @param {!ElementArrayFinder} elements List of elements
     * @param {!string} log log text (optional)
     */
export function perform(action: any, arg1?: any, arg2?: any, arg3?: any) {
    switch (action) {
        case "SENDKEYS": {
            wrap.sendKeys(arg1, arg2, arg3)
            break;
        }
        case "CLEARSEND": {
            wrap.clearSend(arg1, arg2, arg3)
            break;
        }
        case "CLICK": {
            wrap.click(arg1, arg2)
            break;
        }
        case "HIT_ENTER": {
            wrap.enter()
            break;
        }
        case "CLICK_ON_MATCHING_TEXT": {
            wrap.clickOnMatchingText(arg1, arg2, arg3)
            break;
        }
        case 'SELECT_BY_VALUE': {
            wrap.clickOnMatchingText(arg1, arg2, arg3)
            break;
        }
        case "SELECT_BY_INDEX": {
            wrap.selectByIndex(arg1, arg2, arg3)
            break;
        }
        case "SELECT_BY_RANDOM": {
            wrap.selectByRandomValue(arg1, arg2)
            break;
        }
        case "MAXIMIZE": {
            browser.driver.manage().window().maximize();
            break;
        }
        case "NAV_TO": {
            browser.get(arg1)
            break;
        }
        default: {
            console.log("Invalid choice");
            break;
        }
    }
}

/**
     * Update logs in the reports 
     * 
     * @param {!string} log log text
     * 
     */
export function log(log: string) {
    updateLog(log)
}

export default class BaseFlow {

    async goTo() {
        await browser.driver.manage().window().maximize();
        await browser.get(fw.getPrjectUrl())
        log("url launched successfully")
    }

}

export function verify(actual:any){
    return new Matcher(actual)
}