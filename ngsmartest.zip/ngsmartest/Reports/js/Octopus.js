var app = angular.module('parentApp', []);

	app.filter('unique', function() {
   // we will return a function which will take in a collection
   // and a keyname
   return function(collection, keyname) {
      // we define our output and keys array;
      var output = [], 
          keys = [];
      
      // we utilize angular's foreach function
      // this takes in our original collection and an iterator function
      angular.forEach(collection, function(item) {
          // we check to see whether our object exists
          var key = item[keyname];
          // if it's not already part of our keys array
          if(keys.indexOf(key) === -1) {
              // add it to our keys array
              keys.push(key); 
              // push this item to our final output array
              output.push(item);
          }
      });
      // return our array which should be devoid of
      // any duplicates
      return output;
   };
});


app.filter('groupBy', function(){
		return function(list, group_by) {

		var filtered = [];
		var prev_item = null;
		var group_changed = false;
		// this is a new field which is added to each item where we append "_CHANGED"
		// to indicate a field change in the list
		var new_field = group_by + '_CHANGED';

		// loop through each item in the list
		angular.forEach(list, function(item) {

			group_changed = false;

			// if not the first item
			if (prev_item !== null) {

				// check if the group by field changed
				if (prev_item[group_by] !== item[group_by]) {
					group_changed = true;
				}

			// otherwise we have the first item in the list which is new
			} else {
				group_changed = true;
			}

			// if the group changed, then add a new field to the item
			// to indicate this
			if (group_changed) {
				item[new_field] = true;
			} else {
				item[new_field] = false;
			}

			filtered.push(item);
			prev_item = item;

		});

		return filtered;
		};
	});
		


app
		.controller(
				'myController',
				function($scope, $http,$sce) {
				
					$scope.imgsrcv=null;
					$scope.smllimgsrc=null;
					$scope.folder="Current";
					$scope.jsonFileName="Content.json";
					$scope.completeFilePath="Current/Content.json"
					$scope.filePath="Current/Content.json"
					
					$scope.pageName = 'TestSuite';
					$scope.status = false;
					$scope.Statuses = {};
					$scope.reportLevel="Current/";
					$scope.currentView = 'active';
					$scope.pageToLoad = "TestSuite.html"
					$scope.tabName = "Overview";
					$scope.graphnum = 1;
					$scope.oldcontents = [];
					
					$scope.hoverTestCase="true";
					$scope.hoverTestStep="true";
					$scope.hoverStatusPass="true";
					$scope.hoverStatusFail="true";
					$scope.hoverStatusNoRun="true";
					$scope.hoverStatusSkip="true";
					$scope.hoverStatusWarning="true";
					
					$scope.collapsefie="side-nav";
					$scope.loadvideodisp=="None";
					$scope.filter=" ";
					$scope.filteri = 1;
					$scope.filterj = 1;
					$scope.filterk = 1;
					$scope.filterl = 1;
					
					$scope.loadite=1;
					$scope.loaddisp="None";
					$scope.imagestatslog;
					$scope.modules="";
					$scope.ExecutionSummary="";
					$scope.Statuses="";
					$scope.currentIteration=0;
					
					$scope.tcasename;
					$scope.tcasest;
					
					$scope.filterclassPassed = "n-label n-label_status_passed";
					$scope.filterclassFailed = "n-label n-label_status_failed";
					$scope.filterclassSkipped = "n-label n-label_status_skipped";
					$scope.filterclassNoRun = "n-label n-label_status_norun";
					$scope.filterclassWarning="n-label n-label_status_warning";
					
					$scope.selectedCountry="case in modul.TestCases | filter:{'TestCaseStatus': 'Pass'}:true";
					
					$scope.logsExpand="side-nav__icon fa fa-plus-square-o";
					$scope.logsCollapse= "side-nav__icon fa fa-minus-square-o";
					$scope.logsColExp="side-nav__icon fa fa-plus-square-o";
					
					$scope.ModExpand="side-nav__icon fa fa-plus-square-o";
					$scope.ModCollapse= "side-nav__icon fa fa-minus-square-o";
					$scope.ModColExp="side-nav__icon fa fa-plus-square-o";
					
					$scope.modalRight="angle fa fa-angle-right fa-fw fa-lg";
					$scope.modalDown="angle fa fa-angle-down fa-fw fa-lg";
					$scope.modalRD="angle fa fa-angle-right fa-fw fa-lg";
					
					$scope.iterationNumber=0;
					
					$scope.getDisp=0;
					
					$scope.accordion = {
						videosrcv:null,
						imgsrcv:null,
						logstest:null,
						siden:null,
						exc:null,
						base:null,
						logo:null,
						moduleLevel : null,
						testCaseLevel : null,
						exceptionLevel : null,
						exceptiontest : null,
						current:null,
						logexco:null,
						modexco:null
					};
					
					
					$http
							.get("Current/content.json")
							.then(
									function(response) {
										$scope.modules = response.data.Modules;
										$scope.ExecutionSummary = response.data.Project;
										$scope.Statuses = response.data.ProjectStatus;
										$scope.currentIteration= parseInt(response.data.Project[6].TagName);
										$scope.iterationNumber=$scope.currentIteration;
									});		
					
					
				
					$(document).ready(function() {
						$("#myimg").click(function() {
							$("#myModal").modal();
						});
					});
					
					
					
					$scope.showGraphOverview = function() {

						var diff = {
							Passed : $scope.Statuses[0].TotalPassedCount,
							Failed : $scope.Statuses[0].TotalFailedCount,
							Skipped : $scope.Statuses[0].TotalSkippedCount,
							NoRun : $scope.Statuses[0].TotalNoRunCount,
							
						};

						var chart = new CanvasJS.Chart(
								"chartContainer1",
								{
									title : {

									},
									animationEnabled : true,
									data : [ {
										type : "doughnut",
										startAngle : 60,
										toolTipContent : "{legendText}: {y} - <strong>#percent% </strong>",
										showInLegend : false,
										dataPoints : [ {
											y : diff.Passed,
											legendText : "Passed",
											color : "#97CC64"
										}, {
											y : diff.Failed,
											legendText : "Failed",
											color : "#FD5A3E"
										}, {
											y : diff.Skipped,
											legendText : "Skipped",
											color : "#d35ebe"
										}, {
											y : diff.NoRun,
											legendText : "NoRun",
											color : "#AAAAAA"
										}, 

										]
									} ]
								});
						chart.render();
					}
					
					
					$scope.LoadVideo=function()
                                                                                
                                                                                {
                                                                                                if($scope.loadvideodisp=="None")
                                                                                                {
                                                                                                                
                                                                                                                $scope.loadvideodisp="block";
                                                                                                                  $scope.accordion.videosrcv=$scope.reportLevel + $scope.video ;                                
                                                                                  }
                                                                                  else 
                                                                                  {
                                                                                                $scope.loadvideodisp="None";
                                                                                  }
                                                                                                
                                                                                                
                                                                                }
																				
																				

					
					$scope.changeclassv1=function()
					{
						$scope.changeclass1="node node__expanded";
						$scope.changeclass2="node";
						$scope.changeclass3="node";
						$scope.changeclass4="node";
				
					}
					
					$scope.goToSuites=function()
					{
						$scope.filterclassPassed = "n-label n-label_status_passed";
						$scope.filterclassFailed = "n-label n-label_status_failed";
						$scope.filterclassSkipped = "n-label n-label_status_skipped";
						$scope.filterclassNoRun = "n-label n-label_status_norun";
						$scope.filterclassWarning = "n-label n-label_status_warning"
						
						$scope.filter=" ";
						$scope.tabName = "Suites";
						$scope.loaddisp="None";
						
						$scope.accordion.logo=0;
						$scope.accordion.current=null;
						$scope.accordion.logexco=0; 
						$scope.accordion.modexco=0; 
					
						$scope.ModColExp="side-nav__icon fa fa-plus-square-o";
						$scope.logsColExp="side-nav__icon fa fa-plus-square-o";
						
						$scope.modalRD=$scope.modalRight;
					}
					
					
					$scope.goToSuitesMain=function(field)
					{
						
						$scope.modalRD=$scope.modalDown;
						$scope.filterclassPassed = "n-label n-label_status_passed";
						$scope.filterclassFailed = "n-label n-label_status_failed";
						$scope.filterclassSkipped = "n-label n-label_status_skipped";
						$scope.filterclassNoRun = "n-label n-label_status_norun";
						$scope.filterclassWarning = "n-label n-label_status_warning"
						
						$scope.filter=" ";
						$scope.tabName = "Suites";
						$scope.loaddisp="None";
						
						$scope.accordion.logo=0;
						$scope.accordion.current=field;
						$scope.accordion.logexco=0; 
						$scope.accordion.modexco=0; 
					
						$scope.ModColExp="side-nav__icon fa fa-plus-square-o";
						$scope.logsColExp="side-nav__icon fa fa-plus-square-o";
					}
					
					$scope.goToSuitesFilter=function(field1,field2)
					{
						$scope.goToSuites();
						$scope.accordion.current=field1;
						$scope.modalRD=$scope.modalDown;
						 
						if(field2 == "Pass" || field2=="PASS")
						{
							
							$scope.ChangePass();
							$scope.accordion.modexco=0;							
						}
						else if(field2=="Fail" || field2=="FAIL" )
						{
							$scope.ChangeFail();
							$scope.accordion.modexco=0;	
							
						}
						else if(field2=="Skip" || field2=="SKIP")
						{
							$scope.ChangeSkipped();
							$scope.accordion.modexco=0;	
							
						}
						else if(field2=="NoRun" ||  field2=="NORUN")
						{
							$scope.ChangeNoRun();
							$scope.accordion.modexco=0;	
							
						}
						
						else if(field2=="Warning" ||  field2=="WARNING")
						{
							$scope.ChangeWarning();
							$scope.accordion.modexco=0;	
							
						}
						
						else
						{}
						
					}
					
					$scope.expandSingleModule=function(field)
					{
						if($scope.accordion.current==field)
						{
							
							 if($scope.accordion.modexco!=1)
						  {
							$scope.modalRD=$scope.modalRight;
							var field2="";
							$scope.accordion.logo=0;
						  }
						}
						else
						{
							var field2=field;
							$scope.modalRD=$scope.modalDown;
						}
						return field2;
					
					}
					
					$scope.expandSingleTestCase=function(field)
					{
						if($scope.accordion.logstest==field)
						{
							
							var field2="";
							
							
						}
						else
						{
							var field2=field;
						}
						return field2;
						
					}
					
					
					$scope.onclickOverview=function()
					{
						$scope.tabName = "Overview";
						$scope.loaddisp="None";
						
					}
					
					$scope.onclickSmoke=function()
					{
						$scope.tabName = "Smoke";
						$scope.loaddisp="None";
						
					}
					
					$scope.onclickCategories=function()
					{
						$scope.tabName = "Categories";
						$scope.loaddisp="None";
						
					}
					
					$scope.onclickGraphs=function()
					{
						$scope.tabName = "Graphs";
						$scope.loaddisp="None";
						
					}
					
					
					
					$scope.changeclassv3=function()
					{
						$scope.changeclass3="node node__expanded";
						$scope.changeclass1="node";
						$scope.changeclass2="node";
						$scope.changeclass4="node";
						
						
					
					}
					
					$scope.changeclassv4=function()
					{
						$scope.changeclass4="node node__expanded";
						$scope.changeclass1="node";
						$scope.changeclass2="node";
						$scope.changeclass3="node";
						
					
					}
					
					
					
					$scope.ChangePass = function() {
						
						
						$scope.filter = {};
						$scope.filterclassFailed = "n-label n-label_status_failed";
						$scope.filterclassSkipped = "n-label n-label_status_skipped";
						$scope.filterclassNoRun = "n-label n-label_status_norun";
						$scope.filterclassWarning = "n-label n-label_status_warning"
						
						if ($scope.filterclassPassed == "n-label n-label_status_passed") {
							//var x="{'TestCaseStatus': Pass}:true";
							
							$scope.filter = "Pass";
							
							$scope.filterclassPassed = "y-label y-label_status_passed";
							$scope.ModColExp=$scope.ModExpand;
							$scope.expandCollpaseModule();
						} else {
							$scope.filter = " ";
							
							$scope.filterclassPassed = "n-label n-label_status_passed";
							$scope.expandCollpaseModule();
						}

					}

					

					$scope.ChangeFail = function() {
						
						$scope.filter = " ";
						$scope.filterclassSkipped = "n-label n-label_status_skipped";
						$scope.filterclassNoRun = "n-label n-label_status_norun";
						$scope.filterclassPassed = "n-label n-label_status_passed";
						$scope.filterclassWarning = "n-label n-label_status_warning"
						
						if ($scope.filterclassFailed == "n-label n-label_status_failed") {
							$scope.filter = "Fail";
							
							$scope.filterclassFailed = "y-label y-label_status_failed";
							$scope.ModColExp=$scope.ModExpand;
							$scope.expandCollpaseModule();
						} else {
							$scope.filter = " ";
							
							$scope.filterclassFailed = "n-label n-label_status_failed";
							$scope.expandCollpaseModule();
						}

					}

					$scope.ChangeNoRun = function() {
						$scope.filter = {};
						$scope.filterclassPassed = "n-label n-label_status_passed";
						$scope.filterclassFailed = "n-label n-label_status_failed";
						$scope.filterclassSkipped = "n-label n-label_status_skipped";
						$scope.filterclassWarning = "n-label n-label_status_warning"
						
						if ($scope.filterclassNoRun == "n-label n-label_status_norun") {
							$scope.filter = "NoRun";
							
							$scope.filterclassNoRun = "y-label y-label_status_norun";
							$scope.ModColExp=$scope.ModExpand;
							$scope.expandCollpaseModule();
						} else {
							$scope.filter = " ";
							
							$scope.filterclassNoRun = "n-label n-label_status_norun";
							$scope.expandCollpaseModule();
						}

					}

					$scope.ChangeWarning = function() {
						$scope.filter = {};
						
						$scope.filterclassNoRun = "n-label n-label_status_norun";
						$scope.filterclassPassed = "n-label n-label_status_passed";
						$scope.filterclassFailed = "n-label n-label_status_failed";
						$scope.filterclassSkipped = "n-label n-label_status_skipped"
						
						if ($scope.filterclassWarning == "n-label n-label_status_warning") {
							$scope.filter = "Warning";
							
							$scope.filterclassWarning = "y-label y-label_status_warning";
							$scope.ModColExp=$scope.ModExpand;
							$scope.expandCollpaseModule();
						} else {
							$scope.filter = " ";
							
							$scope.filterclassWarning = "n-label n-label_status_warning";
							$scope.expandCollpaseModule();
						}

					}
					
					$scope.ChangeSkipped = function() {
						$scope.filter = {};
						$scope.filterclassNoRun = "n-label n-label_status_norun";
						$scope.filterclassPassed = "n-label n-label_status_passed";
						$scope.filterclassFailed = "n-label n-label_status_failed";
						$scope.filterclassWarning = "n-label n-label_status_warning"
						
						if ($scope.filterclassSkipped == "n-label n-label_status_skipped") {
							$scope.filter = "Skip";
							
							$scope.filterclassSkipped = "y-label y-label_status_skipped";
							$scope.ModColExp=$scope.ModExpand;
							$scope.expandCollpaseModule();
						} else {
							$scope.filter = " ";
							
							$scope.filterclassSkipped = "n-label n-label_status_skipped";
							$scope.expandCollpaseModule();
						}

					}

					$scope.showGraph = function() {

						
						var diff = {
							Passed : $scope.Statuses[0].TotalPassedCount,
							Failed : $scope.Statuses[0].TotalFailedCount,
							Skipped : $scope.Statuses[0].TotalSkippedCount,
							NoRun : $scope.Statuses[0].TotalNoRunCount,
							
						};

						var chart = new CanvasJS.Chart(
								"chartContainer",
								{
									title : {
										text : "Project Level Status"
									},
									animationEnabled : true,

									data : [ {
										type : "doughnut",
										startAngle : 60,
										toolTipContent : "{legendText}: {y} - <strong>#percent% </strong>",
										showInLegend : true,

										dataPoints : [ {
											y : diff.Passed,
											indexLabel : "#percent%",
											legendText : "Passed",
											color : "#97CC64"
										}, {
											y : diff.Failed,
											indexLabel : "#percent%",
											legendText : "Failed",
											color : "#FD5A3E"
										}, {
											y : diff.Skipped,
											indexLabel : "#percent%",
											legendText : "Skipped",
											color : "#d35ebe"
										}, {
											y : diff.NoRun,
											indexLabel : "#percent%",
											legendText : "NoRun",
											color : "#AAAAAA"
										}

										]
									} ]
								});
						chart.render();

					}
					
				
					$scope.expandCollpaseLogs=function()
					{
						
						if ($scope.logsColExp==$scope.logsExpand)
					  {
						 $scope.accordion.logexco=1;
							$scope.logsColExp=$scope.logsCollapse;
							
									  
					  }
					  else 
					  {
						   $scope.accordion.logstest=0;
						   $scope.accordion.logexco=0; 
						   $scope.logsColExp=$scope.logsExpand;
						  
					  }
					  
					  
						
					}
					
					$scope.expandCollpaseModule=function()
					{
						
						
						if ($scope.ModColExp==$scope.ModExpand)
					  {
							$scope.accordion.modexco=1; 
							$scope.ModColExp=$scope.ModCollapse;
						$scope.modalRD=$scope.modalDown;
									  
					  }
					  else 
					  {
						 
						   $scope.accordion.logo=0;
							$scope.accordion.current=null;
							$scope.accordion.logexco=0;
						   $scope.accordion.modexco=0; 
						    $scope.modalRD=$scope.modalRight;
							$scope.ModColExp=$scope.ModExpand;
						  
					  }
						
						
						
					}
				
					$scope.LoadSide=function() {
					  
					  if ($scope.loaddisp=="None")
					  {
						$scope.loaddisp="block";
									  
					  }
					  else 
					  {
						$scope.loaddisp="None";
					  }
					  
					  $scope.groups = [];
						var a = $scope.currentIteration;
				
						$scope.iterationNumber= $scope.currentIteration;
						
						var iterationLimitReached=1;
						
						
						
					for(i=a-1;i>0;i--) {
							
							if(iterationLimitReached>15
							){
							break;
							}else{
							
							$scope.groups.push({
								Iterations: "Iteration-" + i
								});
								}
								iterationLimitReached=iterationLimitReached+1;
						
						}

					
					}
					
					$scope.LoadSideBack=function()
					{
						$scope.loaddisp="None";
						
					}
					
					$scope.onClickAppContent=function()
					{
						$scope.loaddisp="None";
						
					}
					
					$scope.onclickside=function()
					{
						$scope.loaddisp="None";
						
					}
					
					
					$scope.LoadSide1=function(fiel) {
						
					
						$scope.currentPath="PreviousRun/"+fiel+"/content.json"
						
						if ($scope.loaddisp=="None")
					  {
						$scope.loaddisp="block";
									  
					  }
					  else 
					  {
						$scope.loaddisp="None";
					  }
					
						
							$http
							.get()
							.then(
									function(response) {
										$scope.modules = response.data.Modules;
										$scope.ExecutionSummary = response.data.Project;
										$scope.Statuses = response.data.ProjectStatus;
										$scope.iterationNumber=response.data.Project[6].TagName;

									});					
					
						$scope.loadcontentjson = 2;
					}
					
						
					$scope.loadJson=function(field) {
						
						$scope.accordion.logo=0;
						$scope.accordion.current=null;
						$scope.accordion.logexco=0; 
						$scope.logsColExp=$scope.logsExpand;
						$scope.accordion.modexco=0; 
						$scope.ModColExp=$scope.ModExpand;
						$scope.loaddisp="None";
					
					
					
					var filepath;
					$scope.tabName = "Overview";
					if (field=="Current")
					{
							$scope.reportLevel="Current/";
							filePath=$scope.completeFilePath;
					}
					else{
					
									
						if ($scope.loaddisp=="None")
					  {
						$scope.loaddisp="block";
									  
					  }
					  else 
					  {
						$scope.loaddisp="None";
					  }
					  
						$scope.reportLevel="PreviousRun/"+field+"/";
						
						filePath="PreviousRun/"+field+"/content.json";
					}
					
						$http
							.get(filePath)
							.then(
									function(response) {
										$scope.modules = response.data.Modules;
										$scope.ExecutionSummary = response.data.Project;
										$scope.Statuses = response.data.ProjectStatus;
										$scope.iterationNumber=response.data.Project[6].TagName;
									});		
					
						}
					
					
					$scope.loadImage=function(imgsrc)
				
					{
					
					
						
						$scope.imgsrcv=$scope.reportLevel+imgsrc;
						
					
						
					}
					
					
					$scope.loadcategories=function()
					{
					
					$scope.catg=[];
					cat = parseInt($scope.modules.length);
					
					
					for(i=0;i<cat;i++)
					{
					
						var zat=parseInt($scope.modules[i].TestCases.length)
						
						
						for(j=0;j<zat;j++)
						{
						
								
						var TestCaseEx = String($scope.modules[i].TestCases[j].TestException);
						var TestCaseExs = TestCaseEx.split("-");
						
						$scope.catg.push({
							
							ModuleN: $scope.modules[i].ModuleName,
							TestCaseStatusN:$scope.modules[i].TestCases[j].TestCaseStatus,
							TestCaseN: $scope.modules[i].TestCases[j].TestCaseName,
							ExecutionTimeN:$scope.modules[i].TestCases[j].ExecutionTime,
							TestCaseSceN:$scope.modules[i].TestCases[j].TestScenario,
							TestCaseException: $scope.modules[i].TestCases[j].TestException,
							Steps: $scope.modules[i].TestCases[j].Steps,
							VideoN:$scope.modules[i].TestCases[j].Video,
							TestCaseExceptionfilter:TestCaseExs[0],
							TestDescriptionN:$scope.modules[i].TestCases[j].TestDescription
						});
						
						
						}
						
						TestCaseEx = null;
						
					}

					

					}
					
				

					$scope.showBarGraph = function() {
						
						
						var z = $scope.modules.length;

						var datas = [];
						var datafail = [];
						var dataskip = [];
						var datanorun = [];
						var datawarning= [];
						for (i = 0; i < z; i++) {
							datas
									.push({
										y : parseInt($scope.modules[i].PassedTestcases),
										label : $scope.modules[i].ModuleName
									});
							datafail
									.push({
										y : parseInt($scope.modules[i].FailedTestcases),
										label : $scope.modules[i].ModuleName
									});
							dataskip
									.push({
										y : parseInt($scope.modules[i].SkippedTestcases),
										label : $scope.modules[i].ModuleName
									});
							datanorun
									.push({
										y : parseInt($scope.modules[i].NoRunTestcases),
										label : $scope.modules[i].ModuleName
									});
							datawarning
									.push({
										y : parseInt($scope.modules[i].WarningTestcases),
										label : $scope.modules[i].ModuleName
							});
						}

						var chart = new CanvasJS.Chart("chartContainer2", {
							title : {
								text : "Module Level Status"
							},
							dataPointWidth : 20,
							data : [ {

								color : "#97CC64",
								type : "bar",
								dataPoints : datas
							}, {
								color : "#FD5A3E",
								type : "bar",
								dataPoints : datafail
							}, {
								color : "#d35ebe",
								type : "bar",
								dataPoints : dataskip
							}, {
								color : "#AAAAAA",
								type : "bar",
								dataPoints : datanorun
							},{
								color : "#FFD050",
								type : "bar",
								dataPoints : datawarning
							}
							]
						});

						chart.render();

					}

					
						
						$scope.setstat=function(field12)
					{
						if(field12=="Pass" || field12=="PASS")
						{
						var staz="right.png"
						return staz;
						}
						else if(field12=="Fail" || field12=="FAIL")
						{
							var staz="wrong.png"
						return staz;
						
						}
						else if(field12=="Warning" || field12=="WARNING")
						{
							var staz="warning.png"
						return staz;
						
						}
					
					}
					
					$scope.showDurationGraph = function() {

						

						var z = $scope.modules.length;
						var x2 = 1;
						var dura = [];

						for (i = 0; i < z; i++) {

							var z=$scope.modules[i].ExecutionTime;
							var res = z.split(":");
							var hour=res[0];
							var min=res[1];
							var sec=res[2]
								
							var totmin= +hour + +min;
							
							dura.push({
								x : x2,
								y : parseInt(totmin),
								label : $scope.modules[i].ModuleName
							});
							x2 = x2 + 1;
						}

						var chart = new CanvasJS.Chart("chartContainer3", {
							title : {
								text : "Duration of Execution"
							},
							axisY : {
								title : "Time(Min)"
							},
							legend : {
								verticalAlign : "bottom",
								horizontalAlign : "center"
							},
							dataPointWidth : 35,
							data : [

							{

								color : "#4682b4",
								type : "column",
								showInLegend : true,
								legendMarkerType : "none",
								dataPoints : dura
							} ]

						});
						chart.render();
					}

					$scope.getPercentage = function(a, b) {
						var c = Math.round((a / b) * 84.75);
						if (c == 0)
						{
							c=5;
						}
							
						
						return c;
							
					}
					
				
					
					
					$scope.getStatusImage = function(status) {
						if (status == "Passed") {
							return "small-4 columns passimage";
						} else {
							return "small-4 columns failimage";
						}
					}
					$scope.getActiveClass = function(pageName) {
						if ($scope.pageName == pageName) {
							return "active";
						}
						return "inactive"
					}
					$scope.setCurrent = function(test) {
						$scope.current = test;
						$scope.status = true;
					}
					$scope.add = function(test) {

						$scope.testSteps = test.Steps;
						
						$scope.tstatus=test.TestCaseStatus;
						$scope.tscenario=test.TestScenario;
						$scope.tdesc=test.TestDescription;
						$scope.tcasen=test.TestCaseName;
						$scope.tException=test.TestException;
						$scope.video=test.Video;
						$scope.smallimgsrc=$scope.reportLevel;
						
					}
					
					
					$scope.getcolorcode=function(fiel)
					{
						
						if (fiel==" Pass" || fiel==" PASS")
						{
							var d= "#97cc64;";
							return d;
						}
						else if(fiel==" Fail" || fiel==" FAIL")
						{
							var d= "#fd5a3e";
							return d;
						}
						else if(fiel==" Skip" || fiel==" SKIP")
						{
							var d= "#d35ebe";
							return d;
						}
						
						else if(fiel==" NoRun" || fiel==" NORUN")
						{
							var d= "#aaa";
							return d;
						}
						else if(fiel==" Warning" || fiel==" WARNING")
						{
							var d= "#ffd050";
							return d;
						}
						
					}
					
					$scope.addcat = function(test1) {

						$scope.tmod=test1.ModuleN;
						$scope.tcasename=test1.TestCaseN;
						$scope.tcasest=test1.TestCaseStatusN;
						$scope.tcasescen=test1.TestCaseSceN;
						$scope.executionCaseN=test1.ExecutionTimeN;
						$scope.TestExceptionN=test1.TestCaseException;
						$scope.TestCaseExceptionfilterN=test1.TestCaseExceptionfilter;
						$scope.TestDescriptioncatN=test1.TestDescriptionN;
						
						
					}
					
					$scope.collpasechange=function()
					{
						if($scope.collapsefie=="side-nav")
						{
						$scope.collapsefie="side-nav side-nav_collapsed";
						}
						else
						{
						$scope.collapsefie="side-nav";
						}
						
						$scope.loaddisp="None";
					}
					
					
					
				
				
				});

$('.dropdown-menu').find('input').click(function(e) {
	e.stopPropagation();
});

angular.forEach($scope.products, function(value, index) {
	console.log($scope.products[index].name + ' ' + index);
});