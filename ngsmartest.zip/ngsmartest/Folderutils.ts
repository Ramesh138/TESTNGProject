import * as fs from 'fs'

export function recursiveDelete(path:string){
    if (fs.existsSync(path)) {
        fs.readdirSync(path).forEach(function (file:any, index:any) {
            var curPath = path + "/" + file;
            if (fs.lstatSync(curPath).isDirectory()) {
                recursiveDelete(curPath);
            } else {
                fs.unlinkSync(curPath);
            }
        });
        fs.rmdirSync(path);
    }
}

export default class Folderutils {

    deleteFolderRecursive(path:string) {
       recursiveDelete(path)
    }

    createDir(path:string) {
        if (!fs.existsSync(path)) {
            fs.mkdirSync(path);
        }
    }

    deleteDir(path:string){
        if (fs.existsSync(path)) {
            fs.rmdirSync(path);
        }
    }

    deleteFiles(dir:string) {
        var files = fs.readdirSync(dir)
        for (const file of files) {
            fs.unlinkSync(dir + '/' + file)
        }
    }

    deleteFile(filepath:string) {
            fs.unlinkSync(filepath)
    }

}
