

function systemPath() {
    return process.cwd().split("\\bin")[0].trim()
}


function getlabel(key){
    const fs = require('fs');
    // read the file into raw data
    let rawdata = fs.readFileSync('.//labels//English.json');
    // parse the raw data into meaningful JSON format
    let author = JSON.parse(rawdata);
    let websiteValue = author[key]
    console.log(" hbjhb "+websiteValue); 
    return websiteValue; 
}
        

function getLabelJson(){
    const fs = require('fs');
    return JSON.parse(fs.readFileSync(".//labels//English.json").toString())
}
            
console.log(" Label value "+getlabel("[SousTitre][demandesAfficheDemande]"))

console.log(" Label value1 "+getLabelJson().SaisieDesDonnees[0])