import * as xml from 'xmlbuilder';
import { constants, dynamic } from '../constants/constants';
import * as fs from 'fs'

export class XMLUtils {

    private testsuites: any;//xml.XMLElementOrXMLNode=;
    private modules: any;//xml.XMLElementOrXMLNode = this.testsuites.ele("testsuite");
    private testcases: any;//xml.XMLElementOrXMLNode = this.modules.ele("testcase");
    private mapModules: Map<String, Object> = new Map<String, Object>();

    constructor() { }

    addTestSuite(): any {
        this.testsuites = xml.create("testsuites")
    }

    checkIfModuleExists(moduleName: String): boolean {
        if (this.mapModules.get(moduleName) == undefined) {
            return false;
        }
        return true;
    }

    addModules(moduleName: String): any {
        this.modules = this.testsuites.ele("testsuite")
            .attribute("name", moduleName)
        this.mapModules.set(moduleName, this.modules);
    }

    addTestCases(tcName: String): any {
        this.testcases = this.modules.ele("testcase")
            .attribute("name", tcName)
            .attribute("classname", dynamic.currentRunDetails.moduleName)
    }

    updateTestCaseOnPass(timeDiff: any): any {
        this.testcases = this.testcases.attribute('time', timeDiff);
    }


    updateTestCaseOnFailure(timeDiff: any, message: any, stack: any): any {
        this.testcases = this.testcases.attribute('time', timeDiff);
        var failure = this.testcases.ele("failure")
            .attribute('type', 'exception')
            .attribute('message', message)
            .cdata(stack);
    }

    updateModule(timeDiff: any, tests: any, failure: any): any {
        this.modules.attribute('time', timeDiff)
            .attribute('tests', tests)
            .attribute('failures', failure)

    }
    updateTestSuite(timeDiff: any, tests: any, failure: any): any {
        this.testsuites.attribute('time', timeDiff)
            .attribute('tests', tests)
            .attribute('failure', failure)
        this.testsuites.end({ pretty: true });
    }

    addXMLToOutputPath(): any {
        fs.writeFile(constants.xmlSmarTestReport, this.testsuites, function (err: any) {
            if (err) throw err;
            console.log('XML GENERATED');
        });
    }


}