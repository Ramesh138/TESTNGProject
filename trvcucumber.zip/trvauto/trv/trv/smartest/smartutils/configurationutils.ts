import { constants, dynamic } from '../constants/constants'
import {jsonutils} from '../commonutils/jsonUtils'
import {folderutils} from '../commonutils/folderUtils'

import * as fs from 'fs'
import * as path from 'path'
import * as _ from 'lodash'
import * as XLSX from 'xlsx'

var ju = new jsonutils()
var fl = new folderutils()

export default class configurationutils {

    createTestSuiteJson(): any {

        fl.createDir(constants.testSuiteJsonPath)

        var moduleNames: any = []
        var workbook = XLSX.readFile(constants.testSuiteExcelFile);
        var sheet_name_list = workbook.SheetNames;
        sheet_name_list.forEach(function (sName: string) {
            moduleNames.push(sName)
            var moduleObj = XLSX.utils.sheet_to_json(workbook.Sheets[sName])
            var obj = { Module: moduleObj }
            ju.writeJson(constants.testSuiteJsonPath + "/" + sName + ".json", obj)
        })
        return moduleNames
    }

    updateExecutableModulesInConfiguration(exMods: any) {
        dynamic.executableModulesList = exMods
    }

    convertExcelTestDataToJSON(mName: string[]) {
        for (var i = 0; i < mName.length; i++) {
            var workbook = XLSX.readFile(constants.testDataPath + '/' + mName[i] + ".xlsx");
            var sheet_name_list = workbook.SheetNames;
            sheet_name_list.forEach((sName: any) => {
                var moduleObj = XLSX.utils.sheet_to_json(workbook.Sheets[sName])
                var obj = { Testdata: moduleObj }
                fl.createDir(constants.convertedTestDataJsonPath)
                var path = constants.convertedTestDataJsonPath + "/" + mName[i]
                fl.createDir(path)
                ju.writeJson(path + "/" + sName + ".json", obj)
            })
        }
    }

    createTestCaseListByModule(exMods: any) {
        var allModules = []
        for (const mod of exMods) {
            var _path = constants.convertedTestDataJsonPath + '/' + mod
            var files = fs.readdirSync(_path)
            for (const file of files) {
                var filePath = _path + '/' + file
                var tcName = path.basename(filePath, path.extname(filePath))
                allModules.push(mod + "|" + tcName)
            }
        }
        dynamic.testCaseListByModule = allModules
    }

    browserToExecute(): string {
        var pcObj = ju.readJsonFile(constants.projectConfigJsonFile)
        return pcObj.Browser
    }

    getCapability(): any {
        var pcObj = ju.readJsonFile(constants.projectConfigJsonFile)
        if (pcObj.Platform === "Web") {
            var cap = pcObj.WebCapabilities
            return cap
        } else if (pcObj.Platform === "Mobile") {
            var cap = pcObj.MobileCapabilities
            return cap
        }
    }

    getExecutableModules(allModules: any): string[] {
        var exMod = []
        for (const mod of allModules) {
            var fpath: string = constants.testSuiteJsonPath + '/' + mod + '.json'
            var obj = ju.readJsonFile(fpath)
            for (var i = 0; i < obj.Module.length; i++) {
                var flag = obj.Module[i].Flag
                var _mod = path.basename(fpath, path.extname(fpath))
                if (flag === 'Yes')
                    exMod.push(_mod)
            }
        }
        exMod = _.uniq(exMod)
        return exMod
    }

    getExecutableTestCasesFromExecutableModules(executableModules: string[]): string[] {
        var specs = []
        for (const mod of executableModules) {
            var obj = ju.readJsonFile(constants.testSuiteJsonPath + '/' + mod + ".json")
            for (var i = 0; i < obj.Module.length; i++) {
                var flag = obj.Module[i].Flag
                var fName = obj.Module[i].FeatureName                
                if (flag === 'Yes')
                    specs.push('../../features/' + mod + '/' + fName + '.feature')
            }
        }
        console.log(specs)
        specs = _.uniq(specs)
        return specs
    }

}