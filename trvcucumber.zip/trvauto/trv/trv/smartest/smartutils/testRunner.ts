import {jsonutils} from '../commonutils/jsonUtils'
import configutils from './configurationutils'

var ju = new jsonutils()
var cu = new configutils()

class testrunner {
    public executableModules: any = []
}

var tc = new testrunner()

export function setUp() {

    var allModules = cu.createTestSuiteJson()
    tc.executableModules = cu.getExecutableModules(allModules)
    cu.updateExecutableModulesInConfiguration(tc.executableModules)

}

export function getBrowser(): string {
    return cu.browserToExecute()
}

export function getCapabilities(): any {
    return cu.getCapability()
}

export function executableFeatures(): string[] {
    return cu.getExecutableTestCasesFromExecutableModules(tc.executableModules)
}