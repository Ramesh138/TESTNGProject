export class scripts{

    public static jsClick():string{
        return "arguments[0].click();"
    }

    public static highlight():string{
        return "arguments[0].setAttribute('style', color: Red; border: 2px solid red;);"
    }

    public static scrollToElement():string{
        return "arguments[0].scrollIntoView();"
    }

    public static scrollTo(x:number, y:number):string{
        return"window.scrollTo("+x+","+y+")"
    }

    public static scrollSmooth(height:number, width:number):string{
        return"window.scrollTo({top: "+height+",left: "+width+",behavior: 'smooth'});"
    }

    public static scrollToTopScreen():string{
        return"window.scrollTo(0, 0)"
    }
}