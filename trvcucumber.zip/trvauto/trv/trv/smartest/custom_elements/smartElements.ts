import { ElementFinder, ElementArrayFinder } from "protractor";
import { __ } from 'lodash/fp'
import { actions } from "../actions/seleniumActions";

export class Button {

    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public highlight() {
        return actions.highlight(this.element)
    }

    public scrollToElement(){
        return actions.scrollToElement(this.element)
    }

    public click(log?: string) {
        return actions.click(this.element, log)
    }

    public getText() {
        return this.element.getText()
    }

    public getAttribute(attribute: string) {
        return this.element.getAttribute(attribute)
    }

    public submit(log?: string) {
        return actions.submit(this.element, log)
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public enter(log?: string) {
        return actions.enter(this.element, log)
    }

    public hover(log?: string) {
        return actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return actions.jsClick(this.element, log)
    }

    public getElement() {
        return this.element
    }

    public clickAndWaitForAlertPresence(log?: string, millies?:number) {
        actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }

}

export class Icon {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement(){
        return actions.scrollToElement(this.element)
    }

    public highlight() {
        return actions.highlight(this.element)
    }

    public click(log?: string) {
        return actions.click(this.element, log)
    }

    public enter(log?: string) {
        return actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return actions.submit(this.element, log)
    }

    public getAttribute(attribute: string) {
        return this.element.getAttribute(attribute)
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public hover(log?: string) {
        return actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return actions.jsClick(this.element, log)
    }

    public getElement() {
        return this.element
    }

    public clickAndWaitForAlertPresence(log?: string, millies?:number) {
        actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }
}

export class Image {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement(){
        return actions.scrollToElement(this.element)
    }

    public highlight() {
        return actions.highlight(this.element)
    }

    public getAttribute(attribute: string) {
        return this.element.getAttribute(attribute)
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public click(log?: string) {
        return actions.click(this.element, log)
    }

    public enter(log?: string) {
        return actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return actions.submit(this.element, log)
    }

    public hover(log?: string) {
        return actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return actions.jsClick(this.element, log)
    }

    public getElement() {
        return this.element
    }

    public clickAndWaitForAlertPresence(log?: string, millies?:number) {
        actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }

}

export class Label {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement(){
        return actions.scrollToElement(this.element)
    }

    public highlight() {
        return actions.highlight(this.element)
    }

    public getText() {
        return this.element.getText()
    }

    public getAttribute(attribute: string) {
        return this.element.getAttribute(attribute)
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public click(log?: string) {
        return actions.click(this.element, log)
    }

    public enter(log?: string) {
        return actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return actions.submit(this.element, log)
    }

    public hover(log?: string) {
        return actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return actions.jsClick(this.element, log)
    }

    public getElement() {
        return this.element
    }

    public clickAndWaitForAlertPresence(log?: string, millies?:number) {
        actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }

}

export class Textbox {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement(){
        return actions.scrollToElement(this.element)
    }

    public highlight() {
        return actions.highlight(this.element)
    }

    public getElement() {
        return this.element
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public send(text: string, log?: string) {
            return this.element.sendKeys(text)
    }

    public enter(log?: string) {
        return actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return actions.submit(this.element, log)
    }

    public click(log?: string) {
        return this.element.click()
    }

    public clear(log?: string) {
        return this.element.clear()
    }

    public clearSend(text: string, log?: string) {
        return this.element.clear().then(() => {
            return this.element.sendKeys(text)
        })
    }

    public clickSend(text: string, log?: string) {
        return this.element.click().then(() => {
            return this.element.clear().then(() => {
                return this.element.sendKeys(text)
            })
        })
    }

    public clickAndWaitForAlertPresence(log?: string, millies?:number) {
        actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }
}

export class Checkbox {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement(){
        return actions.scrollToElement(this.element)
    }

    public highlight() {
        return actions.highlight(this.element)
    }

    public getElement() {
        return this.element
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public enter(log?: string) {
        return actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return actions.submit(this.element, log)
    }

    public check(log?: string) {
        return this.element.isSelected().then((flag:boolean) => {
            if (!flag)
               this.click(log)
        })
    }

    public unCheck(log?: string) {
        return this.element.isSelected().then((flag:boolean) => {
            if (flag)
                this.click(log)
        })
    }

    public isSelected(log?: string) {
        return this.element.isSelected()
    }

    public click(log?: string) {
        return actions.click(this.element, log)
    }

    public hover(log?: string) {
        return actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return actions.jsClick(this.element, log)
    }

    public clickAndWaitForAlertPresence(log?: string, millies?:number) {
        actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }
    
    public waitForelementToBeSelected(millies: number = 30000) {
        return actions.waitForelementToBeSelected(this.element, millies)
    }

}

export class RadioButton {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement(){
        return actions.scrollToElement(this.element)
    }

    public highlight() {
        return actions.highlight(this.element)
    }

    public getElement() {
        return this.element
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public enter(log?: string) {
        return actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return actions.submit(this.element, log)
    }

    public click(log?: string) {
        return actions.click(this.element, log)
    }

    public hover(log?: string) {
        return actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return actions.jsClick(this.element, log)
    }

    public clickAndWaitForAlertPresence(log?: string, millies?:number) {
        actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }
}

export class Link {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement(){
        return actions.scrollToElement(this.element)
    }

    public highlight() {
        return actions.highlight(this.element)
    }

    public getElement() {
        return this.element
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public enter(log?: string) {
        return actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return actions.submit(this.element, log)
    }

    public click(log?: string) {
        return actions.click(this.element, log)
    }

    public hover(log?: string) {
        return actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return actions.jsClick(this.element, log)
    }

    public clickAndWaitForAlertPresence(log?: string, millies?:number) {
        actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }
}

export class Grid {
    private elements: ElementArrayFinder;

    constructor(elements: ElementArrayFinder) {
        this.elements = elements
    }

    public scrollToElement(index:number){
        return actions.scrollToElement(this.elements.get(index))
    }

    public highlight(index:number) {
        return actions.highlight(this.elements.get(index))
    }

    public getElements() {
        return this.elements
    }

    public getElement(index: number) {
        return this.elements.get(index)
    }

    public clickByIndex(index: number) {
        return this.elements.get(index).click()
    }

    public clickByRandom() {
        return this.elements.count().then((count) => {
            var rNo: number = Math.floor((Math.random() * (count - 1)) + 1);
            return this.elements.get(rNo).click()
        })
    }

    public clickOnMatchingText(textToClick: string) {
        return this.elements.filter((elem: ElementFinder) => {
            return elem.getText().then((text: string) => {
                return text.trim() === textToClick.trim();
            });
        }).first().click()
    }

    public isEnabled(index: number) {
        return this.elements.get(index).isEnabled()
    }

    public isDisplayed(index: number) {
        return this.elements.get(index).isDisplayed()
    }

    public isPresent(index: number) {
        return this.elements.get(index).isPresent()
    }

    public isSelected(index: number) {
        return this.elements.get(index).isSelected()
    }

}

