import { ElementFinder, protractor, ElementArrayFinder, browser, ExpectedConditions } from "protractor";
import { __ } from 'lodash/fp'
import { scripts } from "../constants/scripts"

export class actions {

    public static click(element: ElementFinder, log?: string) {
        element.click()
    }

    public static enter(element: ElementFinder, log?: string) {
        return element.sendKeys(protractor.Key.ENTER)
    }

    public static submit(element: ElementFinder, log?: string) {
        return element.submit()
    }

    public static jsClick(element: ElementFinder, log?: string) {
        return browser.executeScript(scripts.jsClick(), element)
    }

    public static hover(element: ElementFinder, log?: string) {
        return browser.actions().mouseMove(element).perform()
    }

    public static actionClick(element: ElementFinder, log?: string) {
        return browser.actions().click(element).perform()
    }

    public static doubleClick(element: ElementFinder, log?: string) {
        return browser.actions().doubleClick(element).perform()
    }

    public static highlight(element: ElementFinder, log?: string) {
        browser.executeScript(scripts.highlight(), element.getWebElement())
        return element
    }

    public static scrollToElement(element: ElementFinder) {
        return browser.executeScript(scripts.scrollToElement(), element)
    }

    public static clickAndWaitForAlertPresence(element: ElementFinder, log?: string, millies?: number) {
        element.click().then(() => {
            browser.wait(ExpectedConditions.alertIsPresent(), millies)
        })
    }

    public static waitForVisibility(element: ElementFinder, millies: number = 30000) {
        return browser.wait(ExpectedConditions.visibilityOf(element), millies)
    }

    public static waitForPresence(element: ElementFinder, millies: number = 30000) {
        return browser.wait(ExpectedConditions.presenceOf(element), millies)
    }

    public static waitForInvisibility(element: ElementFinder, millies: number = 30000) {
        return browser.wait(ExpectedConditions.invisibilityOf(element), millies)
    }

    public static waitForStaleness(element: ElementFinder, millies: number = 30000) {
        return browser.wait(ExpectedConditions.stalenessOf(element), millies)
    }

    public static waitForClickable(element: ElementFinder, millies: number = 30000) {
        return browser.wait(ExpectedConditions.elementToBeClickable(element), millies)
    }

    public static waitForTextToPresentInElement(element: ElementFinder, text: string, millies: number = 30000) {
        return browser.wait(ExpectedConditions.textToBePresentInElement(element, text), millies)
    }

    public static waitForTextToPresentInElementValue(element: ElementFinder, text: string, millies: number = 30000) {
        return browser.wait(ExpectedConditions.textToBePresentInElementValue(element, text), millies)
    }

    public static waitForelementToBeSelected(element: ElementFinder, millies: number = 30000) {
        return browser.wait(ExpectedConditions.elementToBeSelected(element), millies)
    }

    public static waitForTitleIs(title: string, millies: number = 30000) {
        return browser.wait(ExpectedConditions.titleIs(title), millies)
    }

}