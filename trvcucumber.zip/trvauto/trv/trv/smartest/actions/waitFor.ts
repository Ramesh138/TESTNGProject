import { browser, ExpectedConditions, ElementFinder} from 'protractor'
import { actions } from './seleniumActions'

export function waitForVisibilityOf(locator:ElementFinder, millies:number = 3000) {
    return actions.waitForVisibility(locator, millies)
}

export function waitForPresenceOf(locator:ElementFinder, millies:number = 3000) {
    return actions.waitForPresence(locator, millies)
}

export function waitForInvisibilityOf(locator:ElementFinder, millies:number = 3000) {
    return actions.waitForInvisibility(locator, millies)
}

export function waitForStalenessOf(locator:ElementFinder, millies:number = 3000) {
    return actions.waitForStaleness(locator, millies)
}

export function waitForElementToBeClickable(locator:ElementFinder, millies:number = 3000) {
    return actions.waitForClickable(locator, millies)
}

export function waitForTitleIs(title:string, millies:number = 3000) {
    return actions.waitForTitleIs(title, millies)
}

export function switchToFrameFromDefault(element:ElementFinder) {
    browser.switchTo().defaultContent();
    browser.switchTo().frame(element)
}

export function switchToFrame(element:ElementFinder) {
    browser.switchTo().frame(element)
}

export function switchToDefault(element:ElementFinder) {
    browser.switchTo().defaultContent()
}

export function switchToWindow(windowTitle: string) {
}
