const { BeforeAll, After, Status } = require("cucumber");
import { browser } from "protractor";
import { config } from "../../config/conf";
import { Before, HookScenarioResult, AfterAll, GlobalHookCode,  } from "cucumber";
import { execFile } from "child_process";
import { CutomLogger } from '../../utls/customlogger';

import mailflow from "../../utls/mailconfiguration";

BeforeAll({ timeout: 100 * 1000 }, async () => {

    await browser.get(config.baseUrl);
      
});

Before(async (scenario: HookScenarioResult) => {

})


After(async function (scenario: HookScenarioResult) {
    if (scenario.result.status === Status.FAILED) {
        // screenShot is a base-64 encoded PNG
        const screenShot = await browser.takeScreenshot();
        this.attach(screenShot, "image/png");
    }
});

AfterAll({ timeout: 100 * 10000 }, async () => {
    await browser.quit();

  await  browser.sleep(1000)
   await  browser.sleep(6000)
   await mailflow.sendReportMail();
  return await  browser.sleep(6000)
});


