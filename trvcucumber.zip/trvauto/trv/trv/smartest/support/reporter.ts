import * as reporter from "cucumber-html-reporter";
import * as fs from "fs";
import * as mkdirp from "mkdirp";
import * as path from "path";
const jsonReports = path.join(process.cwd(), "/report/json");
const htmlReports = path.join(process.cwd(), "/report/html");
const targetJson = jsonReports + "/cucumber_report.json";


var options = {
    jsonFile: targetJson,
    output: htmlReports + "/cucumber_reporter.html",
    reportSuiteAsScenarios: true,
    theme: "bootstrap",
    scenarioTimestamp: true,
    launchReport: true,
    metadata: {
        "Application Name":"Travaux",
        "Test Environment": "Re#7",
        "App Version":"V1.0",
        "Browser": "Chrome  84.0.2840.98"
    }
};
export class Reporter {

    public static createDirectory(dir: string) {
        if (!fs.existsSync(dir)) {
            mkdirp.sync(dir);
        }
    }

    public static createHTMLReport() {
        try {
            reporter.generate(options);
        } catch (err) {
            if (err) {
                throw new Error("Failed to save cucumber test results to json file.");
            }
        }
    }
}
