import { browser, Config } from "protractor";
import { Reporter } from "../smartest/support/reporter";
const jsonReports = process.cwd() + "/report/json";
import { executableFeatures, setUp } from '../smartest/smartutils/testRunner'

//const { Authenticator } = require('authenticator-browser-extension');

export const config: Config = {
    setup: setUp(),

    directConnect: true,

    SELENIUM_PROMISE_MANAGER: false,
    
 //  baseUrl: "http://z013479:z013479@phpint01.sax.renault.fr:9031/trv/trvapp",
 //baseUrl: "http://z011615:giveno20@trvre701.intra.renault.fr/trv/trvapp",
 //baseUrl: "https://trv-app.gke.int.gcp.renault.com/",
 baseUrl:"https://trv-app.gke.dev.gcp.renault.com/",
    capabilities: {
        browserName: "chrome",
       // shardTestFiles: true,
       // maxInstances: 3, 
       //parallelTypes: ['features'],

        chromeOptions: {

            //  extensions: [
                
            //     Authenticator.for('z011615', 'giveno20').asBase64(),
                
            //  ],
    args: [ "--headless", "--disable-gpu", "--window-size=800,600" ] 
   // args: ["--headless", "--window-size=800x600", "--disable-gpu", "--no-sandbox", "--disable-dev-shm-usage", "--ignore-certificate-errors"]
    }
    },
    allScriptsTimeout: 300000,
    framework: "custom",
    frameworkPath: require.resolve("protractor-cucumber-framework"),

    specs: executableFeatures(),
    

    onPrepare: () => {
        browser.ignoreSynchronization = true;
        browser.manage().window().maximize();
        Reporter.createDirectory(jsonReports);
    },

    cucumberOpts: {
        compiler: "ts:ts-node/register",
        format: "json:./report/json/cucumber_report.json",
        require: ["../../bin/stepdefinitions/*.js", "../../bin/smartest/support/*.js"],
        strict: true,
        parallelTypes: ["feature"],
         tags: "@CucumberScenario"
    },

    onComplete: () => {
        Reporter.createHTMLReport();
    },
};