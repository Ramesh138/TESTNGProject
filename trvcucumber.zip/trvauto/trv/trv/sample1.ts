console.log("started")
let map = new Map()
var mysql = require("mysql");
let connection = mysql.createConnection({
  host:"s2946ads.mc2.renault.fr", //"s2946ads.mc2.renault.fr",
  user: "trv_adm",//"trv_adm",
  password: "trv_adm_int01",//"trv_adm_01",
  database: "trv_db_01",
  port : "3307",
});

connection.connect();
var sql = "SELECT COUNT(*) as Number FROM TRV_TB01_TRAVAUX_DEMANDES WHERE PRECISION_LIEU= 'SpecifiedLocation_PJSMZA'";
//console.log("sql to be "+Sqlquery)
var row;
 connection.query(sql, async function (err, rows) {
  console.log("Sql inside to be "+sql)
  if (err) {
    console.log(err)
    connection.end()
  } else {
    Object.keys(rows).forEach(function (keyItem) {
      row = rows[keyItem]
      map.set("DBValue", row.Number)
      console.log(" row value " + row.Number)
    })
  }
  connection.end()
  
  console.log(" value to be outside " +map.get("DBValue"))
})
