const sendmail = require('sendmail')({
    logger: {
        debug: console.log,
        info: console.info,
        warn: console.warn,
        error: console.error
    },
    silent: false,

    devPort: 25, // Default: False
    devHost: 'smtp.renault.fr', // Default: localhost
    smtpPort: 25, // Default: 25
    smtpHost: 'smtp.renault.fr' // Default: -1 - extra smtp host after resolveMX
})
console.log("svsdvdsvsdvsd")
sendmail({
    from: 'ramesh.ponneri@rntbci.com',
   // to: 'ramesh.ponneri@rntbci.com praveen.kokku@rntbci.com',
   to: 'ramesh.ponneri@rntbci.com,Selvaraj.Muniasamy@rntbci.com,mohamed-fethi.mederbel@renault.com',
    subject: 'TRAVAUX Mobile  Automation Report ',
    html: "HI Team <br> <br> please find the above attachment for the TRAVAUX Application automation Report <br> <br>  "+"<br><br>Regards <br> Ramesh Ponneri",
    attachments: [
        {   
            path:'..//trv//report//html//cucumber_reporter.html',
        },
    ]
}, function (err, reply) {
    console.log(err && err.stack);
    console.dir(reply);
});