import { loginPage } from "../pages/loginPage";
import { browser, By, element, protractor, ElementFinder, by } from "protractor"
import { admin_Flow } from "../flow/admin_Flow";
import { adminPage } from "../pages/adminPage";
import { labelUtils, getlabel, getlabelwithlangaue } from "../utls/labelUtil";
import { site_Flow } from "../flow/siteManagement_Flow";
import { sitePage } from "../pages/sitemanagement_page";
import { intventionTypeMngmnt_page } from "../pages/intventionTypeMngmnt_Page";
import { IntventionTypeMngmnt_Flow } from "../flow/IntventionTypeMngmnt_flow";
import { Alert } from "selenium-webdriver";
import { IntventionNatureMngmnt_Flow } from "../flow/intventionnatureMngmnt_flow";
const { Given, When, Then } = require("cucumber");
const chai = require("chai").use(require("chai-as-promised"));
const expect = chai.expect;
const adminpage: adminPage = new adminPage();
const labelutil: labelUtils = new labelUtils();
const siteflow: site_Flow = new site_Flow();
const sitepage: sitePage = new sitePage()
const internatureflow: IntventionNatureMngmnt_Flow= new IntventionNatureMngmnt_Flow();

var internaturevalue: any;
var minterventionvalue:any;
var firstvalueactual:any;
var preferedlangaue:any;

Then(/^Click on the intervention nature sub menu link$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await adminpage.getInterventionNaturesManagement().getElement().click();
});

Then(/^Validate all the labels in the intervention nature home page in "(.*?)"$/, { timeout: 2 * 10000 }, async (langauge: any) => {
  await browser.sleep(4000)
  preferedlangaue = labelutil.getlabelmethodvthlanguage(langauge);
  internatureflow.LabelValidationAll(preferedlangaue);
});

Then(/^click on the Add button in the intervention nature home page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,1000);');
  await element(by.css(".btn-save")).click()
  await browser.sleep(2000)
})

Then(/^verify pop up with message should be in the intervention nature home page and validate it is displayed correctly$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  let ale = await browser.switchTo().alert();
  var poptext = await ale.getText()
  var expected = labelutil.getlabelmethod("SelectDonneesPourAjoutOrdre", labelutil.getlabelmethodvthlanguage(preferedlangaue))
  //expect(poptext==expected).to.equal(true)
  await ale.accept();
})

Then(/^select the site from the site selection in intervention nature page$/, { timeout: 2 * 10000 }, async () => {
  await internatureflow.selectSiteValue();
})

Then(/^select the site from the intervention type selection in intervention nature page$/, { timeout: 2 * 10000 }, async () => {
  await internatureflow.selectInterventionTypeValue()
 // await internatureflow.selectInterventionTypeValue()
})

Then(/^Fill all the mandatory fields in the intervention nature add page$/, { timeout: 2 * 10000 }, async () => {
   internaturevalue=await internatureflow.internatureCreation()
})

Then(/^click on the add button in the intervention nature add page$/, { timeout: 2 * 10000 }, async () => {
  await internatureflow.clickAddButtonInAddForm();
})

Then(/^Now verify the created record in the intervention nature list page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await siteflow.navigateToLastpage()
  var listcount=await element.all(by.xpath(".//datatable-body-cell[1]")).count();
  var actualsitevalue=await sitepage.Search_Value(listcount).getText();
  console.log(actualsitevalue+ "   compare  "+ internaturevalue)
 //  expect(actualsitevalue).to.eventually.equal(modifyactualvalue)
 expect(actualsitevalue==internaturevalue).to.equal(true)
});

Then(/^Now intervention nature form page should be launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.executeScript('window.scrollTo(0,1000);');
  var actual = await element(by.xpath("//form/div[1]/h3")).getText();
  var expected = labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SaisieDesDonnees[0] + " '" + labelutil.getlabelmethod("NatureProbleme",labelutil.getlabelmethodvthlanguage(preferedlangaue))+"'";
  expect(actual==expected).to.equal(true)
})
Then(/^Click on the cancel button in the intervention nature page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,2000);');
  await sitepage.getABcancel().click();
});

Then(/^Verify whether the intervention nature page is launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,1000);');
  var actual = await element(by.xpath("//intervention-nature-list/div/h3[1]")).getText();
  var expected = labelutil.getlabelmethod("RechercheDesDonnees",labelutil.getlabelmethodvthlanguage(preferedlangaue));
  console.log(actual+" ==== intervention nature "+expected)
  await expect(actual==expected).to.equal(true)
});

Then(/^click on the created intervention nature hyperlink$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,1000);');
  await browser.sleep(2000)
  await siteflow.navigateToLastpage();
  console.log(" modify site value "+internaturevalue)
  await element(by.linkText(internaturevalue)).click();
  await browser.sleep(2000)
});

Then(/^Now intervention nature modify form page should be launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  var actual = await element(by.xpath("//form/div[1]/h3")).getText();
  var expected = labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SaisieDesDonnees[1] + " '" + labelutil.getlabelmethod("NatureProbleme",labelutil.getlabelmethodvthlanguage(preferedlangaue))+"'";
  console.log(actual+" modify inter page "+expected)
  await expect(actual==expected).to.equal(true)
});

Then(/^Now user should modify the values in the existing intervention nature$/, { timeout: 2 * 10000 }, async () => {
  minterventionvalue=await internatureflow.internatureCreation()
})

Then(/^Now verify the modified created record in the intervention nature list page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await siteflow.navigateToLastpage()
  var listcount=await element.all(by.xpath(".//datatable-body-cell[1]")).count();
  var actualsitevalue=await sitepage.Search_Value(listcount).getText();
  console.log(actualsitevalue+ "   compare  "+ minterventionvalue)
 expect(actualsitevalue==minterventionvalue).to.equal(true)
});

Then(/^Click on the status as NO in intervention nature add page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await element(by.xpath("(.//*[@data-off='Yes'])[2]")).click();
});

Then(/^Click on the sort button in the intervention nature page and verify the sort page launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.sleep(3000)
  firstvalueactual = await siteflow.getfirstcoloumnValueInResult("1");
  console.log("value to be" + firstvalueactual)
  await browser.executeScript('window.scrollTo(0,1000);');
  //await sitepage.getBsort().click
  await browser.sleep(3000)
  await element(by.xpath("//button[@id='au_sort_btn']")).click()
  var expected = await element(By.xpath("//form/h3")).getText()
  console.log("value to be data sequencing  " + expected)
  expect(getlabel("OrdonnerDesDonnees", getlabelwithlangaue(preferedlangaue))).to.equal(expected);
});

Then(/^Click on the cancel button and validate the page redirect to intervention nature page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  await element(by.xpath("//*[@class='btn btn-cancel pointer']")).click();
  await browser.sleep(2000)
});
Then(/^System should be navigate from intervention nature page to the data sequencing page and verify the data population$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(1000)
  var expected = await element(By.xpath(".//*[@id='au_select_intervention_nature']/option[1]")).getText()
  expect(firstvalueactual).to.equal(expected);
  await element(by.xpath(".//*[@id='au_save_btn']")).click();
  await browser.sleep(3000)
});

Then(/^Change the values in the sorting selection and verify in the intervention nature list page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  await element(By.xpath(".//*[@id='au_select_intervention_nature']/option[2]")).click()
  await element(by.xpath(".//button[@id='au_up_btn']")).click()
  var beforesortvalue = await element(By.xpath(".//*[@id='au_select_intervention_nature']/option[1]")).getText()
  await element(by.xpath(".//button[@id='au_save_btn']")).click()
  await browser.sleep(6000)
  var aftersortvalue = await siteflow.getfirstcoloumnValueInResult("1");
  await browser.sleep(3000);
  expect(beforesortvalue).to.equal(aftersortvalue); 
});