import { loginPage } from "../pages/loginPage";
import { browser, By, element, protractor, ElementFinder, by } from "protractor"
import { admin_Flow } from "../flow/admin_Flow";
import { adminPage } from "../pages/adminPage";
import { labelUtils, getlabel, getlabelwithlangaue } from "../utls/labelUtil";
import { site_Flow } from "../flow/siteManagement_Flow";
import { sitePage } from "../pages/sitemanagement_page";
import { Alert } from "selenium-webdriver";
import { IntventionLocationMngmnt_Flow } from "../flow/intventionLocationMngmnt_flow";
const { Given, When, Then } = require("cucumber");
const chai = require("chai").use(require("chai-as-promised"));
const expect = chai.expect;
const adminpage: adminPage = new adminPage();
const labelutil: labelUtils = new labelUtils();
const siteflow: site_Flow = new site_Flow();
const sitepage: sitePage = new sitePage()
const interlocationflow: IntventionLocationMngmnt_Flow = new IntventionLocationMngmnt_Flow();

var interlocationvalue: any;
var minterventionvalue:any;
var firstvalueactual:any;
var preferedlangaue:any;

Then(/^Click on the Intervention location sub menu link$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await adminpage.getManagementInterventionLocations().getElement().click();
});

Then(/^Validate all the labels in the Intervention location home page in "(.*?)"$/, { timeout: 2 * 10000 }, async (langauge: any) => {
  await browser.sleep(4000)
  preferedlangaue = labelutil.getlabelmethodvthlanguage(langauge);
  interlocationflow.LabelValidationAll(preferedlangaue);
});

Then(/^click on the Add button in the Intervention location home page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,1000);');
  await element(by.css(".btn-save")).click()
  await browser.sleep(2000)
})

Then(/^verify pop up with message should be in the Intervention location home page and validate it is displayed correctly$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  let ale = await browser.switchTo().alert();
  var poptext = await ale.getText()
  var expected = labelutil.getlabelmethod("SelectDonneesPourAjoutOrdre", labelutil.getlabelmethodvthlanguage(preferedlangaue))
  //expect(poptext==expected).to.equal(true)
  await ale.accept();
})

Then(/^select the site from the site selection in Intervention location page$/, { timeout: 2 * 10000 }, async () => {
  await interlocationflow.selectSiteValue();
})

Then(/^Fill all the mandatory fields in the Intervention location add page$/, { timeout: 2 * 10000 }, async () => {
   interlocationvalue=await interlocationflow.interLocCreation()
})

Then(/^click on the add button in the Intervention location add page$/, { timeout: 2 * 10000 }, async () => {
  await interlocationflow.clickAddButtonInAddForm();
})

Then(/^Now verify the created record in the Intervention location list page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await siteflow.navigateToLastpage()
  var listcount=await element.all(by.xpath(".//datatable-body-cell[1]")).count();
  var actualsitevalue=await sitepage.Search_Value(listcount).getText();
  console.log(actualsitevalue+ "   compare  "+ interlocationvalue)
 //  expect(actualsitevalue).to.eventually.equal(modifyactualvalue)
 expect(actualsitevalue==interlocationvalue).to.equal(true)
});

Then(/^Now Intervention location form page should be launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.executeScript('window.scrollTo(0,1000);');
  var actual = await element(by.xpath("//form-action/div/form/div[1]/h3")).getText();
  console.log(actual+"  commpare "+expected)
  console.log("site  "+labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SaisieDesDonnees[0])
  var expected = labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SaisieDesDonnees[0] + " '" + labelutil.getlabelmethod("LieuIntervention",labelutil.getlabelmethodvthlanguage(preferedlangaue))+"'";
  expect(actual==expected).to.equal(true)
})
Then(/^Click on the cancel button in the Intervention location page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,2000);');
  await sitepage.getABcancel().click();
});

Then(/^Verify whether the Intervention location page is launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,1000);');
  var actual = await element(by.xpath("//intervention-location/div/h3[1]")).getText();
  var expected = labelutil.getlabelmethod("RechercheDesDonnees",labelutil.getlabelmethodvthlanguage(preferedlangaue));
  console.log(actual+" ==== Intervention location "+expected)
  await expect(actual==expected).to.equal(true)
});

Then(/^click on the created Intervention location hyperlink$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,1000);');
  await browser.sleep(2000)
  await siteflow.navigateToLastpage();
  console.log(" modify site value "+interlocationvalue)
  await element(by.linkText(interlocationvalue)).click();
  await browser.sleep(2000)
});

Then(/^Now Intervention location modify form page should be launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  var actual = await element(by.xpath("//form/div[1]/h3")).getText();
  var expected = labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SaisieDesDonnees[1] + " '" + labelutil.getlabelmethod("LieuIntervention",labelutil.getlabelmethodvthlanguage(preferedlangaue))+"'";
  console.log(actual+" modify inter page "+expected)
  await expect(actual==expected).to.equal(true)
});

Then(/^Now user should modify the values in the existing Intervention location$/, { timeout: 2 * 10000 }, async () => {
  minterventionvalue=await interlocationflow.interLocCreation()
})

Then(/^Now verify the modified created record in the Intervention location list page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await siteflow.navigateToLastpage()
  var listcount=await element.all(by.xpath(".//datatable-body-cell[1]")).count();
  var actualsitevalue=await sitepage.Search_Value(listcount).getText();
  console.log(actualsitevalue+ "   compare  "+ minterventionvalue)
 expect(actualsitevalue==minterventionvalue).to.equal(true)
});

Then(/^Click on the status as NO in Intervention location add page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await element(by.xpath("(.//*[@data-off='Yes'])[2]")).click();
});

Then(/^Click on the sort button in the Intervention location page and verify the sort page launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.sleep(3000)
  firstvalueactual = await siteflow.getfirstcoloumnValueInResult("1");
  console.log("value to be" + firstvalueactual)
  await browser.executeScript('window.scrollTo(0,1000);');
  //await sitepage.getBsort().click
  await browser.sleep(3000)
  await element(by.xpath("//button[@id='au_order_btn']")).click()
  var expected = await element(By.xpath("//form/h3")).getText()
  console.log("value to be data sequencing  " + expected)
  expect(getlabel("OrdonnerDesDonnees", getlabelwithlangaue(preferedlangaue))).to.equal(expected);
});

Then(/^Click on the cancel button and validate the page redirect to Intervention location page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  await element(by.xpath("//*[@class='btn btn-cancel pointer']")).click();
  await browser.sleep(2000)
});
Then(/^System should be navigate from Intervention location page to the data sequencing page and verify the data population$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(1000)
  var expected = await element(By.xpath(".//*[@id='au_select_intervention_locations']/option[1]")).getText()
  expect(firstvalueactual).to.equal(expected);
  await element(by.xpath(".//*[@id='au_save_btn']")).click();
  await browser.sleep(3000)
});

Then(/^Change the values in the sorting selection and verify in the Intervention location list page$/, { timeout: 5 * 10000 }, async () => {
  await browser.sleep(3000)
  await element(By.xpath(".//*[@id='au_select_intervention_locations']/option[2]")).click()
  await browser.sleep(3000)
  await element(by.xpath(".//button[@id='au_up_btn']")).click()
  await browser.sleep(3000)
  var beforesortvalue = await element(By.xpath(".//*[@id='au_select_intervention_locations']/option[1]")).getText()
  await browser.sleep(3000)
  await element(by.xpath(".//button[@id='au_save_btn']")).click()
  await browser.sleep(6000)
  var aftersortvalue = await siteflow.getfirstcoloumnValueInResult("1");
  await browser.sleep(3000);
  expect(beforesortvalue).to.equal(aftersortvalue); 
});