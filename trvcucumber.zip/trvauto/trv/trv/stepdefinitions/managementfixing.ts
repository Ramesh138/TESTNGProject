import { loginPage } from "../pages/loginPage";
import { browser, By, element, protractor, ElementFinder, by } from "protractor"
import { admin_Flow } from "../flow/admin_Flow";
import { adminPage } from "../pages/adminPage";
import { labelUtils, getlabel, getlabelwithlangaue } from "../utls/labelUtil";
import { site_Flow } from "../flow/siteManagement_Flow";
import { sitePage } from "../pages/sitemanagement_page";
import { intventionTypeMngmnt_page } from "../pages/intventionTypeMngmnt_Page";
import { Managementoffixing_Flow } from "../flow/managementFixingTime_flow";
import { Alert } from "selenium-webdriver";
const { Given, When, Then } = require("cucumber");
const chai = require("chai").use(require("chai-as-promised"));
const expect = chai.expect;
const adminpage: adminPage = new adminPage();
const labelutil: labelUtils = new labelUtils();
const siteflow: site_Flow = new site_Flow();
const sitepage: sitePage = new sitePage()
const intertypeflow: Managementoffixing_Flow = new Managementoffixing_Flow();

var intertypevalue: any;
var minterventionvalue:any;
var firstvalueactual:any;
var preferedlangaue:any;

Then(/^Click on the Management of fixing time sub menu link$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await adminpage.getManagementFixingTime().getElement().click();
});

Then(/^Validate all the labels in the Management of fixing time home page in "(.*?)"$/, { timeout: 2 * 10000 }, async (langauge: any) => {
  await browser.sleep(4000)
  preferedlangaue = labelutil.getlabelmethodvthlanguage(langauge);
  intertypeflow.LabelValidationAll(preferedlangaue);
});

Then(/^click on the Add button in the Management of fixing time home page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,1000);');
  await element(by.css(".btn-save")).click()
  await browser.sleep(2000)
})

Then(/^verify pop up with message should be in the Management of fixing time home page and validate it is displayed correctly$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  let ale = await browser.switchTo().alert();
  var poptext = await ale.getText()
  var expected = labelutil.getlabelmethod("SelectDonneesPourAjoutOrdre", labelutil.getlabelmethodvthlanguage(preferedlangaue))
  //expect(poptext==expected).to.equal(true)
  await ale.accept();
})

Then(/^select the site from the site selection in Management of fixing time page$/, { timeout: 2 * 10000 }, async () => {
  await intertypeflow.selectSiteValue();
})

Then(/^Fill all the mandatory fields in the Management of fixing time add page$/, { timeout: 2 * 10000 }, async () => {
   intertypevalue=await intertypeflow.fixtimeCreation()
})

Then(/^click on the add button in the Management of fixing time add page$/, { timeout: 2 * 10000 }, async () => {
  await intertypeflow.clickAddButtonInAddForm();
})

Then(/^Now verify the created record in the Management of fixing time list page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await siteflow.navigateToLastpage()
  var listcount=await element.all(by.xpath(".//datatable-body-cell[1]")).count();
  var actualsitevalue=await sitepage.Search_Value(listcount).getText();
  console.log(actualsitevalue+ "   compare  "+ intertypevalue)
 //  expect(actualsitevalue).to.eventually.equal(modifyactualvalue)
 expect(actualsitevalue==intertypevalue).to.equal(true)
});

Then(/^Now Management of fixing time form page should be launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.executeScript('window.scrollTo(0,1000);');
  var actual = await element(by.xpath("//form/div[1]/h3")).getText();
  var expected = labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SaisieDesDonnees[0] + " '" + labelutil.getlabelmethod("fixingTime",labelutil.getlabelmethodvthlanguage(preferedlangaue))+"'";
  console.log(actual+"    ===========  "+expected)
  expect(actual==expected).to.equal(true)
})
Then(/^Click on the cancel button in the Management of fixing time page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,2000);');
  await sitepage.getABcancel().click();
});

Then(/^Verify whether the Management of fixing time page is launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,1000);');
  var actual = await element(by.xpath("//fixing-time/div/h3[1]")).getText();
  var expected = labelutil.getlabelmethod("RechercheDesDonnees",labelutil.getlabelmethodvthlanguage(preferedlangaue));
  console.log(actual+" ==== Management of fixing time "+expected)
  await expect(actual==expected).to.equal(true)
});

Then(/^click on the created Management of fixing time hyperlink$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,1000);');
  await browser.sleep(2000)
  await siteflow.navigateToLastpage();
  console.log(" modify site value "+intertypevalue)
  await element(by.linkText(intertypevalue)).click();
  await browser.sleep(2000)
});

Then(/^Now Management of fixing time modify form page should be launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  var actual = await element(by.xpath("//form/div[1]/h3")).getText();
  var expected = labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SaisieDesDonnees[1] + " '" + labelutil.getlabelmethod("fixingTime",labelutil.getlabelmethodvthlanguage(preferedlangaue))+"'";
  console.log(actual+" modify inter page "+expected)
  await expect(actual==expected).to.equal(true)
});

Then(/^Now user should modify the values in the existing Management of fixing time$/, { timeout: 2 * 10000 }, async () => {
  minterventionvalue=await intertypeflow.fixtimeCreation()
})

Then(/^Now verify the modified created record in the Management of fixing time list page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await siteflow.navigateToLastpage()
  var listcount=await element.all(by.xpath(".//datatable-body-cell[1]")).count();
  var actualsitevalue=await sitepage.Search_Value(listcount).getText();
  console.log(actualsitevalue+ "   compare  "+ minterventionvalue)
  expect(actualsitevalue==minterventionvalue).to.equal(true)
});

Then(/^Click on the status as NO in Management of fixing time add page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await element(by.xpath("(.//*[@data-off='Yes'])[2]")).click();
});

Then(/^Click on the sort button in the Management of fixing time page and verify the sort page launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.sleep(3000)
  firstvalueactual = await siteflow.getfirstcoloumnValueInResult("1");
  console.log("value to be" + firstvalueactual)
  await browser.executeScript('window.scrollTo(0,1000);');
  //await sitepage.getBsort().click
  await browser.sleep(3000)
  await element(by.xpath("//button[@id='au_sort_btn']")).click()
  var expected = await element(By.xpath("//form/h3")).getText()
  console.log("value to be data sequencing  " + expected)
  expect(getlabel("OrdonnerDesDonnees", getlabelwithlangaue(preferedlangaue))).to.equal(expected);
});

Then(/^Click on the cancel button and validate the page redirect to Management of fixing time page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  await element(by.xpath("//*[@class='btn btn-cancel pointer']")).click();
  await browser.sleep(2000)
});
Then(/^System should be navigate from Management of fixing time page to the data sequencing page and verify the data population$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(1000)
  var expected = await element(By.xpath(".//*[@id='au_select_fixing_times']/option[1]")).getText()
  expect(firstvalueactual).to.equal(expected);
  await element(by.xpath(".//*[@id='au_save_btn']")).click();
  await browser.sleep(3000)
});

Then(/^Change the values in the sorting selection and verify in the Management of fixing time list page$/, { timeout: 5 * 10000 }, async () => {
  await browser.sleep(3000)
  await element(By.xpath(".//*[@id='au_select_fixing_times']/option[2]")).click()
  await browser.sleep(3000)
  await element(by.xpath(".//button[@id='au_up_btn']")).click()
  await browser.sleep(3000)
  var beforesortvalue = await element(By.xpath(".//*[@id='au_select_fixing_times']/option[1]")).getText()
  await browser.sleep(3000)
  await element(by.xpath(".//button[@id='au_save_btn']")).click()
  await browser.sleep(6000)
  var aftersortvalue = await siteflow.getfirstcoloumnValueInResult("1");
  await browser.sleep(3000);
  expect(beforesortvalue).to.equal(aftersortvalue); 
});