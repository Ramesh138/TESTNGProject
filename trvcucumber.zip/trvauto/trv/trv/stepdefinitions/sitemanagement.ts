import { loginPage } from "../pages/loginPage";
import { browser, By, element, protractor, ElementFinder, by, WebElement } from "protractor"
import { admin_Flow } from "../flow/admin_Flow";
import { adminPage } from "../pages/adminPage";
import { labelUtils, getlabel, getlabelwithlangaue } from "../utls/labelUtil";
import { site_Flow } from "../flow/siteManagement_Flow";
import { sitePage } from "../pages/sitemanagement_page";

const { Given, When, Then } = require("cucumber");
const chai = require("chai").use(require("chai-as-promised"));
const expect = chai.expect;
const loginpage: loginPage = new loginPage();
const adminflow: admin_Flow = new admin_Flow();
const adminpage: adminPage = new adminPage();
const labelutil: labelUtils = new labelUtils();
const siteflow: site_Flow = new site_Flow();
const sitepage: sitePage = new sitePage()

var ActualnameHeader: any;
var ActualstatusHeader: any;
var Actualorderheaer: any;
var firstvalueactual: any;
var modifyactualvalue: any;

var preferedlangaue: any;

var sitevalue: any;
Given(/^Navigate to the Admistration page in "(.*?)"$/, { timeout: 2 * 10000 }, async (langauge) => {
  await browser.sleep(2000)
  preferedlangaue = labelutil.getlabelmethodvthlanguage(langauge);
  return loginpage.Adminstartion.click()
});

When(/^Adminstration page is launched in "(.*?)"$/, { timeout: 2 * 10000 }, async (langauge) => {
  await browser.sleep(6000)
  preferedlangaue = labelutil.getlabelmethodvthlanguage(langauge);
  var value = await adminpage.SiteManagement.getText();
  var actual = await adminpage.SiteManagement.getText()
  var expected = await labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SousTitre["administrationgestionSiteChoix"]
  // await expect().to.eventually.equal(labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SousTitre["administrationgestionSiteChoix"])
  console.log(actual + "  ffvdfv  " + expected)
  expect(actual == expected).to.equal(true)
});


Then(/^Verify Whether Adminstration page is launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(4000)
  var actual = await adminpage.SiteManagement.getText()
  var expected = await labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SousTitre["administrationgestionSiteChoix"]
  await expect(actual == expected).to.equal(true)
});

Then(/^System should be redirected to the Adminstration Homepage$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(4000)
  var actual = await adminpage.SiteManagement.getText()
  var expected = await labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SousTitre["administrationgestionSiteChoix"]
  console.log(actual + " expected as " + expected)
  await expect(actual == expected).to.equal(true)
});

Then(/^Validate all the labels in the Adminstration Home Page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  adminflow.LabelValidation_Adminstration_Homepage()
});

Then(/^Click on the site management sub menu link$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  return await adminflow.clickkBSiteManagement();
});


Then(/^Validate all the labels in the site management Home page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(4000)
  siteflow.LabelValidation_Sitemanagement_HomePage(preferedlangaue)
});

Given(/^user click on the cancel button$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(6000)
  siteflow.clickCancel()
});


Given(/^Click on the sitemanagement sub menu link$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  return adminpage.bt_SiteManagement.click()
});

When(/^Click on the Sort button and validating the sort operations$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  siteflow.sortcancelopertion()
});

When(/^user click on the Sort button and verify the sort page launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  firstvalueactual = await siteflow.getfirstcoloumnValueInResult("1");
  console.log("value to be" + firstvalueactual)
  await browser.executeScript('window.scrollTo(0,1000);');
  await browser.sleep(3000)
  await element(by.xpath("//*[@id='au_order_btn']")).click()
  var expected = await element(By.xpath("//form/h3")).getText()
  console.log("value to be data sequencing  " + expected)
  expect(getlabel("OrdonnerDesDonnees", getlabelwithlangaue(preferedlangaue))).to.equal(expected);
});

Then(/^Verify whether System should be Navigate to the data sequencing page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  var expected = await element(By.xpath("//form/h3")).getText()
  console.log("value to be data sequencing  " + expected)
  expect(getlabel("OrdonnerDesDonnees", getlabelwithlangaue(preferedlangaue))).to.equal(expected);
});
Then(/^System should be Navigate to the data sequencing page and verify the data population$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(1000)
  var expected = await element(By.xpath(".//*[@id='au_select_sites']/option[1]")).getText()
  expect(firstvalueactual).to.equal(expected);
  await sitepage.SBadd.click();
  await browser.sleep(3000)
});

Then(/^Change the values in the sorting selection and verify the data modifications in the sorting order$/, { timeout: 2 * 50000 }, async () => {
  await browser.sleep(3000)
  await element(By.xpath(".//*[@id='au_select_sites']/option[2]")).click()
  await browser.sleep(3000)
  await element(by.xpath(".//button[@id='au_up_btn']")).click()
  await browser.sleep(3000)
  var beforesortvalue = await element(By.xpath(".//*[@id='au_select_sites']/option[1]")).getText()
  await browser.sleep(3000)
  await element(by.xpath(".//button[@id='au_save_btn']")).click()
  await browser.sleep(10000)
  var aftersortvalue = await siteflow.getfirstcoloumnValueInResult("1");
  expect(beforesortvalue==aftersortvalue).to.equal(true); 
  await browser.sleep(3000)
});

Then(/^Click on the Cancel button and  validate the page redirect to Sitemanagement page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  siteflow.clickCancelButton()
  await browser.sleep(2000)
  siteflow.verifySortHomePage(preferedlangaue)
});


When(/^User Select on the Active radio button$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  siteflow.clickActive()
});

Then(/^verfying the data displaying  in the datatable grid as active$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  siteflow.statusVerifications(labelutil.getlabelmethod("Actif", labelutil.getlabelmethodvthlanguage(preferedlangaue)));
});

When(/^User click on the InActive radio Button$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  await browser.executeScript('window.scrollTo(1000,0);');
  siteflow.clickInActive()
});

Then(/^Page should be refreshed and displayed only INactive ststus records in the result grid$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  siteflow.statusVerifications(labelutil.getlabelmethod("Inactif", labelutil.getlabelmethodvthlanguage(preferedlangaue)));
});

Then(/^Verify in the result grid  whether new site is created or not$/, { timeout: 2 * 10000 }, async () => {
  siteflow.navigateToLastpage()
  siteflow.createrecordVerification()
})

Then(/^INActive button should be Selected$/, { timeout: 2 * 10000 }, async () => {
})

Then(/^Page should be refreshed and displayed only active status records in the result grid$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  siteflow.statusVerifications(labelutil.getlabelmethod("Actif", labelutil.getlabelmethodvthlanguage(preferedlangaue)));
})

Then(/^Active button should be Selected$/, { timeout: 2 * 10000 }, async () => {
});

When(/^user click on the name header then data should be sorted$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  ActualnameHeader = await siteflow.getfirstcoloumnValueInResult("1");
  await sitepage.THname.click("click on the name header")
  await browser.sleep(3000)
});

Then(/^verifying the name data is verified$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  var actual = await siteflow.getfirstcoloumnValueInResult("1");
  console.log(actual + "=" + ActualnameHeader)
  // if (ActualnameHeader != actual) {
  //   expect(ActualnameHeader==actual).to.equal(false);
  //   console.log("validation done succesfully")
  // } else {
  //   throw new Error("Sorting Not happend properly");
  // }
});

When(/^user click on the Order header then data should be sorted$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  Actualorderheaer = await siteflow.getfirstcoloumnValueOfOrderInResult();
  sitepage.THorder.click("click on the Order header")

});
Then(/^verifying the Order header data is sorted$/, { timeout: 2 * 10000 }, async () => {
  var actual = await siteflow.getfirstcoloumnValueOfOrderInResult();
  console.log(Actualorderheaer + " =========" + actual)
  // if (Actualorderheaer != actual) {
  //   expect(Actualorderheaer==actual).to.equal(false);
  //   console.log("validation done succesfully")
  // } else {
  //   throw new Error("Sorting Not happend properly");
  // }
  await browser.sleep(5000)
});
When(/^user click on the status header then data should be sorted$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(3000)
  sitepage.getRBall().click
  ActualstatusHeader = await siteflow.getfirstcoloumnValueOfStatusInResult()
  sitepage.THstatus.click("click on the Status header")
});
Then(/^verifying the status header data is sorted$/, { timeout: 2 * 10000 }, async () => {
  var actual = await siteflow.getfirstcoloumnValueOfStatusInResult()
  console.log(ActualstatusHeader + " =========" + actual)
  if (ActualstatusHeader != actual) {
    console.log("validation done succesfully")
  } else {
    throw new Error("Sorting Not happend properly");
  }
});

Given(/^click on the Add button$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,1000);');
  await element(by.css(".btn-save")).click()
  await browser.sleep(2000)
})

When(/^Fill all the mandatory fields in the Add page$/, { timeout: 5 * 10000 }, async () => {
  var site = await siteflow.siteCreation()
  sitevalue = site;
})

Then(/^click on the save Button in the add form$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000);
  await siteflow.clickABadd().then(function () {
    console.log("click on the add button ");
  })
})

Then(/^verify page redirected to the sitemanagement Homepage$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  var actual = await sitepage.Ldatasearch.getText()
  var expected = await labelutil.getlabelmethod("RechercheDesDonnees", labelutil.getlabelmethodvthlanguage(preferedlangaue))
  await expect(actual == expected).to.equal(true)
});

Then(/^verify the created record in the Sitemanagement reslt grid page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await siteflow.navigateToLastpage()
  await browser.sleep(2000)
  var listcount = await element.all(by.xpath(".//datatable-body-cell[1]")).count();
  await browser.sleep(2000)
  console.log(" size value " + listcount)
  var actualsitevalue = await sitepage.Search_Value(listcount).getText();
  console.log(actualsitevalue + "   compare  " + sitevalue)
  await expect(actualsitevalue == sitevalue).to.equal(true)
  await browser.sleep(2000)
});

Then(/^Verify Whether Sitemanagement Search page is launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  siteflow.LabelValidation(sitepage.getPageHeader().getElement(), "RechercheDesDonnees", preferedlangaue)
});

Then(/^Verify whether Sitemanagement Creation page is launched$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(1000,0);');
  var actual = await element(by.xpath("//form/div[1]/h3")).getText();
  var expected = labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SaisieDesDonnees[0] + " '" + labelutil.getlabelmethod("site", labelutil.getlabelmethodvthlanguage(preferedlangaue))+"'";
 await expect(actual==expected).to.equal(true)
});


Then(/^Click on the Cancel button in the Sitemanagement Creation page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,2000);');
  await sitepage.getABcancel().click();
});

Then(/^click on the created site hyperlink$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await browser.executeScript('window.scrollTo(0,2000);');
  await browser.sleep(2000)
  console.log(" modify site value " + sitevalue)
  await element(by.linkText(sitevalue)).click();
  await browser.sleep(2000)
});

Then(/^Verify the modify page with header label$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  var expected = labelutil.getlabelvthValue(labelutil.getlabelmethodvthlanguage(preferedlangaue)).SaisieDesDonnees[1] + " '" + await labelutil.getlabelmethod("site", labelutil.getlabelmethodvthlanguage(preferedlangaue)) + "'";
  var actual = await sitepage.Lmodifycreation.getText();
  await expect(actual==expected).to.equal(true)


});
Then(/^user modified  some of the fields$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  modifyactualvalue = await siteflow.siteCreation();
});

Then(/^Now verify the modified created when modified fields are modified succesfuly$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await siteflow.navigateToLastpage()
  var listcount = await element.all(by.xpath(".//datatable-body-cell[1]")).count();
  var actualsitevalue = await sitepage.Search_Value(listcount).getText();
  console.log(actualsitevalue + "   compare  " + modifyactualvalue)
  expect(actualsitevalue == modifyactualvalue).to.equal(true)
});

Then(/^Click on the status as NO$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  await element(by.xpath("(.//*[@data-off='Yes'])[2]")).click();
});

Then(/^Verify the status of new record should be inactive$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  var listcount = await element.all(by.xpath(".//datatable-body-cell[1]")).count();
  var actualsitevalue = await sitepage.Search_ActiveValue(listcount).getText();
  console.log(actualsitevalue + "   compare  " + labelutil.getlabelmethod("Inactif", labelutil.getlabelmethodvthlanguage(preferedlangaue)))
  var expected = labelutil.getlabelmethod("Inactif", labelutil.getlabelmethodvthlanguage(preferedlangaue))
  expect(actualsitevalue == expected).to.equal(true)
});
