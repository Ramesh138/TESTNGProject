import { loginPage } from "../pages/loginPage";
import {browser,protractor} from "protractor"
import { labelUtils } from "../utls/labelUtil";
import { adminPage } from "../pages/adminPage";
import { admin_Flow } from "../flow/admin_Flow";
import { site_Flow } from "../flow/siteManagement_Flow";
import { execFile } from "child_process";
import { myRequest_Flow } from "../flow/myRequest_Flow";
import { CutomLogger } from '../utls/customlogger';
import { exception } from "console";
import { config } from "../config/conf";


const { Given, When,Then } = require("cucumber");
const chai = require("chai").use(require("chai-as-promised"));
const expect = chai.expect;
const loginpage:loginPage =new loginPage();
const labelutil:labelUtils=new labelUtils();
const adminflow:admin_Flow=new admin_Flow()
const siteflow: site_Flow=new site_Flow()
const myrequestflow: myRequest_Flow=new myRequest_Flow()
browser.ignoreSynchronization = false;


Given(/^Launch the Travux Application in "(.*?)"$/, { timeout: 2 * 10000 }, async (lang:any) => {

  try {
    await browser.sleep(2000)
    console.log(" lang will be "+lang)
    if(lang=="English"){
      await browser.sleep(2000)
      await browser.executeScript('window.scrollTo(1000,0);');
    console.log(" lang will be "+lang)
      await loginpage.language_en.click() 
    }else if(lang=="French"){
      await browser.executeScript('window.scrollTo(1000,0);');
      await loginpage.language_fr.click() 
      await browser.sleep(2000)
    }else if(lang=="Portuguse"){
      await browser.executeScript('window.scrollTo(1000,0);');
      await loginpage.language_po.click() 
      await browser.sleep(2000)
    }else if(lang=="Romania"){
      await browser.executeScript('window.scrollTo(1000,0);');
      await loginpage.language_ro.click() 
    }else if(lang=="Spanish"){
      await browser.executeScript('window.scrollTo(1000,0);');
      await loginpage.language_es.click() 
      await browser.sleep(2000)
    }else if(lang=="Turkish"){
      await browser.executeScript('window.scrollTo(1000,0);');
      await loginpage.language_tu.click()
      await browser.sleep(2000) 
    }
    
    
    CutomLogger.logger.log('info', "Step 1: Lauching the Travaux application URL");
  } catch (error) {
    CutomLogger.logger.error("Error in  Step 1: Lauching the Travaux application URL");
  }
});

When(/^Verify the Travux New Request Home is displayed$/, { timeout: 2 * 10000 }, async () => {
  await browser.wait(protractor.ExpectedConditions.visibilityOf(loginpage.M_NewRequest), 30000)
  await browser.sleep(1000)
   let text= await loginpage.M_NewRequest.getText()
   if(text==(labelutil.getlabelvthValue("English").SousTitre.demandesAfficheDemande).toUpperCase()){
    console.log(text+"  is succesfully match with the "+labelutil.getlabelvthValue("English").SousTitre.demandesAfficheDemande.toUpperCase())
   }else{
     throw new Error(text+"  is not match with the "+labelutil.getlabelvthValue("English").SousTitre.demandesAfficheDemande.toUpperCase())
   }
});

Then(/^Close the footer notification$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
  if((await loginpage.closebutton.getWebElement()).isDisplayed){
    await loginpage.closebutton.click() 
    console.log(" popo is already Open ")
  }else{
    console.log(" popo is already closed ")
  }
 
});

Given(/^Navigate to Adminstration menu page$/, { timeout: 2 * 10000 }, async () => {
  await browser.sleep(2000)
 await browser.get(config.baseUrl);
 await browser.sleep(6000)
});

