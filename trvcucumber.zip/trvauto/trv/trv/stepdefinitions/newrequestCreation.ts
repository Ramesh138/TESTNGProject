import { loginPage } from "../pages/loginPage";
import { browser, protractor, ElementFinder, by } from "protractor"
import { labelUtils } from "../utls/labelUtil";
import { newRequest_Flow } from "../flow/newRequest_flow";
import { newRequest_Page } from "../pages/newRequest_Page";
import { myRequest_Page } from "../pages/myRequest_page";
import { myRequest_Flow } from "../flow/myRequest_Flow";
import { dbexecutable } from "../dbexecutable";
import mailflow from "../utls/mailconfiguration";


const { Given, When, Then,AND } = require("cucumber");
const chai = require("chai").use(require("chai-as-promised"));
const loginpage: loginPage = new loginPage();
const newrequestflow: newRequest_Flow = new newRequest_Flow()
const newrequestpage: newRequest_Page = new newRequest_Page()
const myrequestflow: myRequest_Flow = new myRequest_Flow();
let data: any;

When(/^Navigate to New Request Form Page$/, async () => {
  browser.ignoreSynchronization = true;
  await browser.wait(protractor.ExpectedConditions.elementToBeClickable(loginpage.M_NewRequest), 30000)
  loginpage.M_NewRequest.click();
  //console.log("Click on the New Request menu tab ");
});

Then(/^change  the author of requestor as "(.*?)"$/, async (ipn) => {
  await browser.sleep(2000)
  newrequestflow.change_author_requestor(ipn)
});

Then(/^Fill the  site as "(.*?)" in Site dropdown$/, async (site) => {
  browser.ignoreSynchronization = true;
  await browser.wait(protractor.ExpectedConditions.elementToBeClickable(loginpage.site), 30000)
  loginpage.elementclickaction(loginpage.site.getWebElement());
  return newrequestpage.IL_d_Site.clickOnMatchingText(site);
});

Then(/^Fill the Intervention Location  as "(.*?)" in the dropdown$/, async (interventionLocation) => {
  browser.executeScript('window.scrollTo(0,400);').then(function () {
  })
  await browser.wait(protractor.ExpectedConditions.elementToBeClickable(loginpage.interventionlocation), 30000)
  loginpage.elementclickaction(loginpage.interventionlocation.getWebElement());
  await browser.sleep(2000);
  return newrequestpage.IL_d_InterventionLocation.clickOnMatchingText(interventionLocation)
});
Then(/^Fill the Specify the location  as "(.*?)" in the dropdown$/, async (SpecificLocation) => {
  browser.ignoreSynchronization = true;

  await browser.wait(protractor.ExpectedConditions.elementToBeClickable(loginpage.IL_D_SpecifyTheLocation), 30000)
  loginpage.elementclickaction(loginpage.IL_D_SpecifyTheLocation.getWebElement());
  await browser.sleep(2000);
  return newrequestpage.IL_d_SpecifyTheLocation.clickOnMatchingText(SpecificLocation);
});
Then(/^Fill the Specify the location Description$/, async () => {
  await browser.wait(protractor.ExpectedConditions.elementToBeClickable(loginpage.IL_T_SpecifyTheLocation), 30000)
  await browser.sleep(2000);
  data = "SpecifiedLocation_" + newrequestflow.randomString(6)
  browser.sleep(2000).then(() => {
    newrequestpage.set_IL_T_SpecifyTheLocation(data)
  })
  console.log(" data "+data)
  return data
});

Then(/^Fill the Intervention Type dropdown$/,{ timeout: 2 * 3000 }, async () => {
  await browser.sleep(4000);
  newrequestpage.NI_d_Intervention_type.clickByIndex(1)
});

Then(/^Fill the Intervention nature as "(.*?)" in the  dropdown$/,{ timeout: 2 * 3000 }, async (InterventionNature) => {
  await browser.wait(protractor.ExpectedConditions.elementToBeClickable(loginpage.interventionNature), 30000)
  await browser.sleep(3000);
  newrequestpage.NI_d_Intervention_nature.clickOnMatchingText(InterventionNature)
});


Then(/^Fill the Level-2 intervention as "(.*?)" in the dropdown$/,{ timeout: 2 * 3000 }, async (L2Intervention) => {
  await browser.wait(protractor.ExpectedConditions.elementToBeClickable(loginpage.L2_intervention), 30000)
  await browser.sleep(3000);
  newrequestpage.NI_d_Level_2_intervention.clickOnMatchingText(L2Intervention)

});

Then(/^Fill the Description  text field$/,{ timeout: 2 * 3000 }, async () => {
  await browser.sleep(3000);
  newrequestpage.NI_T_Description.click()
  newrequestpage.set_NI_T_Description("Description for Testing test case")
});
Then(/^Providing Required data to additional Information$/,{ timeout: 2 * 3000 }, async () => {
  await browser.sleep(3000);
  browser.executeScript('window.scrollTo(0,2000);').then(function () {
  })
  newrequestflow.Data_provide_to_AdditionalInformation()
})



Then(/^Click on the Save button$/,{ timeout: 2 * 3000 }, async () => {
  await browser.wait(protractor.ExpectedConditions.elementToBeClickable(loginpage.L2_intervention), 30000)
  await browser.sleep(3000);
  return newrequestpage.BSaveBtn.click()
});

Then(/^Verifying the title of the page$/,{ timeout: 2 * 3000 }, async () => {
  await browser.sleep(3000);
  myrequestflow.verifyMyRequestPage()
  //console.log("My request page is verified")
})

Then(/^Verify Whether the new record is succesfully updated in the Database$/,{ timeout: 2 * 3000 }, async () => {
  await browser.sleep(3000);
  console.log("spec value to be "+data)
 await myrequestflow.DB_verification_for_count1("SpecifiedLocation_PJSMZA");
 // dbexecutable();
 await mailflow.sendReportMail();
  
})