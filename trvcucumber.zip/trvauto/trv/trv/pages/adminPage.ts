import { textbox, button, link, label } from "../smartest/custom_elements/smartLocators";
import { WebdriverWebElement, ElementFinder } from 'protractor/built/element';
import { waitForVisibilityOf } from "../smartest/actions/waitFor";

export class adminPage {

    //Elements displayed in PUMMP login page
      SiteManagement = label.byXpath(".//*[@id='au_site']")
      bt_SiteManagement = button.byXpath(".//*[@id='au_site']")
      AdditionalInformationSite = label.byXpath(".//*[@id='au_site_info']")
      InterventionTypesManagement =  label.byXpath(".//*[@id='au_intervention_type']")

      bt_InterventionTypesManagement =  button.byXpath(".//*[@id='au_intervention_type']")
    
      InterventionNaturesManagement =  label.byXpath(".//*[@id='au_intervention_nature']")
      ManagementSubInterventions =  label.byXpath(".//*[@id='au_sub_intervention']")
      ManagementInterventionLocations = label.byXpath(".//*[@id='au_level2_intervention']")

    
      ManagementLevels = label.byXpath(".//*[@id='au_intervention_location']")
      ManagementResponseTime =  label.byXpath(".//*[@id='au_response_time']")
      ManagementFixingTime =  label.byXpath(".//*[@id='au_fixing_time']")

    
      ManagementInterveningCompanies = label.byXpath(".//*[@id='au_companies']")
      UserManagement     = label.byXpath(".//*[@id='au_user']")
      CommunicationManagement =  label.byXpath(".//*[@id='au_communication']")
      Adminstartion =button.byXpath(".//*[@id='au_admin']")

     //To get value to Adminstation title Label
    public  getAdminstartionMBtn() {
        return this.Adminstartion
    }

    public  getSiteManagement(){
        return this.SiteManagement.click("click on the Site Management Button ")
    }

    public  getLSiteManagement(){
        return this.SiteManagement
    }

    public  getBSiteManagement(){
        return this.bt_SiteManagement
    }
    public  getAdditionalInformationSite(){
        return this.AdditionalInformationSite
    }
    public  getInterventionTypesManagement(){
        return this.InterventionTypesManagement
    }

    public  getInterventionBTypesManagement(){
        return this.bt_InterventionTypesManagement
    }
    public  getInterventionNaturesManagement(){
        return this.InterventionNaturesManagement
    }
    public  getManagementSubInterventions(){
        return this.ManagementSubInterventions
    }
    public  getManagementInterventionLocations(){
        return this.ManagementInterventionLocations
    }
    public  getManagementLevels(){
        return this.ManagementLevels
    }
    public  getManagementResponseTime(){
        return this.ManagementResponseTime
    }
    public  getManagementFixingTime(){
        return this.ManagementFixingTime
    }
    public  getManagementInterveningCompanies(){
        return this.ManagementInterveningCompanies
    }
    public  getUserManagement(){
        return this.UserManagement
    }
    public  getCommunicationManagement(){
        return this.CommunicationManagement
    }
         

}