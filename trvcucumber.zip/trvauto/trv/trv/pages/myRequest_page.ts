import { textbox, button, link, label, radiobutton, grid, image } from "../smartest/custom_elements/smartLocators";
import { WebdriverWebElement, ElementFinder } from 'protractor/built/element';

import { browser, element, by } from "protractor";


export class myRequest_Page {
	// title of the page as "T"
	public T_ListOfMyRequest = label.byXpath("//h3[@class ='title m-0']")
	//table title coloums as "TT"
	public TT_sheetName = label.byXpath("//datatable-header-cell[1]/div/div/div")
	public TT_contractManager = label.byXpath("//datatable-header-cell[2]/div/div/div")
	public TT_InterventionLocation = label.byXpath("//datatable-header-cell[3]/div/div/div")
	public TT_Description = label.byXpath("//datatable-header-cell[4]/div/div/div")
	public TT_Status = label.byXpath("//datatable-header-cell[5]/div/div/div")
	public first_sheet_number = label.byXpath("//a[@class ='pointer'][1]");
	public page_count = label.byXpath("//*[@class ='page-count']");

	// table coloums verification
	public get_TT_sheetName() {
		return this.TT_sheetName
	}
	public get_TT_contractManager() {
		return this.TT_contractManager
	}
	public get_TT_InterventionLocation() {
		return this.TT_InterventionLocation
	}
	public get_TT_Description() {
		return this.TT_Description
	}
	public get_TT_Status() {
		return this.TT_Status
	}
	public get_T_ListOfMyRequest() {
		return this.T_ListOfMyRequest
	}
	public get_sheet_number() {
		return this.first_sheet_number
	}
	public get_page_count() {
		return this.page_count
	}

}