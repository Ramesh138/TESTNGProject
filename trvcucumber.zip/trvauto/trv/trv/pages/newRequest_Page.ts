import { WebdriverWebElement, ElementFinder ,} from 'protractor/built/element';
import { browser, element, by } from "protractor";
import{protractor} from 'protractor'
import { textbox, button, link, label, radiobutton, grid, image } from "../smartest/custom_elements/smartLocators";


export class newRequest_Page {
	//d = dropdown , T = textbox and B= button
		
	//intervention location page objects as "IL"
    	//intervention location page objects as "IL"

        public IL_d_Site = grid.byXpath(".//*[@formcontrolname='par_site']/option")
        public IL_d_InterventionLocation = grid.byXpath(".//*[@formcontrolname='parIdLieuxIntervention']/option")
        public IL_d_SpecifyTheLocation = grid.byXpath(".//*[@formcontrolname='parIdSousLieuxIntervention']/option")
        public IL_T_SpecifyTheLocation =textbox.byXpath(".//*[@formcontrolname='parPrecisionLieu']")
    
        
        //Nature of the intervention page objects as "NI"
        public NI_d_Intervention_type = grid.byXpath(".//*[@formcontrolname='parIdTypeProbleme']/option")
        public NI_d_Intervention_nature =grid.byXpath(".//*[@formcontrolname='parIdProbleme']/option")
        public NI_d_Level_2_intervention = grid.byXpath(".//*[@formcontrolname='parIdProbleme2']/option")
        public NI_T_Description = textbox.byXpath(".//*[@formcontrolname='parDesignation']")
        
        //Additional informatipon
        public d_Imobilization = grid.byXpath(".//*[@formcontrolname='parPanneBloquante']/option")
        public T_Imobilization = textbox.byXpath(".//*[@formcontrolname='parRaisonPanneBloquante']")
    
       //save button details
        public BSaveBtn = button.byXpath("/html/body/app-root/app-root/app-full-layout/div/div/ng-component/div/div/form/div[7]/div/button[1]")
        public BCancelBtn = button.byXpath("//button[contains(.,'Cancel')]")
    
        //authore change details
        public B_clear_requestor_details = button.byXpath("//img[@class ='pt-5 pointer'][1]")
        public B_search_requestor_details = button.byXpath("//img[@class ='pt-5 pointer'][2]")
        public T_IPN_requestor_details = textbox.byXpath("//input[@placeholder ='IPN']")
        
	
        public select_IL_d_SpecifyTheLocation1() {
            this.IL_d_SpecifyTheLocation
        }
    
        public async select_IL_d_Site(dvalue: any) {
           // await browser.wait(protractor.ExpectedConditions.visibilityOf(this.IL_d_Site), 30000)
           browser.ignoreSynchronization = false;
           await browser.waitForAngular(" waiting for angular")
           return this.IL_d_Site.clickOnMatchingText(dvalue)
        }
    
        public select_IL_d_InterventionLocation(dvalue: any) {
            browser.sleep(1000).then(() => {
                this.IL_d_InterventionLocation.clickOnMatchingText(dvalue)
            })
        }
    
        public select_IL_d_SpecifyTheLocation(dvalue: any) {
            browser.sleep(1000).then(() => {
                //NewRequest_Page.IL_d_SpecifyTheLocation.clickOnMatchingText(dvalue)
                this.IL_d_SpecifyTheLocation.clickByIndex(1)
            })
        }
    
        public set_IL_T_SpecifyTheLocation(value: any) {
            this.IL_T_SpecifyTheLocation.waitForVisibility()
            this.IL_T_SpecifyTheLocation.click()
            return this.IL_T_SpecifyTheLocation.clickSend(value, value + " is entered textbox")
        }
    
        public select_NI_d_Intervention_type(dvalue: any) {
            browser.sleep(1000).then(() => {
                this.NI_d_Intervention_type.clickOnMatchingText(dvalue)
            })
        }
    
        public select_NI_d_Intervention_nature(dvalue: any) {
            browser.sleep(1000).then(() => {
                this.NI_d_Intervention_nature.clickByIndex(1)
                //clickOnMatchingText(dvalue)
            })
        }
    
        public select_NI_d_Level_2_intervention(dvalue: any) {
            browser.sleep(1000).then(() => {
                this.NI_d_Level_2_intervention.clickByIndex(1)
                //clickOnMatchingText(dvalue)
            })
        }
    
        public set_NI_T_Description(value: string) {
            this.NI_T_Description.waitForVisibility()
            return this.NI_T_Description.clickSend(value, value + " is entered textbox")
        }
    
    
        public select_d_Imobilization(dvalue: any) {
            browser.sleep(3000).then(() => {
                this.d_Imobilization.clickOnMatchingText(dvalue)
            })
        }
    
        public set_T_Imobilization(value: string) {
            this.T_Imobilization.waitForVisibility()
            return this.T_Imobilization.clickSend(value, value + " is entered textbox")
        }
        /**
         * click add method
         */
    
        public clickAdd() {
            browser.sleep(1000).then(() => {
                this.BSaveBtn.waitForClickable().then(async () => {
                    this.BSaveBtn.click("click on the Save button")
                })
            })
        }
    
        public clickCancel() {
            browser.sleep(1000).then(() => {
                this.BCancelBtn.waitForClickable().then(async () => {
                    this.BCancelBtn.click("click on the Cancel user button")
                })
            })
        }
    
       //requestor change
    
        public async click_clean_author_details() {
            await browser.sleep(2000)
            browser.sleep(1000).then(() => {
                this.B_clear_requestor_details.waitForClickable().then(async () => {
                    this.B_clear_requestor_details.click("click on clean button")
                })
            })
        }
        
        public async click_search_author_details() {
            await browser.sleep(2000)
            browser.sleep(1000).then(() => {
                this.B_search_requestor_details.waitForClickable().then(async () => {
                    this.B_search_requestor_details.click("click on clean button")
                })
            })
        }
    
        public async set_T_IPN_requestor_details(value: string) {
            this.T_IPN_requestor_details.waitForVisibility()
            await browser.sleep(2000)
            return this.T_IPN_requestor_details.clickSend(value, value + " is entered textbox")
        } 
    }