import { WebdriverWebElement, ElementFinder } from 'protractor/built/element';
import { $, element, by,browser } from 'protractor';
export class loginPage {

    //Elements displayed in PUMMP login page
    public language_fr: ElementFinder;
    public language_en: ElementFinder;
    public language_es: ElementFinder;
    public language_ro: ElementFinder;
    public language_ru: ElementFinder;
    public language_br: ElementFinder;
    public language_tu: ElementFinder;
    public language_po:ElementFinder;

    public logInBtn: ElementFinder;
    public iLostPwdLnk: ElementFinder;
    public loginErrorMsg: ElementFinder;
    public successLoginElmt: ElementFinder;
    public Adminstartion: ElementFinder;
    public Mallocationbtn: ElementFinder;
    public Mprocessingbtn: ElementFinder;
    public M_Indicators: ElementFinder;
    public M_NewRequest: ElementFinder;
    public M_MyRequest: ElementFinder;
    public closebutton: ElementFinder;
    public site: ElementFinder;
    public interventionlocation:ElementFinder;
    public IL_T_SpecifyTheLocation:ElementFinder;
    public IL_D_SpecifyTheLocation:ElementFinder;
    public interventionNature:ElementFinder;
    public L2_intervention:ElementFinder;
    public newDescription:ElementFinder;
    
    
    constructor() {
        //Elements displayed in PUMMP login page
        this.newDescription=element(by.xpath(".//*[@formcontrolname='parDesignation']"))
        this.site = element(by.xpath(".//*[@formcontrolname='par_site']"))
        this.IL_T_SpecifyTheLocation=element(by.xpath(".//*[@formcontrolname='parPrecisionLieu']"))
        this.IL_D_SpecifyTheLocation=element(by.xpath(".//*[@formcontrolname='parIdSousLieuxIntervention']"))
        this.interventionlocation = element(by.xpath(".//*[@formcontrolname='parIdLieuxIntervention']"))
        this.interventionNature = element(by.xpath(".//*[@formcontrolname='parIdLieuxIntervention']"))
        this.L2_intervention=element(by.xpath(".//*[@formcontrolname='parIdProbleme2']"))
        this.language_fr = element(by.xpath("//*[@id='au_fr_lang']"))
        this.language_en = element(by.xpath("//*[@id='au_en_lang']"))
        this.language_es = element(by.xpath("//*[@id='au_es_lang']"))
        this.language_ro = element(by.xpath("//*[@id='au_ro_lang']"))
        this.language_ru = element(by.xpath("//*[@id='au_ru_lang']"))
        this.language_br = element(by.xpath("//*[@id='au_br_lang']"))
        this.language_tu = element(by.xpath("//*[@id='au_tu_lang']"))
        this.language_po=element(by.xpath("//*[@id='au_po_lang']"))
   
        this.logInBtn = element(by.id("LOGIN"))
        this.iLostPwdLnk = element(by.id("lostPwd"))
        this.loginErrorMsg = element(by.id("AUTH_ERR"))
        //successLoginElmt = element(by.classname("ng-pristine ng-valid ng-touched"))
        this.Adminstartion = element(by.xpath(".//*[@id='au_admin']"))
        this.Mallocationbtn = element(by.id("au_allocate"))
        this.Mprocessingbtn = element(by.id("au_process"))
        this.M_Indicators = element(by.id("au_indicator"))
        this.M_NewRequest = element(by.id("au_new_request"))
        this.M_MyRequest = element(by.id("au_my_request"))
        this.closebutton=element(by.xpath("/html/body/app-root/app-root/app-full-layout/app-footer/footer/div[1]/div[1]/div/button/span"))
   }

   public  elementclickaction(webelementvalue: WebdriverWebElement) {
    webelementvalue.isDisplayed().then(async function (isVisible: any) {
      if (isVisible) {
        webelementvalue.getText().then(function(lable){
          //console.log("click on the " +  lable + "  link ")
            webelementvalue.click()
            //console.log("click on the link ")
        })
      } else {
        throw new Error("Locator is not visible. ")
      }
    });
   }
    get_indicators() {
        return this.M_Indicators
    }

    get_Myrequest() {
        return this.M_MyRequest
    }
    commonElementverification(elementFinderBy: ElementFinder) {

        elementFinderBy.isDisplayed().then((flag: boolean) => {
            if (flag) {
                //console.log("Element is displayed");
            } else {
                throw new Error("Element is not displaying in the home page");
            }
        })
    }
    getMallocationbtn() {
        return this.Mallocationbtn
    }

    getMNewRequestbtn() {
        return this.M_NewRequest
    }

    getMprocessingbtn() {
        return this.Mprocessingbtn
    }



    getLanguagefr() {
        this.language_fr.isDisplayed().then(async function (isVisible) {
            if (isVisible) {
                this.language_fr.waitForVisibility().then(function () {
                    this.language_fr.click("Click on the French icon")
                })
            } else {
                throw new Error("Locator is not visible.So please " + this.language_fr.getAttribute("title"))
            }
        });

    }

    getLanguageEn() {
        this.language_en.isDisplayed().then(async function (isVisible) {
            if (isVisible) {
                this.language_en.waitForVisibility().then(function () {
                    this.language_en.click("Click on the English icon")
                })
            } else {
                throw new Error("Locator is not visible.So please " + this.language_en.getAttribute("title"))
            }
        });
    }


    //To get login button element
    getLogInBtn() {
        return this.logInBtn
    }

    //To get "I lost my password" link element
    getILostPwdLnk() {
        return this.iLostPwdLnk
    }

    //To get "Invalid authentication. Use correct credential for login" label element
    getSuccessLoginElmt() {
        return this.successLoginElmt
    }

    //To get element present in Homepage after successful login
    getLoginErrorMsg() {
        return this.loginErrorMsg
    }
}