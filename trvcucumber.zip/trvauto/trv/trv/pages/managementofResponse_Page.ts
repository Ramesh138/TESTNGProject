import { textbox, button, link, label, radiobutton, grid } from "../smartest/custom_elements/smartLocators";

export class ManagementofResponse_page {
    
    private static LdataSearchTittle = label.byXpath(".//response-time/div/h3[1]")
    private static Lstatus = label.byXpath(".//response-time/div/div[1]/form/div[1]/label[1] ")
    private static Ractive = radiobutton.byXpath(".//response-time/div/div[1]/form/div[1]/label[2]")
    private static Rinactive = radiobutton.byXpath(".//response-time/div/div[1]/form/div[1]/label[3]")
    private static Rall = radiobutton.byXpath(".//response-time/div/div[1]/form/div[1]/label[4]")

    private static LlistOfTypeData = label.byXpath(".//response-time/div/h3[2]")

    private static THname = label.byXpath(".//datatable-header-cell[1]/div/div/div")
    private static THstatus = label.byXpath(".//datatable-header-cell[2]/div/div/div")
    private static THdescription = label.byXpath(".//datatable-header-cell[3]/div/div/div")
    private static THorder = label.byXpath(".//datatable-header-cell[4]/div/div/div")

    private static Badd = button.byXpath(".//response-time/div/div[3]/button[1]")
    private static Bsort = button.byXpath(".//response-time/div/div[3]/button[2]")
    private static Bcancel = button.byXpath(".//response-time/div/div[3]/button[3]")

    private static Dsite = grid.byXpath(".//*[@formcontrolname='parSiteID']//option")
    
    

     //To get value to Adminstation title Label
    public static getsiteDp() {
        return this.Dsite
    }

    public static setsiteDp(value:string) {
        return this.Dsite.clickOnMatchingText(value)
    }

    public static getPageHeader(){
        return this.LdataSearchTittle
    }

    public static getSectionHeader(){
        return this.LlistOfTypeData
    }
    public static getSatus(){
        return this.Lstatus
    }
    public static getRactive(){
        return this.Ractive
    }
    public static getRinactive(){
        return this.Rinactive
    }
    public static getRall(){
        return this.Rall
    }
    public static getTHname(){
        return this.THname
    }
    public static getTHstatus(){
        return this.THstatus
    }
    public static getTHdescription(){
        return this.THdescription
    }

    public static getTHorder(){
        return this.THorder
    }
    public static getBadd(){
        return this.Badd
    }
    public static getBsort(){
        return this.Bsort
    }
    public static getBcancel(){
        return this.Bcancel
    }
}