import { textbox, button, link, label, radiobutton, grid } from "../smartest/custom_elements/smartLocators";
import { WebdriverWebElement, ElementFinder } from 'protractor/built/element';
import { waitForVisibilityOf } from "../smartest/actions/waitFor";
import { browser, by, element } from "protractor";

export class sitePage {


    LdataSearchTittle = label.byXpath("html/body/app-root/app-root/app-full-layout/div/div/sites/div/h3")
    Lstatus = label.byXpath(".//sites/div/div[1]/form/label[1]")
    Ractive = radiobutton.byXpath(".//sites/div/div[1]/form/label[2]")
    Rinactive = radiobutton.byXpath(".//sites/div/div[1]/form/label[3]")
    Rall = radiobutton.byXpath(".//sites/div/div[1]/form/label[4]")
    RBactive = radiobutton.byXpath(".//*[@id='au_active']")
    RBinactive = radiobutton.byXpath(".//*[@id='au_inactive']")
    RBall = radiobutton.byXpath(".//*[@id='au_all']")

    LlistOfTypeData = label.byXpath(".//sites/div/h5")
    Ldatasearch = label.byXpath(".//sites/div/h3")
    Lmodifycreation=label.byXpath(".//form-action/div/form/div[1]/h3")

    THname = label.byXpath(".//datatable-header-cell[1]/div/div/div")
    THstatus = label.byXpath(".//datatable-header-cell[2]/div/div/div")
    THdescription = label.byXpath(".//datatable-header-cell[3]/div/div/div")
    THorder = label.byXpath(".//datatable-header-cell[4]/div/div/div")

    Badd = button.byXpath("//*[@id='au_add_btn']/button")
    Bsort = button.byXpath("//a[@id='au_order_btn']")
    Bcancel = button.byXpath(".//*[@id='au_cancel_btn']")

    ABadd = button.byXpath(".//*[@id='au_save_bottom']")
    ABcancel = button.byXpath(".//*[@id='au_cancel_bottom']")
    SBadd = button.byXpath(".//*[@id='au_save_btn']")

    SBcancel = button.byXpath(".//*[@id='au_cancel_btn']")
    StatusYN = button.byXpath("(.//*[@data-off='Yes'])[2]")
    Hpagenation = button.byXpath(".//datatable-pager/ul/li")

    TxNameFr = textbox.byXpath("(.//*[@formcontrolname='name'])[1]")
    TxNameEn = textbox.byXpath("(.//*[@formcontrolname='name'])[2]")
    TxNameSp = textbox.byXpath("(.//*[@formcontrolname='name'])[3]")
    TxNamePo = textbox.byXpath("(.//*[@formcontrolname='name'])[4]")
    TxNameRo = textbox.byXpath("(.//*[@formcontrolname='name'])[5]")
    TxNameBr = textbox.byXpath("(.//*[@formcontrolname='name'])[7]")
    TxNameTu = textbox.byXpath("(.//*[@formcontrolname='name'])[8]")
    TxNameRu = textbox.byXpath("(.//*[@formcontrolname='name'])[6]")

    Pagecount = textbox.byXpath(".//*[@id='MyRData']/ngx-datatable/div/datatable-footer/div/div")
    pagn_first = button.byXpath(".//*[@class='datatable-icon-prev']")
    pagn_previous = button.byXpath(".//*[@class='datatable-icon-left']")
    pagn_next = button.byXpath(".//*[@class='datatable-icon-right']")
    pagn_last = button.byXpath(".//*[@class='datatable-icon-skip']")
    pagn_listvalue = button.byXpath(".//datatable-pager/ul/li")

    Search_listcount = grid.byXpath(".//datatable-body-cell[1]")

    SortValue1 = grid.byXpath(".//select[@formcontrolname='parSite']")

    SortValue = grid.byXpath(".//select[@formcontrolname='parSite']//option")

    upthedata = button.byXpath(".//button[@id='au_up_btn']")

    downthedata = button.byXpath(".//button[@title='Download these data']")

    Search_table = grid.byXpath("//*[@id='MyRData']")


    Search_Value(number: any) {
        return button.byXpath(".//datatable-row-wrapper[" + number + "]/datatable-body-row/div[2]/datatable-body-cell[1]/div")
    }

    Search_ActiveValue(number: any) {
        return button.byXpath("//datatable-row-wrapper[" + number + "]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span[2]")
    }

    getPagecount() {
        return this.Pagecount
    }
    getSBCancel() {
        return this.SBcancel
    }

    getActiveYN() {
        return this.StatusYN
    }
    getUpdata() {
        return this.upthedata
    }
    getDownData() {
        return this.downthedata
    }
    getSortValue() {
        return this.SortValue
    }

    getSortValue1() {
        return this.SortValue1
    }


    getSearch_table() {
        return this.Search_table
    }

    getPagecounc() {
        return this.Search_Value
    }

    getSearch_listcount() {
        return this.Search_listcount
    }

    getpagn_first() {
        return this.pagn_first
    }
    getpagn_previous() {
        return this.pagn_previous
    }
    getpagn_next() {
        return this.pagn_next
    }
    getpagn_last() {
        return this.pagn_last
    }

    getpagn_listvalue() {
        return this.pagn_listvalue
    }

    getTxNameFr() {
        return this.TxNameFr
    }
    async setTxNameFr(value: string) {
        await this.TxNameFr.clearSend(value);
    }

    getTxNameEn() {
        return this.TxNameEn
    }
    async setTxNameEn(value: string) {
        await this.TxNameEn.clearSend(value)

    }

    getTxNameSp() {
        return this.TxNameSp
    }

    async setTxNameSp(value: string) {
        await this.TxNameSp.clearSend(value)
    }

    getTxNamePo() {
        return this.TxNamePo
    }
    async setTxNamePo(value: string) {
        await this.TxNamePo.clearSend(value)
    }

    getTxNameRu() {
        return this.TxNameRu
    }
    async setTxNameRu(value: string) {

        browser.executeScript('window.scrollTo(0,1000);').then(function () {
        })
        await this.TxNameRu.clearSend(value)
    }

    getTxNameRo() {
        return this.TxNameRo
    }
    async setTxNameRo(value: string) {
        this.TxNameRo.waitForVisibility()
        browser.executeScript('window.scrollTo(0,1000);').then(function () {
        })
        await this.TxNameRo.clearSend(value)
    }

    getTxNameTu() {
        return this.TxNameTu
    }
    async setTxNameTu(value: string) {

        browser.executeScript('window.scrollTo(0,1000);').then(function () {
        })
        await this.TxNameTu.clearSend(value)
    }

    getTxNameBr() {
        return this.TxNameBr
    }
    async setTxNameBr(value: string) {
        this.TxNameBr.waitForVisibility()
        browser.executeScript('window.scrollTo(0,1000);').then(function () {
        })
        await this.TxNameBr.clearSend(value)
    }
    getHpagenationHpl() {
        return this.Hpagenation
    }

    getPageHeader() {
        return this.LdataSearchTittle
    }

    getSectionHeader() {
        return this.LlistOfTypeData
    }
    getSatus() {
        return this.Lstatus
    }
    getRactive() {
        return this.Ractive
    }
    getRinactive() {
        return this.Rinactive
    }
    getRall() {
        return this.Rall
    }

    getRBactive() {
        return this.RBactive
    }
    getRBinactive() {
        return this.RBinactive
    }
    getRBall() {
        return this.RBall
    }
    getTHname() {
        return this.THname
    }
    getTHstatus() {
        return this.THstatus
    }
    getTHdescription() {
        return this.THdescription
    }

    getTHorder() {
        return this.THorder
    }
    getBadd() {
        browser.sleep(1000)
        return this.Badd
    }
    getBsort() {
        browser.sleep(1000)
        return this.Bsort
    }
    getBcancel() {
        browser.sleep(1000)
        return this.Bcancel
    }

    getABadd() {
        return this.ABadd
    }

    getABcancel() {
        browser.sleep(1000)
        return this.ABcancel
    }
}