import projectpath from '../flow/pathutils'

const fs = require('fs');
//let RpLbl = JSON.parse(fs.readFileSync(projectpath.Report_path));
export default class mailflow  {

    static jsdubb() {
        var RpLbl = fs.readFileSync(projectpath.Report_path)
        let taglineDirect = RpLbl.ProjectStatus
        
        for (var i in taglineDirect) {
            var TotalTestcases_value = taglineDirect[i].TotalTestcases;
            var TotalPassedCount = taglineDirect[i].TotalPassedCount;
            var TotalFailedCount = taglineDirect[i].TotalFailedCount;
            return "TotalTestcases" + "  : " + TotalTestcases_value + "<br>" + "TotalPassedCount" + "  : " + TotalPassedCount + "<br>" + "TotalFailedCount" + "  : " + TotalFailedCount + "<br>";
        }
    }
    public static async sendReportMail() {
        console.log(" email")
        const sendmail = require('sendmail')({
            logger: {
                debug: console.log,
                info: console.info,
                warn: console.warn,
                error: console.error
            },
            silent: false,   
            devPort: 25, // Default: False
            devHost: 'smtp.renault.fr', // Default: localhost
            smtpPort: 25, // Default: 25
            smtpHost: 'smtp.renault.fr' // Default: -1 - extra smtp host after resolveMX
        })
     return await sendmail({
            
            from: 'ramesh.ponneri@rntbci.com',
          // to: 'ramesh.ponneri@rntbci.com,alban.nocera@renault.com,jansi.chandran@rntbci.com,dhanabal.mariappan@rntbci.com,Selvaraj.Muniasamy@rntbci.com,mohamed-fethi.mederbel@renault.com',
          to: 'ramesh.ponneri@rntbci.com',
            subject: 'TRAVAUX Mobile  Automation Report ',
            html: "HI Team <br> <br> please find the above attachment for the TRAVAUX Application automation Report <br> <br>  "+"<br><br>Regards <br> Ramesh Ponneri",
            attachments: [
                {   
                    path:'..//trv//report//html//cucumber_reporter.html',
                },
            ]
        }, function (err, reply) {
            console.log(err && err.stack);
            console.dir(reply);
        });
    }
}
