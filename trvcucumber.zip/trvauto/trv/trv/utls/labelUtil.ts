
import fs = require("fs");
export class labelUtils {
    public readJsonFile(filePath:any) {
        return JSON.parse(fs.readFileSync(filePath).toString());
    }
  public getlabelmethod(key:any,language:string) {
        return getlabel(key,language);
    }
   public getlabelvthValue(language:string) {
        return getLabelJson(language);
    }
    public getlabelmethodvthlanguage(key:any) {
        return getlabelwithlangaue(key);
    }
}
export function systemPath() {
    return process.cwd().split("\\bin")[0].trim();
}

export function getLabelJson(language:string) {
    const fs = require('fs');
    return JSON.parse(fs.readFileSync(".//labels//"+language+".json").toString());
}

export function getlabel(key: string ,language:string ) {
    const fs = require('fs');
    let rawdata = fs.readFileSync(systemPath() + '/labels/' + language + '.json');
    let author = JSON.parse(rawdata);
    let websiteValue = author[key];
    return websiteValue;
}

export function getlabelwithlangaue(key: string) {
    const fs = require('fs');
    let rawdata = fs.readFileSync(systemPath() + '/labels/applanguage.json');
    let author = JSON.parse(rawdata);
    let websiteValue = author[key];
    return websiteValue;
}