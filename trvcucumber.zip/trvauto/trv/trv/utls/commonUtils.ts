import { browser } from "protractor";
import { WebdriverWebElement } from "protractor/built/element";

browser.manage().timeouts().implicitlyWait(30000);

export class commonUtils {
  static dbvalue: string = '';
  public createJsonfile(objectValue: any, siteValue: string, filename: string) {
    const fs = require("fs");
    objectValue = {
      site: siteValue,
    };
    const data = JSON.stringify(objectValue);
    fs.writeFileSync(filename + ".json", data);

  }
  public static verticalScrollDown() {
    browser.executeScript('window.scrollTo(0,20000);').then(function () {
    })
  }
  public static verticalScrollUp() {
    browser.executeScript('window.scrollTo(10000,0);').then(function () {
    })
  }

  public async elementclickaction(webelementvalue: WebdriverWebElement) {
    await browser.pause(2000);
    webelementvalue.isDisplayed().then(async function (isVisible: any) {
      if (isVisible) {
        webelementvalue.getText().then(function (lable) {
          console.log("click on the " + lable + "  link ")
        });
        browser.sleep(500).then(async (async) => {
          webelementvalue.click();
        });
      } else {
        throw new Error("Locator is not visible. ");
      }
    });
  }
  public valueValaidation(Actual: string, Expected: string) {
    if (Actual.toUpperCase() == Expected.toUpperCase()) {
      console.log(Actual.toUpperCase() + "  is succesfully match with the " + Expected.toUpperCase())
    } else {
      throw new Error(Actual.toUpperCase() + "  is not match with the " + Expected.toUpperCase())
    }
  }
  public async databasevalue(Sqlquery: string): Promise<any> {
    console.log("sTARTED ")
    var mysql = require("mysql");
    let connection: any = await mysql.createConnection({
      host: "s2946ads.mc2.renault.fr", //"s2946ads.mc2.renault.fr",
      user: "trv_adm",//"trv_adm",
      password: "trv_adm_int01",//"trv_adm_01",
      database: "trv_db_01",
      port: "3307",
    });

    await connection.connect();
    var sql = Sqlquery;
    var row: any;
    await connection.query(sql, function (err: any, rows: any) {
      console.log(" row value ")
      if (err) {
        console.log(err)
      } else {
        Object.keys(rows).forEach(function (keyItem) {
          row = rows[keyItem]
          console.log(" row value " + row.Number)
        })
      }
      connection.end()
      return row.Number
    })
  }

  public async executeQuery2(Sqlquery: any) {
    console.log("started")
    let map = new Map()
    var mysql = require("mysql");
    let connection = mysql.createConnection({
      host: "s2946ads.mc2.renault.fr", //"s2946ads.mc2.renault.fr",
      user: "trv_adm",//"trv_adm",
      password: "trv_adm_int01",//"trv_adm_01",
      database: "trv_db_01",
      port: "3307",
    });

    connection.connect();
    var sql = Sqlquery;
    var row: any;
    connection.query(sql, async function (err: any, rows: any) {
      if (err) {
        console.log(err)
        connection.end()
      } else {
        Object.keys(rows).forEach(function (keyItem) {
          row = rows[keyItem]
          map.set("DBValue", row.Number)
        })
      }
      connection.end()
      commonUtils.dbvalue = map.get("DBValue")

    })
    await browser.sleep(2000)
    console.log(" value to be outside " + commonUtils.dbvalue)
    return commonUtils.dbvalue;
  }


  public async executeQuery(checkvalue: any) {
    let map = new Map()
    var mysql = require("mysql");
    //this.dbvalue="text";
    let connection = mysql.createConnection({
      host: "s2946ads.mc2.renault.fr",
      user: "sma_adm",
      password: "sma_adm_01",
      database: "sma_db_01",
      port: "3306",
    });

    connection.connect();
    var sql = "SELECT s.sts_id,s.partNoLineStatus,s.mixAdoptionRatio,e.partBcas_valueInProcurementCurrencyPiece FROM tb_601_bom_sts_baseInformation s INNER JOIN tb_615_bom_economicTarget e ON s.sts_id = e.sts_id WHERE Rownum =1;"
    var row;
    await browser.sleep(3000)
    await connection.query(sql, async function (err, rows) {
      if (err) {
        console.log(err)
        connection.end()
      } else {
        Object.keys(rows).forEach(function (keyItem) {
          row = rows[keyItem]
          console.log(" row value " + row.sts_id)
          map.set("STS_id", row.sts_id)
          map.set("PartNoOflines", row.partNoLineStatus)
          map.set("mixAdoptionRatio", row.mixAdoptionRatio)
          map.set("partBcas_valueInProcurementCurrencyPiece", row.partBcas_valueInProcurementCurrencyPiece)
        })
      }
      connection.end()

      commonUtils.dbvalue = map.get(checkvalue)
    })
    await browser.sleep(2000)
    console.log(" value to be outside " + commonUtils.dbvalue)
    return commonUtils.dbvalue;
  }

}

