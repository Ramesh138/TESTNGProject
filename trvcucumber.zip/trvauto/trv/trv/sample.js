
class ConnectDatabase {
    constructor() {
        var mysql = require("mysql");
        this.connection = mysql.createConnection({
            host: "s2946ads.mc2.renault.fr",
            user: "trv_adm",
            password: "trv_adm_int01",
            database: "trv_db_01",
            port : "3307",
        });
    }
}
var connectDatabase = new ConnectDatabase()
connectDatabase.connection.connect();
var sql = "SELECT ID_Demande FROM TRV_TB01_TRAVAUX_DEMANDES WHERE PRECISION_LIEU='SpecifiedLocation_RC7JJG';"
connectDatabase.connection.query(sql, function (err, rows) {
    if (err) {
        console.log(err)
    } else {
        // console.log(JSON.stringify(rows))

        Object.keys(rows).forEach(function (keyItem) {
            var row = rows[keyItem]
            value = row.ID_Demande

        console.log(row.TYPE_LIB + " " + row.INTITULE)
           console.log(row.Number)
            console.log(row.ID_Demande-1)
        })
    }
    connectDatabase.connection.end()
})

