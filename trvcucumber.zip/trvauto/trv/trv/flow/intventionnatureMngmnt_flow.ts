import { browser, By, by, element, ExpectedConditions, protractor } from "protractor";
import { WebdriverWebElement } from "protractor/built/element";
import { intventionNatureMngmnt_page } from "../pages/intventionNatureMngmnt_Page";
import {sitePage} from "../pages/sitemanagement_page"
import { labelUtils } from "../utls/labelUtil";


const labelutil: labelUtils = new labelUtils();
const sitepage: sitePage = new sitePage()
const chai = require("chai").use(require("chai-as-promised"));
const expect = chai.expect;

export class IntventionNatureMngmnt_Flow {

  public LabelValidation(webelementvalue: WebdriverWebElement, Labele: string,language:any) {
    browser.sleep(1000)
    webelementvalue.getText().then(function (LabelValue) {
      if (LabelValue.toString().match(labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language)))) {
        console.log("'" + LabelValue + "'" + "  Expected value is matached with Actual value   " + labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language)))
      } else {

        var actual =LabelValue
        var expected=labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language))
        console.log(actual+" is not matching vth expected "+expected)
        expect(actual==expected).to.equal(true)
      }
    })
  }


  public async LabelValidationAll(language:string) {
    await browser.sleep(2000)
    this.LabelValidation(intventionNatureMngmnt_page.getPageHeader().getElement(), "RechercheDesDonnees",language)
    this.LabelValidation(intventionNatureMngmnt_page.getSatus().getElement(), "Etat",language)
    this.LabelValidation(intventionNatureMngmnt_page.getRactive().getElement(), "Active",language)
    this.LabelValidation(intventionNatureMngmnt_page.getRinactive().getElement(), "Inactif",language)
    this.LabelValidation(intventionNatureMngmnt_page.getRall().getElement(), "Tout",language)
    this.LabelValidation(intventionNatureMngmnt_page.getTHname().getElement(), "Intitule",language)
    this.LabelValidation(intventionNatureMngmnt_page.getTHstatus().getElement(), "Etat",language)
    this.LabelValidation(intventionNatureMngmnt_page.getTHdescription().getElement(), "Designation",language)
    this.LabelValidation(intventionNatureMngmnt_page.getTHorder().getElement(), "Ordre",language)
    // this.LabelValidation(itm.getBadd().getElement(), "BoutonAjouter")
    this.LabelValidation(intventionNatureMngmnt_page.getBsort().getElement(), "BoutonOrdonner",language)
    this.LabelValidation(intventionNatureMngmnt_page.getBcancel().getElement(), "BoutonAnnuler",language)
    this.LabelValidation(intventionNatureMngmnt_page.getSectionHeader().getElement(), "ListeDesDonneesDeType",language)
  }

  public async selectSiteValue() {
    intventionNatureMngmnt_page.getsiteDp().getElements().count().then(function(value){
      intventionNatureMngmnt_page.getsiteDp().clickByIndex(value-1)
      console.log("'" + value + "'" + "Size value is defined  ")
    })
    await browser.sleep(3000);
  }

  public async selectInterventionTypeValue() {
    await browser.sleep(2000)
    intventionNatureMngmnt_page.getinterventiontypeDp().getElements().count().then(async function(value){
      intventionNatureMngmnt_page.getinterventiontypeDp().clickByIndex(value-1)
      console.log("'" + value + "'" + "Size value is defined  ")
    })

  }

  public async verifyAlertmessage() {
    var message:any;
    let abc = await browser.switchTo().alert();
    await abc.getText().then(function (message) {
      console.log(message + " message is succesfully verified")
    })
    await abc.accept();
  }

  async internatureCreation() {
    await browser.sleep(2000)
    var addValue=this.randomString(4);
   await sitepage.setTxNameFr("internature"+addValue);
   await sitepage.setTxNameEn("internature"+addValue);
   await sitepage.setTxNameSp("internature"+addValue);
   await sitepage.setTxNamePo("internature"+addValue);
   await sitepage.setTxNameRo("internature"+addValue);
   await sitepage.setTxNameRu("internature"+addValue);
   await sitepage.setTxNameBr("internature"+addValue);
   await sitepage.setTxNameTu("internature"+addValue);
   return "internature"+addValue;
  }

  //"intertypemation demo data "+ this.randomString(5)
  public randomString(value: any) {
    var chars = "0123456789";
    var string_length = value;
    var randomstring = '';
    for (var i = 0; i < string_length; i++) {
      var rnum = Math.floor(Math.random() * chars.length);
      randomstring += chars.substring(rnum, rnum + 1);
    }
    return randomstring;
  }

 public async clickAddButtonInAddForm(){
   await browser.sleep(3000);
   await browser.executeScript('window.scrollTo(0,1000);');
   await element(by.id("au_save_bottom")).click();
   await browser.sleep(3000);
 }
}