import { browser, By, by, element, ExpectedConditions } from "protractor";
import { WebdriverWebElement } from "protractor/built/element";
import { commonUtils } from "../utls/commonUtils";
import { labelUtils } from "../utls/labelUtil";
import { myRequest_Page } from "../pages/myRequest_page";

const fs = require('fs');
// let Actual = JSON.parse(fs.readFileSync("..//Travax//data//Actual-Sitedata-file.json"));
// let Expected = JSON.parse(fs.readFileSync("..//Travax//data//Expected-Sitedata-file.json"));
const myrequestpage: myRequest_Page = new myRequest_Page();
const labelutils: labelUtils = new labelUtils()
const comutils: commonUtils = new commonUtils();
export class myRequest_Flow {

  //pass title of the page as "List of my requests"
  public LabelValidation(webelementvalue: WebdriverWebElement, Labele: string) {
    webelementvalue.getText().then(function (LabelValue) {
      if (LabelValue.toString().match(labelutils.getlabelmethod(Labele,labelutils.getlabelmethodvthlanguage("English")))) {
        //console.log("'" + LabelValue + "'" + "Expected value is matached with Actual value ")
      } else {
        throw new Error(labelutils.getlabelmethod(Labele,labelutils.getlabelmethodvthlanguage("English")) + " Expected value is not matached with Actual value " + LabelValue)
      }
    })
  }

  public Table_coloums_verification() {

    this.LabelValidation(myrequestpage.get_TT_sheetName().getElement(), "NumeroFiche")
    //console.log("1")
    this.LabelValidation(myrequestpage.get_TT_contractManager().getElement(), "ChargeAffaire")
    //console.log("2")
    this.LabelValidation(myrequestpage.get_TT_InterventionLocation().getElement(), "interventionLocation")
    //console.log("3")
    this.LabelValidation(myrequestpage.get_TT_Description().getElement(), "Description")
    //console.log("4")
    this.LabelValidation(myrequestpage.get_TT_Status().getElement(), "Etat")
    //console.log("5")
  }

  async verifyMyRequestPage() {
    await browser.sleep(2000);
    return this.LabelValidation(myrequestpage.get_T_ListOfMyRequest().getElement(), "Liste de mes demandes")
  }

  checkPageCount() {
    browser.sleep(1000)
    myrequestpage.get_page_count().getText().then(function (value) {
      //console.log(value)
    })
  }

  public data_click() {
    browser.executeScript('window.scrollTo(0,20000);').then(function () {
    })
    myrequestpage.get_sheet_number().click("Clicked on first request");

  }

  async DB_verification_for_count1(specloc: any) {
    var query = "SELECT COUNT(*) as Number FROM TRV_TB01_TRAVAUX_DEMANDES WHERE PRECISION_LIEU= '" + specloc + "';"
    var actual: any = await comutils.executeQuery2(query);
    console.log(" db value should be " + actual)
  }


  async DB_trail() {
    console.log("started")
    let map = new Map()
    var mysql = require("mysql");
    let connection = mysql.createConnection({
      host: "s2946ads.mc2.renault.fr", //"s2946ads.mc2.renault.fr",
      user: "trv_adm",//"trv_adm",
      password: "trv_adm_int01",//"trv_adm_01",
      database: "trv_db_01",
      port: "3307",
    });

    connection.connect();
    var sql = "SELECT COUNT(*) as Number FROM TRV_TB01_TRAVAUX_DEMANDES WHERE PRECISION_LIEU= 'SpecifiedLocation_PJSMZA';";

    var row;

    connection.query(sql, async function (err, rows) {
      console.log("Sql inside to be " + sql)
      if (err) {
        console.log(err)
        connection.end()
      } else {
        Object.keys(rows).forEach(function (keyItem) {
          row = rows[keyItem]
          map.set("DBValue", row.Number)
          console.log(" row value " + row.Number)
        })
      }
      connection.end()
      console.log(" value to be outside " + map.get("DBValue"))
    })
  }
  /**
   * DBINIT
   */
  public async dbvalue() {
    console.log(" i am started")
    let mysql = require('mysql');
    let con = mysql.createConnection({
      host: "s2946ads.mc2.renault.fr", //"s2946ads.mc2.renault.fr",
      user: "trv_adm",//"trv_adm",
      password: "trv_adm_int01",//"trv_adm_01",
      database: "trv_db_01",
      port: "3307",
    });
   // console.log(connection);
    console.log(" i am BEGIN CONNECTION")
    let con1:any=con.connect((err: any) => {
      if (err) throw err;
      console.log('Connected!');
    });

    var sql = "SELECT COUNT(*) as Number FROM TRV_TB01_TRAVAUX_DEMANDES WHERE PRECISION_LIEU= 'SpecifiedLocation_PJSMZA'";
     con.query(sql,

      (err: any, rows: any) => {
        if (err) throw err;
        console.log(rows);
      }
    );
    con.end((err: any) => {
      if (err) throw err;
      console.log('end!');
    });
    console.log("END PROGRAM")
  }

}

