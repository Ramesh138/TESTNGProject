
import { browser, WebElementPromise } from 'protractor'
import { WebdriverWebElement } from "protractor/built/element";
import { adminPage } from "../pages/adminPage";
import { labelUtils } from "../utls/labelUtil";
import { commonUtils } from "../utls/commonUtils";

const commonutils: commonUtils = new commonUtils();
const labelutil: labelUtils = new labelUtils();
const adminpage: adminPage = new adminPage();

browser.manage().timeouts().implicitlyWait(30000)

export class admin_Flow {

  /*click on the Adminstartion  link*/
  public async clickAdminMenuBtn() {
    await browser.pause(2000)
    commonutils.elementclickaction(adminpage.getAdminstartionMBtn().getElement())
  }

  public clickAdminMenuBtn1() {
    browser.pause(5000)
    commonutils.elementclickaction(adminpage.getAdminstartionMBtn().getElement())
  }


  public async clickkBSiteManagement() {
    await browser.sleep(2000)
    return adminpage.bt_SiteManagement.click();
     
   // commonutils.elementclickaction(adminpage.getBSiteManagement().getElement())
  }
  public clickkAdditionalInformationSite() {
    commonutils.elementclickaction(adminpage.getAdditionalInformationSite().getElement())
  }
  public clickkInterventionTypesManagement() {
    commonutils.elementclickaction(adminpage.getInterventionBTypesManagement().getElement())
  }
  public clickkInterventionNaturesManagement() {
    commonutils.elementclickaction(adminpage.getInterventionNaturesManagement().getElement())
  }
  public clickkManagementSubInterventions() {
    commonutils.elementclickaction(adminpage.getManagementSubInterventions().getElement())
  }
  public clickkManagementInterventionLocations() {
    commonutils.elementclickaction(adminpage.getManagementInterventionLocations().getElement())
  }
  public clickManagementLevels() {
    commonutils.elementclickaction(adminpage.getManagementLevels().getElement())
  }
  public clickManagementResponseTime() {
    commonutils.elementclickaction(adminpage.getManagementResponseTime().getElement())
  }
  public clickManagementFixingTime() {
    commonutils.elementclickaction(adminpage.getManagementFixingTime().getElement())
  }
  public clickManagementInterveningCompanies() {
    commonutils.elementclickaction(adminpage.getManagementInterveningCompanies().getElement())
  }
  public clickUserManagement() {
    commonutils.elementclickaction(adminpage.getUserManagement().getElement())
  }
  public clickCommunicationManagement() {
    commonutils.elementclickaction(adminpage.getCommunicationManagement().getElement())
  }

  public async LabelValidationWithChildLabel(webelementvalue: WebdriverWebElement, Labele: string) {
    browser.sleep(1000);
    webelementvalue.getText().then(function (LabelValue) {
      console.log("'" + LabelValue + "'" + "  Expected value is matached with Actual value   " + labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage("English")))
      if (LabelValue.toString().match(labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage("English")))) {
        console.log("'" + LabelValue + "'" + "  Expected value is matached with Actual value   " + labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage("English")))
      } else {
        throw new Error(labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage("English")) + " Expected value is not matached with Actual value " + LabelValue)
      }
    })

  }

  public async LabelValidationWithParentLabel(webelementvalue: WebdriverWebElement, Labele: string) {
    browser.sleep(1000);
    return await webelementvalue.getText().then(function (LabelValue) {
      if (LabelValue.toString().match(Labele)) {
        console.log("'" + LabelValue + "'" + "  Expected value is matached with Actual value   " + Labele)
      } else {
        throw new Error(Labele + " Expected value is not matached with Actual value " + LabelValue)
      }
    })
  }

  public async LabelValidation_Adminstration_Homepage() {
    return this.LabelValidationWithParentLabel(adminpage.getAdditionalInformationSite().getElement(), "GestionInfoDesSites")
    return this.LabelValidationWithChildLabel(adminpage.getInterventionTypesManagement().getElement(), "GestionDesTypesProblemes")
    return this.LabelValidationWithChildLabel(adminpage.getInterventionNaturesManagement().getElement(), "GestionDesNaturesProblemes")
    return this.LabelValidationWithChildLabel(adminpage.getManagementSubInterventions().getElement(), "GestionDesSousProblemes")
    return this.LabelValidationWithChildLabel(adminpage.getManagementInterventionLocations().getElement(), "GestionDesLieuxIntervention")
    return this.LabelValidationWithChildLabel(adminpage.getManagementLevels().getElement(), "GestionDesSousLieuxIntervention")
    return this.LabelValidationWithChildLabel(adminpage.getManagementResponseTime().getElement(), "GestionDesTpsReaction")
    return this.LabelValidationWithChildLabel(adminpage.getManagementFixingTime().getElement(), "GestionDesTpsDepannage")
    return this.LabelValidationWithChildLabel(adminpage.getManagementInterveningCompanies().getElement(), "GestionDesSocietes")
    return this.LabelValidationWithChildLabel(adminpage.getUserManagement().getElement(), "GestionDesUtilisateurs")
    return this.LabelValidationWithChildLabel(adminpage.getCommunicationManagement().getElement(), "GestionComm")
  }
}