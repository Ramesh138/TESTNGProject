
import { ElementFinder } from "protractor/built/element";
import { browser } from "protractor";
import { labelUtils } from "../utls/labelUtil";
import { newRequest_Page } from "../pages/newRequest_Page";
import {$,element, by } from 'protractor';
const newrequest: newRequest_Page = new newRequest_Page();
const labelutil:labelUtils=new labelUtils()
browser.manage().timeouts().implicitlyWait(30000)

export class newRequest_Flow  {

   // pass the title of the page as "New request"
    public LabelValidation(webelementvalue: ElementFinder, Labele: string) {
      webelementvalue.getText().then(function (LabelValue) {
        if (LabelValue.toString().match(labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage("English")))) {
          //console.log("'" + LabelValue + "'" + "Expected value is matached with Actual value ")
        } else {
          throw new Error(labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage("English")) + " Expected value is not matached with Actual value " + LabelValue)
        }
      })
    }
  
/**
 * provide the data to "Intervention location"
 */
public Data_provide_to_InterventionLocation() {
  //console.log("start")
  newrequest.select_IL_d_Site("9831_EN")
  newrequest.select_IL_d_InterventionLocation("9907_EN")
  newrequest.select_IL_d_SpecifyTheLocation("Centrale n°202 578")
  browser.executeScript('window.scrollTo(0,500);').then(function () {
  })
  browser.sleep(500)
  let data = "SpecifiedLocation_"+this.randomString(6)
  //console.log(data)
  browser.sleep(2000).then(() => {
  newrequest.set_IL_T_SpecifyTheLocation(data) 
  })
  //console.log("start")
  return data
}





public  Data_provide_to_nature_of_intervention() {
   //console.log("start of this method")
  // newrequest.select_NI_d_Intervention_type(getData("Interventiontype"))
  // newrequest.select_NI_d_Intervention_nature(getData("InterventionNature"))
  // newrequest.select_NI_d_Level_2_intervention(getData("L2levelIntervention"))
  // newrequest.set_NI_T_Description(getData("Description"))

  //   newrequest.select_NI_d_Intervention_type("Equipement")
  // newrequest.select_NI_d_Intervention_nature("Ascenceur / monte-charge")
  // newrequest.select_NI_d_Level_2_intervention("Bruit anormal")
  // newrequest.set_NI_T_Description("qwerty")

  newrequest.select_NI_d_Intervention_type("2367_EN")
  newrequest.select_NI_d_Intervention_nature("2201")
  newrequest.select_NI_d_Level_2_intervention("2201")
  newrequest.set_NI_T_Description("qwerty")
}

/**
 *  provide data to "Additional Information"
 */
public  Data_provide_to_AdditionalInformation() {
  browser.executeScript('window.scrollTo(0,20000);').then(function () {
  })
  newrequest.select_d_Imobilization("Yes");
  newrequest.set_T_Imobilization("DescriptionImmobilisation for the Automation Case")
}

/**
 *  to click on save button
 */
 
public async click_on_Save_button() {
  browser.executeScript('window.scrollTo(0,10000);').then(function () {
  })
  await browser.sleep(1000);
	return newrequest.BSaveBtn.click()
}


public click_on_Cancel_button() {
  browser.executeScript('window.scrollTo(0,10000);').then(function () {
  })
	newrequest.clickCancel();
}

/**
 *  change the author requestor
 */
 public async change_author_requestor(ipn:string) {
  await browser.sleep(4000)
  newrequest.click_clean_author_details()
  await browser.sleep(2000)
  newrequest.set_T_IPN_requestor_details(ipn);
  await browser.sleep(2000)
	newrequest.click_search_author_details();
}


public randomString(value: any) {
  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
  var string_length = value;
  var randomstring = '';
  for (var i = 0; i < string_length; i++) {
    var rnum = Math.floor(Math.random() * chars.length);
    randomstring += chars.substring(rnum, rnum + 1);
  }
  return randomstring;
}

LabelValidationAll(){
  this.LabelValidation(element(by.xpath("//h4")),"Requester")
  this.LabelValidation(element(by.xpath("//label[@class ='col-md-12']")),"Requester")
  this.LabelValidation(element(by.xpath("//form/div[4]/div[1]/div/h5")),"Intervention location")
  this.LabelValidation(element(by.xpath("//form/div[4]/div[1]/div/div[1]/label")),"Geographic site")
  this.LabelValidation(element(by.xpath("//form/div[4]/div[1]/div/div[2]/label")),"Intervention location")
  this.LabelValidation(element(by.xpath("//form/div[4]/div[1]/div/div[3]/label")),"Specify the location")
  this.LabelValidation(element(by.xpath("//form/div[4]/div[1]/div/div[4]/label")),"Specify the location ")

  //
  this.LabelValidation(element(by.xpath("//form/div[4]/div[2]/div/h5")),"Nature of the intervention")
  this.LabelValidation(element(by.xpath("//form/div[4]/div[2]/div/div[1]/label")),"Intervention type ")
  this.LabelValidation(element(by.xpath("//form/div[4]/div[2]/div/div[2]/label")),"Intervention nature ")
  this.LabelValidation(element(by.xpath("//form/div[4]/div[2]/div/div[3]/label")),"Level-2 intervention ")
  this.LabelValidation(element(by.xpath("//form/div[4]/div[2]/div/div[4]/label")),"Description ")

  //
  this.LabelValidation(element(by.xpath("//form/div[5]/div/h5")),"Additional Information")
  this.LabelValidation(element(by.xpath("//form/div[5]/div/div[1]/label")),"Is the breakdown immobilizing?")
  this.LabelValidation(element(by.xpath("//form/div[5]/div/div[2]/label")),"If answer is Yes, Why?")

  //
  this.LabelValidation(element(by.xpath("//form/div[6]/div/label")),"Attachments")
  this.LabelValidation(element(by.xpath("//label[@for = 'test1']")),"File")
  this.LabelValidation(element(by.xpath("//label[@for = 'test2']")),"Url")
  this.LabelValidation(element(by.xpath("//div[contains(@class, 'drag')]/span")),"Drag and drop")

}

}