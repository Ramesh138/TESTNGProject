import { browser, By, by, element, ExpectedConditions, protractor } from "protractor";
import { WebdriverWebElement } from "protractor/built/element";
import { ManagementLevel_Page } from "../pages/managementLevel_Page";
import {sitePage} from "../pages/sitemanagement_page"
import { labelUtils } from "../utls/labelUtil";


const labelutil: labelUtils = new labelUtils();
const sitepage: sitePage = new sitePage()
const chai = require("chai").use(require("chai-as-promised"));
const expect = chai.expect;

export class ManagementLevel_Flow {

  public LabelValidation(webelementvalue: WebdriverWebElement, Labele: string,language:any) {
    browser.sleep(1000)
    webelementvalue.getText().then(function (LabelValue) {
      if (LabelValue.toString().match(labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language)))) {
        console.log("'" + LabelValue + "'" + "  Expected value is matached with Actual value   " + labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language)))
      } else {

        var actual =LabelValue
        var expected=labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language))
        console.log(actual+" is not matching vth expected "+expected)
        expect(actual==expected).to.equal(true)
      }
    })
  }


  public async LabelValidationAll(language:string) {
    await browser.sleep(2000)
    this.LabelValidation(ManagementLevel_Page.getPageHeader().getElement(), "RechercheDesDonnees",language)
    this.LabelValidation(ManagementLevel_Page.getSatus().getElement(), "Etat",language)
    this.LabelValidation(ManagementLevel_Page.getRactive().getElement(), "Active",language)
    this.LabelValidation(ManagementLevel_Page.getRinactive().getElement(), "Inactif",language)
    this.LabelValidation(ManagementLevel_Page.getRall().getElement(), "Tout",language)
    this.LabelValidation(ManagementLevel_Page.getTHname().getElement(), "Intitule",language)
    this.LabelValidation(ManagementLevel_Page.getTHstatus().getElement(), "Etat",language)
    this.LabelValidation(ManagementLevel_Page.getTHdescription().getElement(), "Designation",language)
    this.LabelValidation(ManagementLevel_Page.getTHorder().getElement(), "Ordre",language)
    // this.LabelValidation(itm.getBadd().getElement(), "BoutonAjouter")
    this.LabelValidation(ManagementLevel_Page.getBsort().getElement(), "BoutonOrdonner",language)
    this.LabelValidation(ManagementLevel_Page.getBcancel().getElement(), "BoutonAnnuler",language)
    this.LabelValidation(ManagementLevel_Page.getSectionHeader().getElement(), "ListeDesDonneesDeType",language)
  }

  public async selectSiteValue() {
    ManagementLevel_Page.getDsite().getElements().count().then(function(value){
      ManagementLevel_Page.getDsite().clickByIndex(value-1)
      console.log("'" + value + "'" + "Size value is defined  ")
    })
    await browser.sleep(3000);
  }

  public async selectInterventionLocationValue() {
    await browser.sleep(2000)
    ManagementLevel_Page.getDInterventionLocaton().getElements().count().then(async function(value){
      ManagementLevel_Page.getDInterventionLocaton().clickByIndex(value-1)
      console.log("'" + value + "'" + "Size value is defined  ")
    })

  }

  public async verifyAlertmessage() {
    var message:any;
    let abc = await browser.switchTo().alert();
    await abc.getText().then(function (message) {
      console.log(message + " message is succesfully verified")
    })
    await abc.accept();
  }

  async LevelCreation() {
    await browser.sleep(2000)
    var addValue=this.randomString(4);
   await sitepage.setTxNameFr("level"+addValue);
   await sitepage.setTxNameEn("level"+addValue);
   await sitepage.setTxNameSp("level"+addValue);
   await sitepage.setTxNamePo("level"+addValue);
   await sitepage.setTxNameRo("level"+addValue);
   await sitepage.setTxNameRu("level"+addValue);
   await sitepage.setTxNameBr("level"+addValue);
   await sitepage.setTxNameTu("level"+addValue);
   return "level"+addValue;
  }

  //"intertypemation demo data "+ this.randomString(5)
  public randomString(value: any) {
    var chars = "0123456789";
    var string_length = value;
    var randomstring = '';
    for (var i = 0; i < string_length; i++) {
      var rnum = Math.floor(Math.random() * chars.length);
      randomstring += chars.substring(rnum, rnum + 1);
    }
    return randomstring;
  }

 public async clickAddButtonInAddForm(){
   await browser.sleep(3000);
   await browser.executeScript('window.scrollTo(0,1000);');
   await element(by.id("au_save_bottom")).click();
   await browser.sleep(3000);
 }
}