import { element, By, browser, protractor, WebElementPromise, $ } from "protractor"

browser.ignoreSynchronization = true;

export default class projectpath {

  static en_labelspath: string = systemPath() + '/Labels/en.json'
  static fr_labelspath: string = systemPath() + '/Labels/fr.json'
  //static Report_path: string = systemPath() + '/Reports/Current/content.json'
  static Report_path: string = systemPath() + '/Reports/Dynamic/Current/content.json'
  static Report_path1: string = systemPath() + '/autoit/content.json'
  static data_file: string = systemPath() + '/autoit/data.json'


  comparevaluesinlist(listdata: any) {
    for (let j in listdata) {
      let value = listdata[j];
      console.log(j + ":::::::::" + listdata[j]);
    }
  }

}
export function systemPath(): string {
  return process.cwd().split("\\bin")[0].trim()
}