import { browser, By, by, element, ExpectedConditions, protractor } from "protractor";
import { WebdriverWebElement } from "protractor/built/element";
import { intventionTypeMngmnt_page } from "../pages/intventionTypeMngmnt_Page";
import {sitePage} from "../pages/sitemanagement_page"
import { labelUtils } from "../utls/labelUtil";


const labelutil: labelUtils = new labelUtils();
const sitepage: sitePage = new sitePage()
const chai = require("chai").use(require("chai-as-promised"));
const expect = chai.expect;

export class IntventionTypeMngmnt_Flow {

  public LabelValidation(webelementvalue: WebdriverWebElement, Labele: string,language:any) {
    browser.sleep(1000)
    webelementvalue.getText().then(function (LabelValue) {
      if (LabelValue.toString().match(labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language)))) {
        console.log("'" + LabelValue + "'" + "  Expected value is matached with Actual value   " + labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language)))
      } else {

        var actual =LabelValue
        var expected=labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language))
        console.log(actual+" is not matching vth expected "+expected)
        expect(actual==expected).to.equal(true)
      }
    })
  }


  public async LabelValidationAll(language:string) {
    await browser.sleep(2000)
    this.LabelValidation(intventionTypeMngmnt_page.getPageHeader().getElement(), "RechercheDesDonnees",language)
    this.LabelValidation(intventionTypeMngmnt_page.getSatus().getElement(), "Etat",language)
    this.LabelValidation(intventionTypeMngmnt_page.getRactive().getElement(), "Active",language)
    this.LabelValidation(intventionTypeMngmnt_page.getRinactive().getElement(), "Inactif",language)
    this.LabelValidation(intventionTypeMngmnt_page.getRall().getElement(), "Tout",language)
    this.LabelValidation(intventionTypeMngmnt_page.getTHname().getElement(), "Intitule",language)
    this.LabelValidation(intventionTypeMngmnt_page.getTHstatus().getElement(), "Etat",language)
    this.LabelValidation(intventionTypeMngmnt_page.getTHdescription().getElement(), "Designation",language)
    this.LabelValidation(intventionTypeMngmnt_page.getTHorder().getElement(), "Ordre",language)
    // this.LabelValidation(itm.getBadd().getElement(), "BoutonAjouter")
    this.LabelValidation(intventionTypeMngmnt_page.getBsort().getElement(), "BoutonOrdonner",language)
    this.LabelValidation(intventionTypeMngmnt_page.getBcancel().getElement(), "BoutonAnnuler",language)
    this.LabelValidation(intventionTypeMngmnt_page.getSectionHeader().getElement(), "ListeDesDonneesDeType",language)
  }

  public selectSiteValue() {
    intventionTypeMngmnt_page.getsiteDp().getElements().count().then(function(value){
      intventionTypeMngmnt_page.getsiteDp().clickByIndex(value-1)
      console.log("'" + value + "'" + "Size value is defined  ")
    })

  }

  public async verifyAlertmessage() {
    var message:any;
    let abc = await browser.switchTo().alert();
    await abc.getText().then(function (message) {
      console.log(message + " message is succesfully verified")
    })
    await abc.accept();
  }

  async interTypeCreation() {
    await browser.sleep(2000)
    var addValue=this.randomString(4);
   await sitepage.setTxNameFr("intertype"+addValue);
   await sitepage.setTxNameEn("intertype"+addValue);
   await sitepage.setTxNameSp("intertype"+addValue);
   await sitepage.setTxNamePo("intertype"+addValue);
   await sitepage.setTxNameRo("intertype"+addValue);
   await sitepage.setTxNameRu("intertype"+addValue);
   await sitepage.setTxNameBr("intertype"+addValue);
   await sitepage.setTxNameTu("intertype"+addValue);
   return "intertype"+addValue;
  }

  //"intertypemation demo data "+ this.randomString(5)
  public randomString(value: any) {
    var chars = "0123456789";
    var string_length = value;
    var randomstring = '';
    for (var i = 0; i < string_length; i++) {
      var rnum = Math.floor(Math.random() * chars.length);
      randomstring += chars.substring(rnum, rnum + 1);
    }
    return randomstring;
  }

 public async clickAddButtonInAddForm(){
   await browser.sleep(3000);
   await browser.executeScript('window.scrollTo(0,1000);');
   await element(by.id("au_save_bottom")).click();
   await browser.sleep(3000);
 }
}