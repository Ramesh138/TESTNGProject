import { browser, By, by, element, ExpectedConditions, protractor } from "protractor";
import { WebdriverWebElement } from "protractor/built/element";
import { InterventionLocations_Page } from "../pages/interventionLocatiion_Page";
import {sitePage} from "../pages/sitemanagement_page"
import { labelUtils } from "../utls/labelUtil";


const labelutil: labelUtils = new labelUtils();
const sitepage: sitePage = new sitePage()
const chai = require("chai").use(require("chai-as-promised"));
const expect = chai.expect;

export class IntventionLocationMngmnt_Flow {

  public LabelValidation(webelementvalue: WebdriverWebElement, Labele: string,language:any) {
    browser.sleep(1000)
    webelementvalue.getText().then(function (LabelValue) {
      if (LabelValue.toString().match(labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language)))) {
        console.log("'" + LabelValue + "'" + "  Expected value is matached with Actual value   " + labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language)))
      } else {
        var actual =LabelValue
        var expected=labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language))
        console.log(actual+" is not matching vth expected "+expected)
        expect(actual==expected).to.equal(true)
      }
    })
  }


  public async LabelValidationAll(language:string) {
    await browser.sleep(2000)
    this.LabelValidation(InterventionLocations_Page.getPageHeader().getElement(), "RechercheDesDonnees",language)
    this.LabelValidation(InterventionLocations_Page.getSatus().getElement(), "Etat",language)
    this.LabelValidation(InterventionLocations_Page.getRactive().getElement(), "Active",language)
    this.LabelValidation(InterventionLocations_Page.getRinactive().getElement(), "Inactif",language)
    this.LabelValidation(InterventionLocations_Page.getRall().getElement(), "Tout",language)
    this.LabelValidation(InterventionLocations_Page.getTHname().getElement(), "Intitule",language)
    this.LabelValidation(InterventionLocations_Page.getTHstatus().getElement(), "Etat",language)
    this.LabelValidation(InterventionLocations_Page.getTHdescription().getElement(), "Designation",language)
    this.LabelValidation(InterventionLocations_Page.getTHorder().getElement(), "Ordre",language)
    // this.LabelValidation(itm.getBadd().getElement(), "BoutonAjouter")
    this.LabelValidation(InterventionLocations_Page.getBsort().getElement(), "BoutonOrdonner",language)
    this.LabelValidation(InterventionLocations_Page.getBcancel().getElement(), "BoutonAnnuler",language)
    this.LabelValidation(InterventionLocations_Page.getSectionHeader().getElement(), "ListeDesDonneesDeType",language)
  }

  public selectSiteValue() {
    InterventionLocations_Page.getsiteDp().getElements().count().then(function(value){
      InterventionLocations_Page.getsiteDp().clickByIndex(value-1)
      console.log("'" + value + "'" + "Size value is defined  ")
    })
  }



  public async verifyAlertmessage() {
    var message:any;
    let abc = await browser.switchTo().alert();
    await abc.getText().then(function (message) {
      console.log(message + " message is succesfully verified")
    })
    await abc.accept();
  }

  async interLocCreation() {
    await browser.sleep(2000)
    var addValue=this.randomString(4);
   await sitepage.setTxNameFr("interLoc"+addValue);
   await sitepage.setTxNameEn("interLoc"+addValue);
   await sitepage.setTxNameSp("interLoc"+addValue);
   await sitepage.setTxNamePo("interLoc"+addValue);
   await sitepage.setTxNameRo("interLoc"+addValue);
   await sitepage.setTxNameRu("interLoc"+addValue);
   await sitepage.setTxNameBr("interLoc"+addValue);
   await sitepage.setTxNameTu("interLoc"+addValue);
   return "interLoc"+addValue;
  }

  //"interLocmation demo data "+ this.randomString(5)
  public randomString(value: any) {
    var chars = "0123456789";
    var string_length = value;
    var randomstring = '';
    for (var i = 0; i < string_length; i++) {
      var rnum = Math.floor(Math.random() * chars.length);
      randomstring += chars.substring(rnum, rnum + 1);
    }
    return randomstring;
  }

 public async clickAddButtonInAddForm(){
   await browser.sleep(3000);
   await browser.executeScript('window.scrollTo(0,1000);');
   await element(by.id("au_save_bottom")).click();
   await browser.sleep(3000);
 }
}