import { browser, By, by, element, ExpectedConditions, protractor } from "protractor";
import { WebdriverWebElement } from "protractor/built/element";
import { sitePage } from "../pages/sitemanagement_page";
import { Alert } from "selenium-webdriver";
import { labelUtils } from "../utls/labelUtil";


const labelutil: labelUtils = new labelUtils();
const sitepage: sitePage = new sitePage()
const fs = require('fs');

export class site_Flow {

  public LabelValidation(webelementvalue: WebdriverWebElement, Labele: string,language:any) {
    browser.sleep(1000)
    webelementvalue.getText().then(function (LabelValue) {
      if (LabelValue.toString().match(labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language)))) {
        console.log("'" + LabelValue + "'" + "  Expected value is matached with Actual value   " + labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language)))
      } else {
        throw new Error(labelutil.getlabelmethod(Labele,labelutil.getlabelmethodvthlanguage(language)) + " Expected value is not matached with Actual value " + LabelValue)
      }
    })
  }


  public async LabelValidationAll(language:string) {
    await browser.sleep(2000)
    this.LabelValidation(sitepage.getPageHeader().getElement(), "RechercheDesDonnees",language)
    this.LabelValidation(sitepage.getSatus().getElement(), "Etat",language)
    this.LabelValidation(sitepage.getRactive().getElement(), "Active",language)
    this.LabelValidation(sitepage.getRinactive().getElement(), "Inactif",language)
    this.LabelValidation(sitepage.getRall().getElement(), "Tout",language)
    this.LabelValidation(sitepage.getTHname().getElement(), "Intitule",language)
    this.LabelValidation(sitepage.getTHstatus().getElement(), "Etat",language)
    this.LabelValidation(sitepage.getTHdescription().getElement(), "Designation",language)
    this.LabelValidation(sitepage.getTHorder().getElement(), "Ordre",language)
    // this.LabelValidation(sitepage.getBadd().getElement(), "BoutonAjouter")
    this.LabelValidation(sitepage.getBsort().getElement(), "BoutonOrdonner",language)
    this.LabelValidation(sitepage.getBcancel().getElement(), "BoutonAnnuler",language)
    this.LabelValidation(sitepage.getSectionHeader().getElement(), "ListeDesDonneesDeType",language)
  }

  public async LabelValidation_Sitemanagement_HomePage(language:string) {
    await browser.sleep(2000)
    this.LabelValidation(sitepage.getPageHeader().getElement(), "RechercheDesDonnees",language)
    this.LabelValidation(sitepage.getSatus().getElement(), "Etat",language)
    this.LabelValidation(sitepage.getRactive().getElement(), "Active",language)
    this.LabelValidation(sitepage.getRinactive().getElement(), "Inactif",language)
    this.LabelValidation(sitepage.getRall().getElement(), "Tout",language)
    this.LabelValidation(sitepage.getTHname().getElement(), "Intitule",language)
    this.LabelValidation(sitepage.getTHstatus().getElement(), "Etat",language)
    this.LabelValidation(sitepage.getTHdescription().getElement(), "Designation",language)
    this.LabelValidation(sitepage.getTHorder().getElement(), "Ordre",language)
    // this.LabelValidation(sitepage.getBadd().getElement(), "BoutonAjouter")
    this.LabelValidation(sitepage.getBsort().getElement(), "BoutonOrdonner",language)
    this.LabelValidation(sitepage.getBcancel().getElement(), "BoutonAnnuler",language)
    this.LabelValidation(sitepage.getSectionHeader().getElement(), "ListeDesDonneesDeType",language)
    console.log("end")
  }
  public async clickadd() {
    await browser.sleep(2000)
    await browser.executeScript('window.scrollTo(0,1000);').then(function () {
    })
    await sitepage.getBadd().getElement().click();
  }



  public async clickCancel() {
    await browser.executeScript('window.scrollTo(0,1000);').then(function () {
    })
   await sitepage.getBcancel().click("Clicked on Cancel menu button");
  }

  public async clickABadd() {
    browser.executeScript('window.scrollTo(0,1000);').then(function () {
    })
    await browser.sleep(2000);
    sitepage.getABadd().click();
  }

  public async clickABCancel() {
    browser.executeScript('window.scrollTo(0,40000);').then(function () {
    })
    await sitepage.getABcancel().click("Clicked on Cancel menu button");

  }

  public clickActive() {
    browser.executeScript('window.scrollTo(1000,0);').then(function () {
    })
    return sitepage.getRBactive().click("click on the  Active Radio Button ")
  }

  public clickInActive() {
    browser.executeScript('window.scrollTo(1000,0);').then(function () {
    })
    sitepage.getRBinactive().click("click on InActive Radio button ")
  }

  verifyAdminHomePage() {
    browser.sleep(1000)
    browser.sleep(2000).then(() => {
      //  this.LabelValidation(AdminPage.getLSiteManagement().getElement(), "administrationgestionSiteChoix")
    })
  }

  public async clickSort() {
    await browser.executeScript('window.scrollTo(0,1000);');
    await element(by.xpath(".//a[@id='au_order_btn']")).click()
  }

  public VerifyingactiveInactiveStatcus(status: string) {
    browser.executeScript('window.scrollTo(0,50000);').then(function () {
    })
    browser.sleep(1000)
    this.paginationlistverifification(status)
  }

  /**
   * status verification 
   */
  public static statusverificationvalidation(status: string) {
    sitepage.getSearch_listcount().getElements().all(by.xpath("./div/a")).count().then(function (count) {
      sitepage.Search_ActiveValue(count).getText().then(function (value) {
        // verify(value).isEqualTo(status, " Inactive status is verified successfully")
      })
    });
  }

  /**
   * pagination list verifification
   */


  public paginationlistverifification(status: string) {
    if (element(by.xpath(".//*[@id='MyRData']/ngx-datatable/div/datatable-footer/div/div")).getWebElement().isDisplayed().then(function () { })) {
      element(by.xpath(".//*[@id='MyRData']/ngx-datatable/div/datatable-footer/div/div")).getText().then(function (countvalue) {
        let countpfrecords = countvalue.toString()
        let noofrecordsintheresultgrid = countpfrecords.split(' ')
        let connum = Number(noofrecordsintheresultgrid[0]);
        if (connum = 0) {
          //  log("no records is displaying in result grid")
          console.log("no records is displaying in result grid")
        }
        if (connum > 0 && connum <= 20) {
          //  log("no of records is less than  20   records")
          console.log("no of records is less than  20   records")
          site_Flow.statusverificationvalidation(status);
        } else if (connum > 20 && connum <= 100) {
          sitepage.getpagn_listvalue().getElement().getSize().then(function (listsizevaluee) {
            //log("no of records is greater than  20   records and less than 20  records")
            console.log("no of records is greater than  20   records and less than 20  records")
            // sitepage.getpagn_listvalue().getElement().get(listsizevaluee).click()
          })
          site_Flow.statusverificationvalidation(status);
        } else if (connum > 100) {
          sitepage.getpagn_last().click();
          site_Flow.statusverificationvalidation(status);
        }
      })
    }
  }


  public static navigateToLastPage() {
    if (element(by.xpath(".//*[@id='MyRData']/ngx-datatable/div/datatable-footer/div/div")).getWebElement().isDisplayed().then(function () { })) {
      element(by.xpath(".//*[@id='MyRData']/ngx-datatable/div/datatable-footer/div/div")).getText().then(function (countvalue) {
        let countpfrecords = countvalue.toString()
        let noofrecordsintheresultgrid = countpfrecords.split(' ')
        let connum = Number(noofrecordsintheresultgrid[0]);
        if (connum = 0) {
          //  log("no records is displaying in result grid")
          console.log("no records is displaying in result grid")
        }
        if (connum > 0 && connum <= 20) {
          // log("no of records is less than  20   records")
          console.log("no of records is less than  20   records")

        } else if (connum > 20 && connum <= 100) {
          sitepage.getpagn_listvalue().getElement().getSize().then(function (listsizevaluee) {
            //  log("no of records is greater than  20   records and less than 20  records")
            console.log("no of records is greater than  20   records and less than 20  records")
            // sitepage.getpagn_listvalue().getElement().get(listsizevaluee).click()
          })

        } else if (connum > 100) {
          sitepage.getpagn_last().click();

        }
      })
    }
  }
  public createrecordVerification() {
    browser.sleep(1000)
    browser.executeScript('window.scrollTo(0,10000);').then(function () {
    })
    sitepage.getSearch_listcount().getElements().all(by.xpath("./div/a")).count().then(function (count) {
      sitepage.Search_Value(count).getText().then(function (value) {
        console.log("value " + value)
        // commonutils.createJsonfile(objectValue, value, actualFile)
        // commonutils.connectionDatabase("SELECT * FROM TRV_TB01_LIB_LIBELLE WHERE INTITULE LIKE '" + value + "%'", expectedFile, objectValue);
      })
    });
  }

  public statusVerifications(status: string) {
    browser.sleep(1000)
    if (sitepage.getSearch_listcount().isEnabled) {
      browser.executeScript('window.scrollTo(0,10000);').then(function () {
        sitepage.getSearch_listcount().getElements().all(by.xpath("./div/a")).count().then(function (count) {
          sitepage.getTHstatus().click()
          for (let index = 1; index < count; index++) {
            sitepage.Search_ActiveValue(count).getText().then(function (value) {
              // verify(value).isEqualTo(status, "Actual status is matching with expected Satatus")
              console.log(value + "  Actual value is matching with the Expected value " + status)
            })
          }
        });
      })
    } else {
      // log("no data availble in the  Search result grid ")
    }
  }

  /**
   * sortcancelopertion
   */

  public async clickSortButton() {
    // WaitFor.waitForVisibilityOf(sitepage.getBsort().getElement())
    await browser.executeScript('window.scrollTo(0,10000);').then(function () {
    })
    await sitepage.getBsort().click("click on the Sort button");
  }


  public clickCancelButton() {
    // WaitFor.waitForVisibilityOf(sitepage.getSBCancel().getElement())
    sitepage.getSBCancel().click("click on the Cancel button");

  }
  public async sortcancelopertion() {
    browser.executeScript('window.scrollTo(0,10000);').then(function () {
    })
    this.clickSortButton()
  }

  public async getfirstcoloumnValueInResult(indexvalue: string) {
    var xpathvalue = "datatable-row-wrapper:nth-child(" + indexvalue + ") a";

    var value = await element(by.css(xpathvalue)).getText();

    return value;

  }

  public async getfirstcoloumnValueOfOrderInResult() {
    var xpathvalue = "//*[@id='MyRData']/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[4]/div/span";

    var value = await element(by.xpath(xpathvalue)).getText();

    return value;

  }

  public async getfirstcoloumnValueOfStatusInResult() {
    var xpathvalue = "//*[@id='MyRData']/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span[2]";

    var value = await element(by.xpath(xpathvalue)).getText();

    return value;

  }

  /**
   * verifySortHome Page 
   */
  public verifySortHomePage(language:string) {
    this.LabelValidation(sitepage.getSatus().getElement(), "Etat",language)
  }

  /**
   * verifyAlertmessage
   */
  public verifyAlertmessage() {
    // browser.manage().timeouts().implicitlyWait(30000)
    browser.sleep(2000).then(() => {
      this.clickadd();
    })
    let abc: Alert = browser.switchTo().alert();
    abc.getText().then(function (message) {
      //log(message + " message is succesfully verified")
    })
    abc.accept();
  }

  public SortValueVerifications() {
    browser.sleep(1000)
    if (sitepage.getSearch_listcount().isEnabled) {
      browser.executeScript('window.scrollTo(0,10000);').then(function () {
        sitepage.getSearch_listcount().getElements().all(by.xpath("./div/a")).count().then(function (count) {
          if (count >= 2) {
            sitepage.getBsort().click()
            // log("click on the up Sort button")
            console.log("click on the up Sort button")
            browser.sleep(1000)
            // sitepage.getSortValue().clickByIndex(2);
            sitepage.getSortValue1().getElements().all(by.xpath("./option[2]")).getText().then(function (count) {
              // log(count + "  is selected from the  list box")
              sitepage.getUpdata().click()
              //  log("click on the up arrow button")
              browser.sleep(1000)
              sitepage.getBadd()
              // log("click on the save  button")
              browser.sleep(100000)
              sitepage.Search_Value(1).getText().then(function (value1) {
                //   verify(value1).isEqualTo(count)
              })
            })

          }
        });
      })
    } else {
      //  log("no data availble in the  Search result grid ")
    }
  }

  verifyDbVthApp() {
    var sheetnumber1 = fs.readFileSync('TestfileName.txt')
    // expect(Actual.site).toEqual(Expected.site);
    //  log( "Actual Value is succesfully matched with the Expecetd Value" )
  }

  verifypaginationlistpages() {
    if (sitepage.getPagecount().isEnabled) {
      browser.executeScript('window.scrollTo(0,10000);').then(function () {
      })
    }
    browser.sleep(500)
    if (sitepage.getPagecount().isDisplayed()) {
      sitepage.getPagecount().getElement().getText().then(function (LabelValue) {
        let psize = LabelValue.split(" ");
        let pvalue = psize[0];
        let connum = Math.floor(Number(pvalue) / 10);
        let connum1 = Math.ceil(Number(pvalue) / 10);
        // log("'" + connum1 + "'" + "Expected value is matached with Actual value ")
        //  log("'" + connum + "'" + "Expected value is matached with Actual value ")
        if (!(connum == 0)) {
          for (let i = 1; i < connum - 1 && i < 5; i++) {
            browser.sleep(1000)
            if (sitepage.getpagn_previous().isEnabled) {
              browser.executeScript('window.scrollTo(0,10000);').then(function () {
              })
            }
            site_Flow.pagn_num(i).click();
            // log(i + ' page navigated and verified data succesfully')
          }
          for (let i = 1; i < connum - 1 && i < 5; i++) {
            browser.sleep(1000)
            if (sitepage.getpagn_previous().isEnabled) {
              browser.executeScript('window.scrollTo(0,10000);').then(function () {
              })
            }
            sitepage.getpagn_previous().click()
            // log(i + ' previous page link  is navigated and verified data succesfully ')
          }
          for (let i = 1; i <= connum - 1 && i < 5; i++) {
            browser.sleep(1000)
            if (sitepage.getpagn_previous().isEnabled) {
              browser.executeScript('window.scrollTo(0,10000);').then(function () {
              })
            }
            sitepage.getpagn_next().click()
            //  log(i + ' next page link  is navigated and verified data succesfully')

          }
          for (let i = 1; i <= 1; i++) {
            browser.sleep(1000)
            if (sitepage.getpagn_previous().isEnabled) {
              browser.executeScript('window.scrollTo(0,10000);').then(function () {
              })
            }
            sitepage.getpagn_first().click()
            // log(' first page link  is navigated and verified data succesfully ')

          }
          for (let i = 1; i <= 1; i++) {
            browser.sleep(1000)
            if (sitepage.getpagn_previous().isEnabled) {
              browser.executeScript('window.scrollTo(0,10000);').then(function () {
              })
            }
            // sitepage.getpagn_last().click()
            //  log(' next page link  is navigated and verified data succesfully ')
            browser.executeScript('window.scrollTo(0,10000);').then(function () {
            })
          }
        }
        else {
          //log('no pagination is available')
          return null
        }
      });
    }

  }
  static pagn_num(i: number): any {
    return element(By.xpath('.//datatable-pager/ul/li[' + i + ']/a'))
  }

  public clickActiveInactiveBtn() {
    // WaitFor.waitForVisibilityOf(sitepage.getActiveYN().getElement())
    sitepage.getActiveYN().click("click on the Active inactive  button");
    browser.pause(2000)
  }
  async verify_siteCreation_Active_inactive() {
    this.clickadd();
    sitepage.setTxNameFr(this.randomString(4) + "_Fr")
    sitepage.setTxNameEn(this.randomString(4) + "_EN")
    sitepage.setTxNameSp(this.randomString(4) + "_SP")
    sitepage.setTxNamePo(this.randomString(4) + "_Po")
    sitepage.setTxNameRo(this.randomString(4) + "_RO")
    sitepage.setTxNameRu(this.randomString(4) + "_RU")
    sitepage.setTxNameBr(this.randomString(4) + "_BR")
    sitepage.setTxNameTu(this.randomString(4) + "_Tu")
    this.clickActiveInactiveBtn()
    this.clickABadd();
  }


  async siteCreation() {
    await browser.sleep(2000)
    var addValue=this.randomString(4);
   await sitepage.setTxNameFr("site"+addValue);
   await sitepage.setTxNameEn("site"+addValue);
   await sitepage.setTxNameSp("site"+addValue);
   await sitepage.setTxNamePo("site"+addValue);
   await sitepage.setTxNameRo("site"+addValue);
   await sitepage.setTxNameRu("site"+addValue);
   await sitepage.setTxNameBr("site"+addValue);
   await sitepage.setTxNameTu("site"+addValue);
   return "site"+addValue;
  }

  //"automation demo data "+ this.randomString(5)
  public randomString(value: any) {
    var chars = "0123456789";
    var string_length = value;
    var randomstring = '';
    for (var i = 0; i < string_length; i++) {
      var rnum = Math.floor(Math.random() * chars.length);
      randomstring += chars.substring(rnum, rnum + 1);
    }
    return randomstring;
  }

 public async navigateToLastpage(){
  await browser.executeScript('window.scrollTo(0,1000);').then(function () {
  })
  if(sitepage.getPagecount().getElement().isDisplayed().then(async function(){    
  })){
    
    console.log(" naviagation ")
    var pagecountvalue= await sitepage.getPagecount().getElement().getText();
    console.log(pagecountvalue)
    var countpfrecords = pagecountvalue.toString()
    console.log(countpfrecords)
    var noofrecordsintheresultgrid = countpfrecords.split(' ')
    console.log(noofrecordsintheresultgrid)
    var countvalue = Number(noofrecordsintheresultgrid[0]);
    console.log(countvalue)
    if(countvalue>20){
      await browser.executeScript('window.scrollTo(0,1000);').then(function () {
      })
      await sitepage.getpagn_last().getElement().click();
      console.log("Naviagate to the last page ")
      browser.sleep(3000)
    }else{
      console.log("There is no last page in the pagination ")
    }
  };

 }

}

