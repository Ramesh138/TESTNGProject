const mysql = require('mysql');
const connection = mysql.createConnection({
  host:"s2946ads.mc2.renault.fr", //"s2946ads.mc2.renault.fr",
  user: "trv_adm",//"trv_adm",
  password: "trv_adm_int01",//"trv_adm_01",
  database: "trv_db_01",
  port : "3307",
});
connection.connect((err) => {
  if (err) throw err;
  console.log('Connected!');
});

var sql = "SELECT COUNT(*) as Number FROM TRV_TB01_TRAVAUX_DEMANDES WHERE PRECISION_LIEU= 'SpecifiedLocation_PJSMZA';";
connection.query(sql,
  (err, rows) => {
    if(err) throw err;
    console.log(rows);
  }
);
connection.end(async (err) => {
  if (err) throw err;
  console.log('end!');
});