package com.rntbci.insertdatabase;


import java.io.FileInputStream;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Connection;
 

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;
 
 
 
public class EXCELTODB {
 
   
    public static void main(String[] args) {
        try{
        	
        	System.out.println("hai vel");
            Class.forName("org.postgresql.Driver");
            Connection con = (Connection) DriverManager.getConnection("jdbc:postgresql://localhost/excel","postgres","postgres");
            con.setAutoCommit(false);
            PreparedStatement pstm = null ;
            FileInputStream input = new FileInputStream("D:\\LocalData\\z018746\\data\\test1.xls");
            POIFSFileSystem fs = new POIFSFileSystem( input );
            HSSFWorkbook wb = new HSSFWorkbook(fs);
            HSSFSheet sheet = wb.getSheetAt(0);
            Row row;
            
            for(int i=1; i<=sheet.getLastRowNum(); i++){
                row = sheet.getRow(i);
                int cell = row.getLastCellNum();
                System.out.println("cell" + cell);
       
                String sql = "INSERT INTO exc_data VALUES(";
                for(int j=0;j<cell-1;j++){
                	
                	sql += "'"+row.getCell(j).getStringCellValue()+"',";
                }
                sql += "'"+row.getCell(cell-1).getStringCellValue()+"')";
                
                System.out.println("sql " + sql );
                //String sql = "INSERT INTO exc_data VALUES('"+row.getCell(0).getStringCellValue()+"','"+row.getCell(1).getStringCellValue()+"','"+row.getCell(2).getStringCellValue()+"')";
                pstm = (PreparedStatement) con.prepareStatement(sql);
                pstm.execute();
                System.out.println("Import rows "+i);
            }
            con.commit();
            input.close();
            System.out.println("Success import excel to mysql table");
        }catch(ClassNotFoundException e){
            System.out.println(e);
        }catch(SQLException ex){
            System.out.println(ex);
        }catch(IOException ioe){
            System.out.println(ioe);
        }
 
    }
}
