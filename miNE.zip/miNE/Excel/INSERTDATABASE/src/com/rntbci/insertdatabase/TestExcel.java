package com.rntbci.insertdatabase;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;



import java.sql.Statement;
import java.text.SimpleDateFormat;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class TestExcel {

	public static void main(String[] args) {
        try{
        	
            Class.forName("org.postgresql.Driver");
            Connection con = (Connection) DriverManager.getConnection("jdbc:postgresql://localhost/excel","postgres","postgres");
            con.setAutoCommit(false);
            //PreparedStatement pstm = null ;
            FileInputStream input = new FileInputStream("D:\\LocalData\\z018746\\data\\tabletest.xls");
            POIFSFileSystem fs = new POIFSFileSystem( input );
            HSSFWorkbook wb = new HSSFWorkbook(fs);
            HSSFSheet sheet = wb.getSheetAt(0);
            Row row;
            row = sheet.getRow(0);
            String table = row.getCell(0).getStringCellValue();
            String sql = "";
            
            //pstm = (PreparedStatement) con.prepareStatement(sql);
            Statement stmt = con.createStatement();
            
            for(int i=2; i<=sheet.getLastRowNum(); i++){
                row = sheet.getRow(i);
                int cell = row.getLastCellNum();
                System.out.println("cell" + cell);     
                
                sql = "INSERT INTO " +  table + " VALUES(";
         

                for(int j=0;j<cell-1;j++){
                	
                	HSSFCell celx = sheet.getRow(i).getCell(j);
                	             	
                    if (celx.getCellType() == HSSFCell.CELL_TYPE_STRING){
                    	
                    	sql += "'"+celx.getStringCellValue()+ "',";                	
                    }   
                	if (celx.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
                		               		
                		if (HSSFDateUtil.isCellDateFormatted(celx)) {
                        	
                			//double date = HSSFDateUtil.getExcelDate(celx.getDateCellValue());
                			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                			String  date =  sdf.format(celx.getDateCellValue());
                    		sql += "'"+ date + "',";
                        }
                	}
                	if (celx.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
                		
                		sql += "'"+celx.getNumericCellValue()+ "',";
                	} 
        
                	
                    if (celx.getCellType() == HSSFCell.CELL_TYPE_BLANK){
                		
                		sql += "'"+ "',";
                	}
                    if(celx.getStringCellValue().equals("<NULL>")){
                    	
                    	sql += "'"+ "',";
                    }
                }
                
                HSSFCell cely = sheet.getRow(i).getCell(cell-1);              
                if (cely.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
                	
            		sql += "'"+cely.getNumericCellValue()+"')";
            	}      
                if (cely.getCellType() == HSSFCell.CELL_TYPE_STRING){
                	
                	if(cely.getStringCellValue().equals("<NULL>")){
                    	
                    	sql += "'"+"')";
                    }
                	else{
                	    sql += "'"+cely.getStringCellValue()+"')";
                	}
                }  
                if (cely.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
        			
            		if (HSSFDateUtil.isCellDateFormatted(cely)) {
                    	
                		sql += "'"+ cely.getDateCellValue()+"')";
                    }
                }
  
                if (cely.getCellType() == HSSFCell.CELL_TYPE_BLANK){
            		
            		sql += "'"+ "',";
            	}
                
                stmt.addBatch(sql);
                              
                System.out.println("sql " + sql );
           

            }
                //String sql = "INSERT INTO exc_data VALUES('"+row.getCell(0).getStringCellValue()+"','"+row.getCell(1).getStringCellValue()+"','"+row.getCell(2).getStringCellValue()+"')";
             
            //pstm = (PreparedStatement) con.prepareStatement(sql);
            System.out.println("hjnh");
            stmt.executeBatch();
            //pstm.execute();
            con.commit();
            input.close();
            System.out.println("Success import excel to mysql table");
        }catch(ClassNotFoundException e){
            System.out.println(e);
        }catch(SQLException ex){
            System.out.println(ex);
        }catch(IOException ioe){
            System.out.println(ioe);
        }
 
    }
}
