/**
 * 
 */
package newpackage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Writer;
import java.util.Iterator;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * @author z013959
 *
 */
public class sampleExcelReader {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws InvalidFormatException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws IOException, InvalidFormatException {
		// TODO Auto-generated method stub
String filepath = "D:\\Public\\CompanyTask\\MyExcelFile.xlsx";
String outfile = "D:\\Public\\CompanyTask\\outputfile.hql";

	FileInputStream inputstream = new FileInputStream(new File(filepath));
	
//	PrintStream outputstream = new PrintStream(new FileOutputStream(outfile),true,"UTF-8");
	
	PrintStream outputstream = new PrintStream(new FileOutputStream(new File(outfile)));
	
//	FileOutputStream outputstream = new FileOutputStream(new File(outfile));
//	PrintWriter outputstream = new PrintWriter(new FileWriter(outfile));
	
//	byte[] bom = {(byte)0xEF, (byte)0xBB, (byte)0xBF};
	
//	byte[] bom = filepath.getBytes();
	
	//PrintStream out = new PrintStream(new FileOutputStream(csvFile),
      //      true, "UTF-8");
	
//	Workbook workbook = new XSSFWorkbook(inputstream);
	
//	Workbook workbook = WorkbookFactory.create(inputstream);
	
	Writer out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outfile),"UTF-8"));
	
	XSSFWorkbook workbook = new XSSFWorkbook(inputstream);
	
	Sheet firstSheet = workbook.getSheetAt(0);
	
	Iterator<Row> rowIterator = firstSheet.iterator();
	
		
	while(rowIterator.hasNext()){
		Row nextRow = rowIterator.next();
		Iterator<Cell> cellIterator = nextRow.cellIterator();
		
		while(cellIterator.hasNext()){
			Cell cell = cellIterator.next();
			
			switch(cell.getCellType()){
				
				case Cell.CELL_TYPE_STRING:
					System.out.println(cell.getStringCellValue());
					break;
					
				case Cell.CELL_TYPE_BOOLEAN:
					System.out.println(cell.getBooleanCellValue());
					break;
					
				case Cell.CELL_TYPE_NUMERIC:
					System.out.println(cell.getNumericCellValue());
					break;
					
				case Cell.CELL_TYPE_FORMULA:
					System.out.println(cell.getCellFormula());
					
			}
	//		System.out.println(" - ");
			
		}
	System.out.println();
	
//	out.append("Website UTF-8").append("\r\n");
	
//	out.append("?? UTF-8").append("\r\n");
//	out.append("??????? UTF-8").append("\r\n");
		
	}
	workbook.write(outputstream);
//	workbook.write(bom);
//	outputstream.write(bom);
//((FileInputStream) workbook).close();

	inputstream.close();
	outputstream.flush();
	outputstream.close();
	
//out.flush();
//out.close();
//workbook = new XSSFWorkbook(new FileInputStream(outfile));
	}

}
