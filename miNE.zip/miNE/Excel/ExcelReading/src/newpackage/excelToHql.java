/**
 * 
 */
package newpackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



/**
 * @author z013959
 *
 */
public class excelToHql {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException  {
		// TODO Auto-generated method stub
		File inputFile=new File("D:\\Public\\CompanyTask\\MyExcelFile.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(inputFile));		
		int sheetNo = Integer.parseInt("0");
		StringBuffer data = new StringBuffer();
		
		XSSFFormulaEvaluator fe = null;
		    fe = wb.getCreationHelper().createFormulaEvaluator();
			PrintStream out = new PrintStream(new FileOutputStream(new File("D:\\Public\\CompanyTask\\MyHQLlFile.hql")),
                true, "UTF-8");
byte[] bom = {(byte)0xEF, (byte)0xBB, (byte)0xBF};
out.write(bom);
{

	XSSFSheet sheet = wb.getSheetAt(sheetNo);
	
	for (int r = 0, rn = sheet.getLastRowNum() ; r <= rn ; r++) {
        XSSFRow row = sheet.getRow(r);
        if ( row == null )
        {
        out.println(','); 
        continue;
        }
        boolean firstCell = true;
        for (int c = 0, cn = row.getLastCellNum() ; c < cn ; c++) {
        	XSSFCell cell = row.getCell(c, row.RETURN_BLANK_AS_NULL);
            if ( ! firstCell ) out.print(',');
            if ( cell != null ) {
                if ( fe != null ) cell = fe.evaluateInCell(cell);
                switch (cell.getCellType()) 
                {
                case Cell.CELL_TYPE_BOOLEAN:
                        data.append(cell.getBooleanCellValue() + ",");
                        break;

                case Cell.CELL_TYPE_NUMERIC:
                        data.append(cell.getNumericCellValue() + " ");
                        break;

                case Cell.CELL_TYPE_STRING:
                        data.append(cell.getStringCellValue() + " ");
                        break;

                case Cell.CELL_TYPE_BLANK:
                        data.append("" + ",");
                        break;

               default:
                        data.append(cell + ",");
                }

                out.print(data.toString());
            }
            firstCell = false;
        }
        out.println();
    }
		
	}
		
	}

}
