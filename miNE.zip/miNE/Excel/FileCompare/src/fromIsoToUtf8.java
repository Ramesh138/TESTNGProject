import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * 
 */

/**
 * @author z013959
 *
 */
public class fromIsoToUtf8 {

	/**
	 * @param args
	 */
	static File input = new File("D:/Public/Analysis/taskdetector/IDeleteDA.java");
    static File output = new File("D:/Public/Analysis/taskdetector/conv/IDeleteDA.java");
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		 BufferedReader br = null;

	        FileWriter fileWriter = new FileWriter(output);
	        try {

	            String sCurrentLine;

	            br = new BufferedReader(new FileReader( input ));

	            int i= 0;
	            while ((sCurrentLine = br.readLine()) != null) {
	                byte[] utfB =  encode( sCurrentLine.getBytes() );
	                fileWriter.write(new String(utfB, Charset.forName("UTF-8") ) );
	                fileWriter.write("\n");
	                System.out.println( i++ );
	            }

	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                fileWriter.flush();
	                fileWriter.close();
	                if (br != null)br.close();
	            } catch (IOException ex) {
	                ex.printStackTrace();
	            }
	        }
		

	}
	
	
	
	static byte[] encode(byte[] arr){
        Charset iso88591charset = Charset.forName("Shift-JIS");
        Charset utf8charset = Charset.forName("UTF-8");

        ByteBuffer inputBuffer = ByteBuffer.wrap( arr );

        // decode ISO-8559-1
        CharBuffer data = iso88591charset.decode(inputBuffer);

        // encode UTF-8
        ByteBuffer outputBuffer = utf8charset.encode(data);
        byte[] outputData = outputBuffer.array();

        return outputData;
    }
	
	
	
}
