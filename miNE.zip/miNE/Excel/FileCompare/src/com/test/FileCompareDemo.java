package com.test;

import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import javax.mail.Folder;

/**
 * @author z013959
 *
 */
public class FileCompareDemo {

	private ResourceBundle resource;

	private String s1;

	private String s2;

	private static String d1;

	private static String d2;
	
	public FileCompareDemo() {
		resource = ResourceBundle.getBundle("test");

		s1 = resource.getString("s1");

		s2 = resource.getString("s2");

		d1 = resource.getString("d1");

		d2 = resource.getString("d2");

		File sourceFolder1 = new File(s1);
		File[] listOfFiles1 = sourceFolder1.listFiles();

		File sourceFolder2 = new File(s2);
		File[] listOfFiles2 = sourceFolder2.listFiles();
		
		//Object destFldr1 = null;
		//Object destFldr2 = null;
	
		// -------aditionally added-------
		
		//Zip file name        
	    String destinationZipFilePath1 = "F1";
	    String destinationZipFilePath2 = "F2";

	    // Directory to be Zipped
	    String directoryToBeZipped1 = "d1";
	    String directoryToBeZipped2 = "d2";
	    
		//Folder directory1ToZip = null;
		//Folder directory2ToZip = null;
				
		moveNonExistingFiles(listOfFiles1, listOfFiles2);
		
	}

	public void moveNonExistingFiles(File[] listOfFiles1, File[] listOfFiles2) {
		
		for (int i = 0; i < listOfFiles1.length; i++) {
			if (listOfFiles1[i].isFile()) {
				System.out.println("FileNameIs: " + listOfFiles1[i].getName());
				String filename = listOfFiles1[i].getName();

				boolean existing = new File(s2 + "/" + filename).exists();
				System.out.println("Same file in source and destination : "
						+ existing);

				if (!existing) {

					System.out.println("moving");

					//boolean destFldr1 = 
							
						listOfFiles1[i].renameTo(new File(d1 + "/"
							+ listOfFiles1[i].getName()));

					System.out.println("moved");

					}
			}
				
		for (int j = 0; j < listOfFiles2.length; j++) {
			if (listOfFiles2[j].isFile()) {
				System.out.println("FileNameIs: " + listOfFiles2[j].getName());
				String filename = listOfFiles2[j].getName();

				boolean existing = new File(s1 + "/" + filename).exists();
				System.out.println("Same file in source and destination : "
						+ existing);

				if (!existing) {

					System.out.println("moving");

					
				//	boolean destFldr2 =
							
						listOfFiles2[j].renameTo(new File(d2 + "/"
							+ listOfFiles2[j].getName()));

					System.out.println("moved");

					}
			}			
		
		}
			
		}
		
	}
		
	public static void main(String args[]) throws IOException, NoSuchAlgorithmException, ZipException {
		
		// ZipParameters zipParameters = new ZipParameters();
		 
		String destinationZipFilePath1 = null;
		ZipFile zipFile1 = new ZipFile(destinationZipFilePath1);
		String destinationZipFilePath2 = null;
		ZipFile zipFile2 = new ZipFile(destinationZipFilePath2);
		
		FileCompareDemo zipParameters = new FileCompareDemo();
		 
		Object directoryToBeZipped1;
	//    ((FileCompareDemo) zipFile1).moveNonExistingFiles(directoryToBeZipped1,zipParameters);
			
		Object directoryToBeZipped2;
	//	((FileCompareDemo) zipFile2).moveNonExistingFiles(directoryToBeZipped2,zipParameters);
		}

	private void moveNonExistingFiles(Object directoryToBeZipped1,
			FileCompareDemo zipParameters) {
		// TODO Auto-generated method stub
		
	}

}
