package com.test;

import java.io.File;
import java.util.ArrayList;
import java.util.ResourceBundle;
import org.jboss.as.controller.client.helpers.domain.AddDeploymentPlanBuilder;
import org.jboss.as.controller.client.helpers.domain.DeploymentPlanBuilder;
public class DefCls {
	
	private ResourceBundle resource;
	
	private String s1;

	private String s2;

	private String d1;

	private String d2;
	
	//ArrayList
	ArrayList<String> fileNames1 = null;
	ArrayList<String> fileNames2 = null;
	
	public DefCls(){
		
		resource = ResourceBundle.getBundle("test");
		
		File sourceFolder1 = new File(s1);
		File sourceFolder2 = new File(s2);
		
		// get list of files
		File[] listOfFiles1 = sourceFolder1.listFiles();
		File[] listOfFiles2 = sourceFolder2.listFiles();
		
		//	moveNonExistingFiles(listOfFiles1);
		
		//moveNonExistingFiles(listOfFiles2);
	}
	private void moveNonExistingFiles(File[] listOfFiles1, File[] listOfFiles2 ) {
		
			fileNames1 =new ArrayList<String>();
			fileNames2 = new ArrayList<String>();
		// TODO Auto-generated method stub
		for (int i = 0; i < listOfFiles1.length; i++) {
			if (listOfFiles1[i].isFile()) {
				System.out.println("FileNameIs: " + listOfFiles1[i].getName());
				
				//Object fileNames1 = 
						fileNames1.add(listOfFiles1[i].getName());
				//Object fileNames2 = 
						fileNames2.add(listOfFiles2[i].getName());
				
			}
		}
				
		}
	public static void main(String args[]) throws NullPointerException{
		
		new DefCls();
		return;
		
	}
	
		}


