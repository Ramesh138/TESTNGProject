package org.apache.commons.io;

import java.io.File;

public class FileUtils {

	public static void copyFile(String filename, String d1) {
		// TODO Auto-generated method stub
		
	}

}
