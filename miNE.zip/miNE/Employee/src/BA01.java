
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class BA01 {
	
	int DEBUG               =        0  ;   
	String	APP_ID 		=	"BA01"  ;     
	int	OK		    =         0    ;   
	int	NG		   =         -1     ;   
	int	RET_DB_NORMAL	  =           0;       
	int MAX_RCD_INPUT     =        1000 ;      
	static Connection conn = null;
	String g_fken_cd = null;
	String g_skgn_cd = null;
	String g_hs_cd = null;
	String g_tenpo_cd = null;
	
	public Connection getConnection()
	{
		
	//	Statement stmt = null;
		PreparedStatement ps=null;
			
			try {
				Class.forName("org.postgresql.Driver");
			
				conn = (Connection) DriverManager
				        .getConnection("jdbc:postgresql://localhost:5432/Compass",
				        "postgres", "postgres");
				
				System.out.println("hi");
				System.out.println(conn);
			} catch (SQLException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return conn;
				
	}
	
	/*public void BA01_insertWR3_TERI_T(String g_fken_cd,String g_skgn_cd, String g_hs_cd, String g_tenpo_cd, String g_time)
	{
		Connection c1=new BA01().getConnection();

		try {
			
										
			PreparedStatement ps=c1.prepareStatement ("INSERT INTO wr3_teri_t (fken_cd, skgn_cd, hs_cd, tenpo_cd, ins_dt, host_flg ) VALUES  (?,?,?,?,current_timestamp,'0')");
			
			ps.setString(1,g_fken_cd);
			
			ps.setString(2,g_skgn_cd);
			
			ps.setString(3,g_hs_cd);
			
			ps.setString(4,g_tenpo_cd);
		
			ps.executeUpdate();
			
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
	public void BA01_main()
	{
		System.out.println("BA Method--");
		FileReader reader = null;
		try {
			reader = new FileReader("D:\\Public\\CompanyTask\\Host.txt");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader brf = new BufferedReader(reader);
		String temp="";
		Connection c=new BA01().getConnection();
		try {
			
			while ((temp = brf.readLine())!= null) {
				
				String[] fileDatas =temp.split(" "); 
				for (int i = 0; i <fileDatas.length; i++) {
					String line = fileDatas[i];
					Infile inf=new Infile();
					String g_fken_cd =inf.getFken_cd();
					g_fken_cd=line.substring(1, 3);
					String g_skgn_cd=inf.getSkgn_cd();
					g_skgn_cd=line.substring(4, 7);
					String g_hs_cd=inf.getHs_cd();
				    g_hs_cd=line.substring(9, 13);
				    String g_tenpo_cd=inf.getTenpo_cd();
					g_tenpo_cd=line.substring(14, 17);
					String g_data_kbn=inf.getData_kbn();
					 g_data_kbn = line.substring(18, 19);
					 String g_kaigyou=inf.getKaigyou();
					 g_kaigyou=line.substring(20, 21);
													
					System.out.println("for Loop");
					System.out.println("File Dates--->"+fileDatas);
				if(temp.startsWith("I"))
				{
					BA01_insertWR3_TERI_T(g_fken_cd,g_skgn_cd,g_hs_cd,g_tenpo_cd,g_data_kbn);
				}
				else if(temp.startsWith("U"))
				{
					BA01_updateWR3_TERI_T(g_fken_cd,g_skgn_cd,g_hs_cd,g_tenpo_cd,g_data_kbn);
				}
				else if(temp.startsWith("D"))
				{
					BA01_deleteWR3_TERI_T(g_fken_cd,g_skgn_cd, g_hs_cd,g_tenpo_cd,g_data_kbn);
				}
				
				}
				
			}
			c.commit();
		} catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				c.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}	
		
		}

	private void BA01_insertWR3_TERI_T( String g_fken_cd,String g_skgn_cd,
			String g_hs_cd, String g_tenpo_cd, String g_data_kbn) {
		// TODO Auto-generated method stub
		Connection c1=new BA01().getConnection();

		try {
													
			PreparedStatement ps=c1.prepareStatement ("INSERT INTO wr3_teri_t (fken_cd, skgn_cd, hs_cd, tenpo_cd, ins_dt, host_flg ) VALUES  (?,?,?,?,current_timestamp,'0')");
			
			ps.setString(1,g_fken_cd);
			
			ps.setString(2,g_skgn_cd);
			
			ps.setString(3,g_hs_cd);
			
			ps.setString(4,g_tenpo_cd);
		
			ps.executeUpdate();
			
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}

	private void BA01_updateWR3_TERI_T(String g_fken_cd,String g_skgn_cd, String g_hs_cd, String g_tenpo_cd,String g_data_kbn) {
		// TODO Auto-generated method stub
		
		Connection c1=new BA01().getConnection();
		
		try {
			
			PreparedStatement ps=c1.prepareStatement("update wr3_teri_t set ins_dt=current_timestamp where fken_cd=? and skgn_cd=? and hs_cd=? and tenpo_cd=?");
			
			ps.setString(1,g_fken_cd );
			
			ps.setString(2,g_skgn_cd );
			
			ps.setString(3,g_hs_cd );
			
			ps.setString(4,g_tenpo_cd);
			
			//ps.setString(5,g_time );
			 ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	
	private void BA01_deleteWR3_TERI_T(String g_fken_cd,String g_skgn_cd, String g_hs_cd, String g_tenpo_cd,String g_data_kbn) {
		// TODO Auto-generated method stub
		Connection c1=new BA01().getConnection();
			
		try {
			PreparedStatement ps=c1.prepareStatement("delete from wr3_teri_t where fken_cd=? and skgn_cd=? and hs_cd=? and tenpo_cd=? ");
			
            ps.setString(1,g_fken_cd );
			
			ps.setString(2,g_skgn_cd );
			
			ps.setString(3,g_hs_cd );
			
			ps.setString(4,g_tenpo_cd);
			
			//ps.setString(5,g_time );
			 ps.executeUpdate();
			
			//ps.setString(1,g_time);
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}
	
	public static void main(String args[]){
		BA01 obj=new BA01();
	//	obj.getConnection();
	//	obj.BA01_main();
	
		//String temp = null;
				
		Connection conn = null;
		System.out.println(conn);
		//System.out.println("sss");
		
		obj.BA01_main();
				
			}

	
}
