/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.sql.Connection;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class Update
/*    */   extends HttpServlet
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {}
/*    */   
/*    */   protected void doPost(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 43 */     Connection connection = null;
/* 44 */     PreparedStatement ps = null;
/* 45 */     String empId = request.getParameter("eid");
/* 46 */     String emname = request.getParameter("ename");
/* 47 */     String depid = request.getParameter("depid");
/*    */     
/* 49 */     PrintWriter out = response.getWriter();
/*    */     try
/*    */     {
/* 51 */       Class.forName("com.mysql.jdbc.Driver").newInstance();
/*    */     }
/*    */     catch (InstantiationException|IllegalAccessException|ClassNotFoundException e)
/*    */     {
/* 53 */       System.out.println(e);
/*    */     }
/*    */     try
/*    */     {
/* 57 */       connection = DriverManager.getConnection(
/* 58 */         "jdbc:mysql://localhost:3306/test", "root", "123");
/*    */     }
/*    */     catch (SQLException e)
/*    */     {
/* 61 */       e.printStackTrace();
/*    */     }
/*    */     try
/*    */     {
/* 64 */       ps = connection.prepareStatement("update  EmployeeTable set EmpName=?, DeptId=? where EmpId=?");
/*    */       
/* 66 */       ps.setString(1, emname);
/* 67 */       ps.setString(2, depid);
/* 68 */       ps.setString(3, empId);
/* 69 */       ps.executeUpdate();
/* 70 */       out.println("Updated");
/*    */       
/* 72 */       response.sendRedirect("index.jsp");
/*    */     }
/*    */     catch (SQLException e)
/*    */     {
/* 76 */       e.printStackTrace();
/*    */       try
/*    */       {
/* 80 */         connection.close();
/*    */       }
/*    */       catch (SQLException e)
/*    */       {
/* 83 */         e.printStackTrace();
/*    */       }
/*    */     }
/*    */     finally
/*    */     {
/*    */       try
/*    */       {
/* 80 */         connection.close();
/*    */       }
/*    */       catch (SQLException e)
/*    */       {
/* 83 */         e.printStackTrace();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:           D:\Public\Work_Software\Srimathi\WEB-INF\classes\
 * Qualified Name:     Update
 * JD-Core Version:    0.7.0.1
 */