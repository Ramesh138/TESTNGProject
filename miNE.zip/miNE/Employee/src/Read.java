/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.sql.Connection;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class Read
/*    */   extends HttpServlet
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {}
/*    */   
/*    */   protected void doPost(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 42 */     Connection connection = null;
/* 43 */     PreparedStatement ps = null;
/* 44 */     PrintWriter out = response.getWriter();
/*    */     try
/*    */     {
/* 46 */       Class.forName("com.mysql.jdbc.Driver").newInstance();
/*    */     }
/*    */     catch (InstantiationException|IllegalAccessException|ClassNotFoundException e)
/*    */     {
/* 48 */       System.out.println(e);
/*    */     }
/*    */     try
/*    */     {
/* 52 */       connection = DriverManager.getConnection(
/* 53 */         "jdbc:mysql://localhost:3306/test", "root", "123");
/*    */     }
/*    */     catch (SQLException e)
/*    */     {
/* 56 */       e.printStackTrace();
/*    */     }
/*    */     try
/*    */     {
/* 59 */       ps = connection.prepareStatement("select * from EmployeeTable");
/*    */       
/*    */ 
/* 62 */       ResultSet rs = ps.executeQuery();
/* 63 */       while (rs.next())
/*    */       {
/* 65 */         int eid = rs.getInt("EmpId");
/* 66 */         String ename = rs.getString("EmpName");
/* 67 */         int did = rs.getInt("DeptId");
/*    */         
/* 69 */         out.println("EmployeeID :" + eid + " " + "EmployeeName :" + ename + " " + "DepartmentId :" + did);
/*    */       }
/*    */     }
/*    */     catch (SQLException e)
/*    */     {
/* 75 */       e.printStackTrace();
/*    */       try
/*    */       {
/* 79 */         connection.close();
/*    */       }
/*    */       catch (SQLException e)
/*    */       {
/* 82 */         e.printStackTrace();
/*    */       }
/*    */     }
/*    */     finally
/*    */     {
/*    */       try
/*    */       {
/* 79 */         connection.close();
/*    */       }
/*    */       catch (SQLException e)
/*    */       {
/* 82 */         e.printStackTrace();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:           D:\Public\Work_Software\Srimathi\WEB-INF\classes\
 * Qualified Name:     Read
 * JD-Core Version:    0.7.0.1
 */