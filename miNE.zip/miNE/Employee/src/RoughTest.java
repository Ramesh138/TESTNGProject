import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class RoughTest {

	public Connection getConnection()
	{
		Connection conn = null;
		Statement stmt = null;
			
			try {
				Class.forName("org.postgresql.Driver");
			
				conn = (Connection) DriverManager
				        .getConnection("jdbc:postgresql://localhost:5432/Compass",
				        "postgres", "postgres");
			} catch (SQLException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("hi");
			}
			return conn;
			
	
	}
	
}
