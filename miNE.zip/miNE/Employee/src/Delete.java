import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Delete
  extends HttpServlet
{
  private static final long serialVersionUID = 1L;
  
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {}
  
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    PreparedStatement ps = null;
    String empId = request.getParameter("eid");
    Connection connection = null;
    
    PrintWriter out = response.getWriter();
    try
    {
      Class.forName("com.mysql.jdbc.Driver").newInstance();
    }
    catch (InstantiationException|IllegalAccessException|ClassNotFoundException e)
    {
      System.out.println(e);
    }
    try
    {
      connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "123");
    }
    catch (SQLException e)
    {
      e.printStackTrace();
    }
    try
    {
      ps = connection.prepareStatement("delete  from EmployeeTable where EmpId=?");
      
      ps.setString(1, empId);
      ps.executeUpdate();
      out.println("Deleted");
      
      response.sendRedirect("index.jsp");
    }
    catch (SQLException e)
    {
      e.printStackTrace();
      try
      {
        connection.close();
      }
      catch (SQLException e)
      {
        e.printStackTrace();
      }
    }
    finally
    {
      try
      {
        connection.close();
      }
      catch (SQLException e)
      {
        e.printStackTrace();
      }
    }
  }
}
