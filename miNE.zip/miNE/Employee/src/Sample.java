import java.io.File;
import java.sql.Date;
import java.text.SimpleDateFormat;


public class Sample extends Infile {
	private static final String NULL = null;
	//String Str="Sample";
	
	private static int DEBUG=0;
	private static String APP_ID 	=		"BA01"  ;
	private static int 	OK		=             0 ;
	private static int NG		 =           -1 ;
	private static int RET_DB_NORMAL	=             0  ;
	private static int MAX_RCD_INPUT    =       1000;
	private static String DBNAME 	=             "compass";
	private static String 	USERID 	 =            "dbcmps1" ;
	private static String PASSWD 	 =            "dbcmps1" ;  
	private static String APP_START 	 =            "00001" ; 
	private static String APP_END		 =             "00002"  ;
	private static String ERR_DB		 =            "00003"  ;
	private static String ERR_OTHER		 =            "00004"  ;
	private static String INF_DB		 =          "99998";
	static int  g_cnt;  
	static String filename;
	static String str_shell = "512";
	
	
//	public void write()
//	{
//		//System.out.println(Str);
//	}
	public static int BA01_main(String filenname)
	{
		int ng_flg = 0;
		
		
		Infile 		 inf[MAX_RCD_INPUT];  
		size_t 		 size;		      

		Object 		 fp; 
		String str_shell="512";
				            
	//	time_t		 times;
	//	struct tm	 *ltime;

		int res  = OK;   		     
		 int i = 0;
String str_err_rec="12";
		

if (DEBUG==1){
	
	int read_count = 0;
	}

if( ( fp = fopen(filename,"rb") ) == NULL )
{
	return( OK );	
}

str_shell= "$compassLogPgm" + " " + APP_ID + " " + ERR_DB + " ";
System.out.println(str_shell);

//return( NG );

Date ltime = new Date(i );
SimpleDateFormat tm = new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");
System.out.println("gtime: " + tm.format(ltime));

while((size = fread(inf, sizeof(Infile), MAX_RCD_INPUT, fp )) > 0 )
{
	for( i=0; i<size;  i++ )
	{
//	       sprintf(g_fken_cd, "%2.2s\0", inf[i].fken_cd);   
//	       sprintf(g_skgn_cd, "%3.3s\0", inf[i].skgn_cd);   
//	       sprintf(g_hs_cd, "%4.4s\0",   inf[i].hs_cd);     
//	       sprintf(g_tenpo_cd, "%3.3s\0",inf[i].tenpo_cd); 
	       
	       
	        String line;
			String fken_cd = line.substring(0,2);	
			String skgn_cd = line.substring(2, 5);
		    String hs_cd = line.substring(6, 10);
			String tenpo_cd = line.substring(11, 14);
			String data_kbn=line.substring(15, 16);
			String kaigyou = line.substring(17,18);
	       
	    	
		if( inf[i].data_kbn[0] == 'I' )
		{
			res = BA01_insertWR3_TERI_T();             
		}
		else
		if( inf[i].data_kbn[0] == 'U' )
		{
			res = BA01_updateWR3_TERI_T();             
		}
		else
		if( inf[i].data_kbn[0] == 'D' )
		{
			res = BA01_deleteWR3_TERI_T();             
		}
		else
		{
			memset( str_shell, 0, sizeof(str_shell) );
		       
			sprintf( str_shell, "$compassLogPgm %s %s \"%s 入力ファイル サイズ不正\"", APP_ID, ERR_OTHER, filename );
			system( str_shell );
			
		}
		
		if( res == NG )
		{
			ng_flg	 = 1;
			
			sprintf ( str_err_rec,"echo %s%s%s%s%c >>$errorRecFile",g_fken_cd,g_skgn_cd,g_hs_cd,g_tenpo_cd,inf[i].data_kbn[0]);
			system (str_err_rec);
		}
	}
	
	}

		return DEBUG;
		
		}
		
	private static Object fopen(String filename2, String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public static int BA01_insertWR3_TERI_T()
	{
			
		return DEBUG;
		
	}
	public void BA01_updateWR3_TERI_T()
	{
		
	}
	public void BA01_deleteWR3_TERI_T()
	{
		
	}
public static int main(String[] args) {
	
	int logpath_date;	   
	int res  = OK;     
	 str_shell = "$compassLogPgm" + " " + APP_ID + " " + APP_START + " ";
	 System.out.println( str_shell); 
	 
	res = BA01_main(APP_END);
	
	str_shell= "$compassLogPgm" +  " " +  APP_ID +" " +  APP_END +" "+ g_cnt+" " ;
	System.out.println(str_shell); 
     	 
	Sample sample = new Sample();
	//sample.write();
	sample.BA01_main(APP_END);
	sample.BA01_insertWR3_TERI_T();
	sample.BA01_updateWR3_TERI_T();
	sample.BA01_deleteWR3_TERI_T();
	return res; 
	
}
}
