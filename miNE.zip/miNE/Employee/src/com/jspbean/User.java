package com.jspbean;

public class User
{
	/*String name;
	String pswd;
	String email;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPswd() {
		return pswd;
	}
	public void setPswd(String pswd) {
		this.pswd = pswd;
	}
	public String getEmal() {
		return email;
	}
	public void setEmal(String email) {
		this.email = email;
	}*/
	
	
	
	

	private String name;

	private int age;

	public void setName(String n)

	{

	name=n;

	}

	public void setAge(int a)

	{

	age=a;

	}

	public int getAge()

	{

	return age;

	}

	public String getName()

	{

	return name;

	}

	
	
	
}
