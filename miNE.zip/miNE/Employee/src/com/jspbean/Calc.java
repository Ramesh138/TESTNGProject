package com.jspbean;

public class Calc {
	
	public int cube(int n){
		return n*n*n;
	}

}
