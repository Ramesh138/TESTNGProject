
public class Infile {

	private String fken_cd="2";
	private String skgn_cd="3";
	private String hs_cd="4";
	private String tenpo_cd="3";
	protected String data_kbn="1";
	private String kaigyou="1";
	public String getFken_cd() {
		return fken_cd;
	}
	public void setFken_cd(String fken_cd) {
		this.fken_cd = fken_cd;
	}
	public String getSkgn_cd() {
		return skgn_cd;
	}
	public void setSkgn_cd(String skgn_cd) {
		this.skgn_cd = skgn_cd;
	}
	public String getHs_cd() {
		return hs_cd;
	}
	public void setHs_cd(String hs_cd) {
		this.hs_cd = hs_cd;
	}
	public String getTenpo_cd() {
		return tenpo_cd;
	}
	public void setTenpo_cd(String tenpo_cd) {
		this.tenpo_cd = tenpo_cd;
	}
	public String getData_kbn() {
		return data_kbn;
	}
	public void setData_kbn(String data_kbn) {
		this.data_kbn = data_kbn;
	}
	public String getKaigyou() {
		return kaigyou;
	}
	public void setKaigyou(String kaigyou) {
		this.kaigyou = kaigyou;
	}
	
		
	}
