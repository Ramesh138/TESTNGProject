/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.sql.Connection;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class Insert
/*    */   extends HttpServlet
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {}
/*    */   
/*    */   protected void doPost(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 42 */     String empname = request.getParameter("ename");
/*    */     
/* 44 */     String dpId = request.getParameter("did");
/* 45 */     Connection connection = null;
/* 46 */     PreparedStatement ps = null;
/* 47 */     PrintWriter out = response.getWriter();
/*    */     try
/*    */     {
/* 50 */       Class.forName("com.mysql.jdbc.Driver").newInstance();
/*    */     }
/*    */     catch (InstantiationException|IllegalAccessException|ClassNotFoundException e)
/*    */     {
/* 52 */       System.out.println(e);
/*    */     }
/*    */     try
/*    */     {
/* 56 */       connection = DriverManager.getConnection(
/* 57 */         "jdbc:mysql://localhost:3306/test", "root", "123");
/*    */     }
/*    */     catch (SQLException e)
/*    */     {
/* 60 */       e.printStackTrace();
/*    */     }
/*    */     try
/*    */     {
/* 63 */       ps = connection.prepareStatement("insert into EmployeeTable(EmpName,DeptId) VALUES (?,?)");
/*    */       
/* 65 */       ps.setString(1, empname);
/* 66 */       ps.setString(2, dpId);
/*    */       
/* 68 */       ps.executeUpdate();
/* 69 */       out.println("Inserted");
/*    */     }
/*    */     catch (SQLException e)
/*    */     {
/* 74 */       e.printStackTrace();
/*    */       try
/*    */       {
/* 78 */         connection.close();
/*    */       }
/*    */       catch (SQLException e)
/*    */       {
/* 81 */         e.printStackTrace();
/*    */       }
/*    */     }
/*    */     finally
/*    */     {
/*    */       try
/*    */       {
/* 78 */         connection.close();
/*    */       }
/*    */       catch (SQLException e)
/*    */       {
/* 81 */         e.printStackTrace();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:           D:\Public\Work_Software\Srimathi\WEB-INF\classes\
 * Qualified Name:     Insert
 * JD-Core Version:    0.7.0.1
 */