package File.all;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class FileCrudForSqc {

	/**
	 * @param args
	 */
	
	public Connection getConnection(){
		
		Connection connec = null;
		Statement stmt = null;
			
			try {
				Class.forName("org.postgresql.Driver");
			
				connec = (Connection) DriverManager
				        .getConnection("jdbc:postgresql://localhost:5432/Compass",
				        "postgres", "postgres");
				
			//	System.out.println("hi");
							
			} catch (SQLException | ClassNotFoundException e) {
			
				e.printStackTrace();
				
			//	System.out.println("hi");
			}
			return connec;
		
		
		//return null;
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
	}

}
