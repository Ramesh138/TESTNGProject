package File.all;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BA02 {

	/**
	 * @param args
	 */
		
	public Connection getConnection()
	{
	
	//	Statement stmt = null;
		PreparedStatement ps=null;
		Connection conn = null;
			
			try {
				Class.forName("org.postgresql.Driver");
			
				conn = (Connection) DriverManager.getConnection("jdbc:postgresql://localhost:5432/Compass","postgres", "postgres");
				
			//	System.out.println("getting connection");
				System.out.println(conn);
			} catch (SQLException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return conn;
	}
	
	public void BA02_main(){
		
		FileReader reader = null;
		try {
			reader = new FileReader("D:\\Public\\CompanyTask\\BA02ReadFile.txt");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		BufferedReader brf = new BufferedReader(reader);
		String temp="";
		Connection c=new BA02().getConnection();
		try {
			
			while ((temp = brf.readLine())!= null) {
				
				String[] fileDatas =temp.split(" "); 
				for (int i = 0; i <fileDatas.length; i++) {
					String line = fileDatas[i];
					
					String g_zip_u3=line.substring(1, 4);
					
					String g_zip_l4=line.substring(5, 9);
					
					String g_fken_cd=line.substring(10, 12);
				  
					String g_skgn_cd=line.substring(13, 16);
					
					String  g_skgn_nm = line.substring(17, 37);
																
					System.out.println("for Loop");
				//	System.out.println("File Dates--->"+fileDatas);
				if(temp.startsWith("I"))
				{
					BA02_insertWR3_TERI_T(g_zip_u3,g_zip_l4,g_fken_cd,g_skgn_cd,g_skgn_nm);
				}
				else if(temp.startsWith("U"))
				{
					BA02_updateWR3_TERI_T(g_zip_u3,g_zip_l4,g_fken_cd,g_skgn_cd,g_skgn_nm);
				}
				else if(temp.startsWith("D"))
				{
					BA02_deleteWR3_TERI_T(g_zip_u3,g_zip_l4, g_fken_cd,g_skgn_cd,g_skgn_nm);
				}
							
			}
				
			}
			c.commit();
		} catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				c.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}	
					
	}
	
	private void BA02_insertWR3_TERI_T(String g_zip_u3, String g_zip_l4, String g_fken_cd, String g_skgn_cd, String g_skgn_nm) {
		// TODO Auto-generated method stub
		Connection c=new BA02().getConnection();
		try{
			
			PreparedStatement ps=c.prepareStatement("INSERT INTO wr3_skgn_t (zip_u3,zip_l4,fken_cd,skgn_cd,skgn_nm,pub_flg,ins_dt)VALUES(?,?,?,?,?,'0',current_timestamp)");
			ps.setString(1,g_zip_u3);
			ps.setString(2,g_zip_l4);
			ps.setString(3,g_fken_cd);
			ps.setString(4,g_skgn_cd);
			ps.setString(5,g_skgn_nm);
			ps.executeUpdate();
			c.commit();
			
		}
		catch(Exception e){
			e.printStackTrace();
			try {
				c.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
					
		}
				
	}
	
	private void BA02_updateWR3_TERI_T(String g_zip_u3, String g_zip_l4, String g_fken_cd, String g_skgn_cd, String g_skgn_nm) {
		// TODO Auto-generated method stub
		Connection c=new BA02().getConnection();
		try {
			PreparedStatement ps=c.prepareStatement("update wr3_skgn_t set ins_dt=current_timestamp,pub_flg='1' where fken_cd=? and skgn_cd=?");
			ps.setString(1,g_fken_cd );
			ps.setString(2,g_skgn_cd );
			System.out.println(ps);
			ps.executeUpdate();
			
			
			System.out.println("updated");
			c.commit();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				c.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
		
	}
	
	private void BA02_deleteWR3_TERI_T(String g_zip_u3, String g_zip_l4, String g_fken_cd, String g_skgn_cd, String g_skgn_nm) {
		// TODO Auto-generated method stub
		Connection c=new BA02().getConnection();
		
		try {
			PreparedStatement ps=c.prepareStatement("delete from wr3_skgn_t  where fken_cd=? and skgn_cd=?");
			
            ps.setString(1,g_fken_cd );
			
			ps.setString(2,g_skgn_cd );
			
			ps.executeUpdate();
			c.commit();
			
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			try {
				c.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
					
		}
			
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BA02 obj=new BA02();
		Connection conn = null;
		System.out.println(conn);
		obj.BA02_main();
		
		}

}
