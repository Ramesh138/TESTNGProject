package File.all;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BWR3F410_02 {

	/**
	 * @param args
	 */
	
	
	String g_hs_cd="";				
	String g_shash_cd="";			
	String g_syd_no="";			
	String g_syd_no2="";			
	String g_first_ins_dt=""; 		
	String g_first_chk_stat="";		
	String g_shash_ktsk=""; 		
	String g_shash_kihon="";		
	String g_shash_kbn="";			
	String g_tosyoku_cd=""; 		
	String g_usr_full_nm="";		
	String g_aims_first_ins_dt=""; 
	String g_sisaku_hs_cd="";		
	String g_kei_kb=""; 			
	int chk_stat;
	
	public Connection getConnection()
	{
	
	//	Statement stmt = null;
		PreparedStatement ps=null;
		Connection conn = null;
			
			try {
				Class.forName("org.postgresql.Driver");
			
				conn = (Connection) DriverManager.getConnection("jdbc:postgresql://localhost:5432/Compass","postgres", "postgres");
				
			//	System.out.println("getting connection");
				System.out.println(conn);
			} catch (SQLException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return conn;
	}
		
	int WR3F410_02_main() {
		FileReader reader = null;
		try {
			reader = new FileReader("D:\\Public\\CompanyTask\\Host.txt");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return 0;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	
		
		
	}

}
