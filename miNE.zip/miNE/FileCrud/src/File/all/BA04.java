package File.all;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BA04 {

	private static final int RET_DB_NOTFOUND = 0;
	private static final int NG = -1;
	private static final int RET_DB_NORMAL = 0;
	private static final Object OK = 0;
	private String g_fken_cd;
	private String g_skgn_cd;
	private String g_town_cd;
	private String g_koaza_cd;
	private String g_town_nm;
	private String g_zip_cd;
	private String g_time;
	private String g_first_time;
	private String g_flag;
	private int Flag;
	
	ResultSet rs = null;
		
	/**
	 * @param args
	 */
	public Connection getConnection()
	{
	
	//	Statement stmt = null;
		PreparedStatement ps=null;
		Connection conn = null;
			
			try {
				Class.forName("org.postgresql.Driver");
			
				conn = (Connection) DriverManager.getConnection("jdbc:postgresql://localhost:5432/Compass","postgres", "postgres");
				
			//	System.out.println("getting connection");
				System.out.println(conn);
			} catch (SQLException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return conn;
	}
	
	public int BA04_main(){
				
		System.out.println("BA Method--");
		FileReader reader = null;
		try {
			reader = new FileReader("D:\\Public\\CompanyTask\\BA04ReadFile.txt");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader brf = new BufferedReader(reader);
		String temp="";
		Connection c=new BA04().getConnection();
		try {
			
			while ((temp = brf.readLine())!= null) {
				
				String[] fileDatas =temp.split(" "); 
				for (int i = 0; i <fileDatas.length; i++) {
				
                    String line = fileDatas[i];
					
					g_fken_cd = line.substring(1, 3);
					
					g_skgn_cd = line.substring(4, 7);
					
					g_town_cd = line.substring(8, 12);
				  
					g_koaza_cd = line.substring(13, 16);
					
					g_town_nm = line.substring(17, 19);
					
				    g_zip_cd = line.substring(20, 22);
				  
				    g_first_time = line.substring(23, 33);
				  
				   	
				if(g_zip_cd!= null || g_zip_cd !=" ")
				//if( strcmp(g_zip_cd,"       ") != 0 )
				{
					
					if( BA04_selectWR3_TOWN_T()==1)
					{
						if(Flag==1){
							 BA04_insertWR3_TOWN_T();
							
						}
										
					}
								
			}
				else {
					BA04_deleteWR3_TOWN_T();
					BA04_insertWR3_TOWN_T();
					
				}
			}
			}
			}
			
			catch(Exception e){
				e.printStackTrace();
				
				try {
					c.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
						
		return 0;
		
	}
//	private int strcmp(String g_zip_cd, String string) {
//		// TODO Auto-generated method stub
//		return 0;
//	}

	int BA04_deleteWR3_TOWN_T(){
		
Connection c=new BA02().getConnection();
		
		try {
			PreparedStatement ps=c.prepareStatement("delete from wr3_town_t  where  fken_cd = ?AND skgn_cd = ? AND	town_cd = ?AND	koaza_cd = ? AND zip_cd = ?  ");
			
            ps.setString(1,g_fken_cd );
			
			ps.setString(2,g_skgn_cd );
			
			ps.setString(3,g_town_cd );
			
			ps.setString(4,g_koaza_cd );
			
			ps.setString(5,g_zip_cd );
			
			
			ps.executeUpdate();
			c.commit();
			
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			try {
				c.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
		}
		
		return 0;	
	}
	int BA04_selectWR3_TOWN_T(){
		
		
		Connection c=new BA02().getConnection();

		
		try {
			PreparedStatement ps=c.prepareStatement("select fken_cd, skgn_cd, pub_flg from wr3_town_t  where  fken_cd = ? AND skgn_cd = ? AND town_cd =? AND koaza_cd = ? AND zip_cd = ? AND ins_dt ::date <= '2015-04-06'");
			ps.setString(1,g_fken_cd );
			 
			ps.setString(2,g_skgn_cd );
			
			ps.setString(3,g_town_cd );
			
			ps.setString(4,g_koaza_cd );
			
			ps.setString(5,g_zip_cd );
			
			//ps.setString(6,g_first_time);
			
			System.out.println(ps);
			
			rs = ps.executeQuery();
			
			if(rs.next()){
				
				System.out.println(rs.getString("fken_cd"));
				System.out.println(rs.getString("skgn_cd"));
				System.out.println(rs.getString("pub_flg"));
				Flag = 0;
			}
			else
			{
				Flag = 1;
			}
			
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				c.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
					
		}
				
		return Flag;
	}
	int BA04_insertWR3_TOWN_T(){
		
		if( BA04_check_town_nm() == OK )
		{
			String g_flag = "0";
			//g_flag[1] = '\0';
		}
		else
		{
			String g_flag = "1";
		//	g_flag[1] = '\0';
		}
		
		Connection c=new BA02().getConnection();
        	
		try {
			PreparedStatement ps=c.prepareStatement ("INSERT INTO wr3_town_t (fken_cd,skgn_cd,town_cd,koaza_cd,town_nm,zip_cd,ins_dt,pub_flg ) VALUES  (?,?,?,?,?,?,current_timestamp,?)");
		
			    ps.setString(1,g_fken_cd );
				
				ps.setString(2,g_skgn_cd );
				
				ps.setString(3,g_town_cd );
				
				ps.setString(4,g_koaza_cd );
				
				ps.setString(5,g_town_nm );
				
				ps.setString(6,g_zip_cd );
											
				ps.setString(7,g_flag);
				System.out.println(ps);
				int NG = ps.executeUpdate();
				if(NG>0){
					Flag=1;
				}else{
					Flag=0;
				}
			
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			try {
				c.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
		}
						
		return Flag;
	}
	
	
	private Object BA04_check_town_nm() {
		
		if (g_town_nm.contains("-")) 
		{ 
			return( NG ); 
		} 
		if (g_town_nm.contains("�")) 
		{ 
			
		if (g_town_nm.contains("0")) 
		{ 
			return( NG ); 
		} 
		if (g_town_nm.contains("1")) 
		{ 
			return( NG ); 
		} 
		if (g_town_nm.contains("2")) 
		{ 
			return( NG ); 
		} 
		if (g_town_nm.contains("3")) 
		{ 
			return( NG ); 
		} 
		
		if (g_town_nm.contains("4")) 
		{ 
			return( NG ); 
		} 
		if (g_town_nm.contains("5")) 
		{ 
			return( NG ); 
		} 
		if (g_town_nm.contains("6")) 
		{ 
			return( NG ); 
		} 
		if (g_town_nm.contains("7")) 
		{ 
			return( NG ); 
		} 
		if (g_town_nm.contains("8")) 
		{ 
			return( NG ); 
		} 
		if (g_town_nm.contains("9")) 
		{ 
			return( NG ); 
		} 
		
		return( NG ); 
		} 
		
		// TODO Auto-generated method stub
		return OK;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BA04 obj=new BA04();
		Connection conn = null;
		System.out.println(conn);
		obj.BA04_main();
		
	}

}
