import { browser, Config } from "protractor";
const jsonReports = process.cwd() + "/report/json";
import { Reporter } from "../smartest/cucumber_support/reporter";
import { setUp, executableFeatures } from '../smartest/smartutils/TestRunner';
var path = require('path');
var downloadsPath = path.resolve(__dirname, '../../downloads');
const { Authenticator } = require('authenticator-browser-extension');


export const config: Config = {

    setup: setUp(),

    directConnect: true,

    SELENIUM_PROMISE_MANAGER: false,

    capabilities: {

        browserName: "chrome",
        unexpectedAlertBehaviour: 'accept',
        javascriptEnabled: true,
        acceptInsecureCerts: true,

        // Uncomment the code below when commiting to pipeline

        /* acceptSslCerts: true,
        chromeOptions: {
            args: ["--headless", "--disable-gpu", "--disable-infobars", "--no-sandbox", "--window-size=1500x750", "--ignore-certificate-errors"],
            prefs: {
                download: {
                    'prompt_for_download': false,
                    'default_directory': downloadsPath
                }
            }
        }, */

        // Uncomment the code below while running in local machine
        chromeOptions: {
            extensions: [
                Authenticator.for('z020650', 'Veen1434').asBase64()
            ],
            args: ["--disable-gpu"],
            prefs: {
                download: {
                    'prompt_for_download': false,
                    'default_directory': downloadsPath
                }
            }
        }
    },

    framework: "custom",
    frameworkPath: require.resolve("protractor-cucumber-framework"),

    specs: executableFeatures(),

    onPrepare: () => {
        browser.ignoreSynchronization = true;
        browser.manage().window().maximize();
        Reporter.createDirectory(jsonReports);
    },

    cucumberOpts: {
        compiler: "ts:ts-node/register",
        format: "json:./report/json/cucumber_report.json; xml:./report/json/cucumber_report.xml",
        tags: "@Re7",
        require: ["../../bin/stepdefinitions/*.js", "../../bin/smartest/cucumber_support/*.js"],
        strict: true
    },

    onComplete: () => {
        Reporter.createHTMLReport();
    },
};
