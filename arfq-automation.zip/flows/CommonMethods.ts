import { browser, by } from "protractor";
export class CommonMethods {
    
    //if new elements are getting loaded if scrolling the list
    public static async selectMatchingTextFromInfiniteScroll(maxScroll: number, elementsXpath: string, textToClick: string) {
        let lastValue;
        loop: for (let index = 0; index < maxScroll; index++) {
            const options = await browser.driver.findElements(by.xpath(elementsXpath))
            let temp;
            for (const option of options) {
                temp = await option.getText();
                if (temp === textToClick) {
                    await option.click()
                    break loop;
                }
            }
            if (lastValue === temp) {
                throw new Error("No value found in the name '" + textToClick + "'")
            } else {
                lastValue = temp;
                await browser.executeScript("arguments[0].scrollIntoView();", options[options.length - 1]);
            }
            await browser.sleep(1000)
        }
    }


    //scroll to specified range(x-axis, y-axis)
    public static async scrollTo(x: number, y: number) {
        return await browser.executeScript("window.scrollTo(" + x + "," + y + ");")
    }

    //Random number between specified range
    public static randomNumber(min: number, max: number) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    public static  runExeFile = (filePath: string) => {
        var child_process = require('child_process');
        child_process.exec(filePath)
    }

    //Random string specified length
    public static randomString(length: number) {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    }

    //If delete list one by one (Delete icons/buttons xpath should be given as argument)
    public static async removeListOneByOne(elementsXpath: string) {
        let dbCount = await (await browser.driver.findElements(by.xpath(elementsXpath))).length
        for (let index = 0; index < dbCount; index++) {
            let elms = await browser.driver.findElements(by.xpath(elementsXpath))
            elms[0].click()
            await browser.sleep(1000)
        }
    }


   
}