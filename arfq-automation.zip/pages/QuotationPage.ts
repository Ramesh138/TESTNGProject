import { button, checkbox, textbox } from '../smartest/custom_elements/SmartLocators'
import { SupplierConstants } from './SupplierConstants';

export class QuotationPage extends SupplierConstants {


    public static getToolingInvestmentNeededTgl() {
        return button.byXpath("//label[@for='notneeded-section-toolinginvestments']")
    }


    // default row 1
    public static getCheckBoxPriceTableRow() {
        return checkbox.byXpath(this.getAppSectionXpath("Prices") + "//div[@class='table ng-star-inserted']/div[@class='row ng-star-inserted']//input[@type='checkbox']");
    }

    public static getTechnicalFromPriceTableRow() {
        return textbox.byXpath(this.getAppSectionXpath("Prices") + "//div[@class='table ng-star-inserted']/div[@class='row ng-star-inserted']//input[starts-with(@name,'technical')]");
    }

    public static getPackagingFromPriceTableRow() {
        return textbox.byXpath(this.getAppSectionXpath("Prices") + "//div[@class='table ng-star-inserted']/div[@class='row ng-star-inserted']//input[starts-with(@name,'packaging')]");
    }

    public static getTransportFromPriceTableRow() {
        return textbox.byXpath(this.getAppSectionXpath("Prices") + "//div[@class='table ng-star-inserted']/div[@class='row ng-star-inserted']//input[starts-with(@name,'transport')]");
    }


}