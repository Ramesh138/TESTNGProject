import { element, by } from 'protractor';
import { textbox, textarea, button, selectbox, label, checkbox, link } from '../smartest/custom_elements/SmartLocators'

export class RFQPage {

    public static createRFQbtn = button.byXpath("//button[contains(text(),'Create')]");

    public static mainInformation = label.byId("General");

    public static getExistingRFQID(RFQID: string) {
        return button.byXpath("//div[@class='table-responsive custom-table-div']//*[contains(text(),'" + RFQID + "')]")
    }

    public static getTextBoxOf(textBoxName: string) {
        return textbox.byXpath("//*[contains(text(),'" + textBoxName + "')]/following::input")
    }


    static documentDilog = class {
        public static documentDialog: string = "//div[@role='document']"

        public static getDropDownOf(dropDownName: string) {
            return selectbox.byXpath(this.documentDialog + "//*[contains(text(),'" + dropDownName + "')]/following::select")
        }

        public static getTextBoxOf(textBoxName: string) {
            return textbox.byXpath(this.documentDialog + "//*[contains(text(),'" + textBoxName + "')]/following::input")
        }

        public static getElementOf(textBoxName: string) {
            return textarea.byXpath(this.documentDialog + "//*[contains(text(),'" + textBoxName + "')]/following::textarea")
        }

        public static getBrandType(brand: string) {
            return link.byXpath(this.documentDialog + "//img[contains(@alt,'" + brand + "')]")
        }

        public static searchContentToolTipInput(toolTipValue: string) {
            return checkbox.byXpath(this.documentDialog + "//div[@ng-reflect-ngb-tooltip='" + toolTipValue + "']/parent::div//input")
        }

        public static firstRowSearchContent() {
            return checkbox.byXpath(this.documentDialog + "//div[contains(@class,'table-responsive custom-table-div')]//div[contains(@class,'row section')]//input[@type='checkbox']")
        }

        public static searchContentTableInput() {
            return checkbox.byXpath(this.documentDialog + "//div[@class='scroll-sec']//input")
        }

        public static getButton(buttonName: string) {
            return button.byXpath(this.documentDialog + "//button[contains(text(),'" + buttonName + "')]");
        }

        public static getActorInput() {
            return textbox.byXpath(this.documentDialog + "//input")
        }

        public static getActorDetailCard(actorName: string) {
            return button.byXpath(this.documentDialog + "//div[@class='actor-detail']/p[contains(text(),'" + actorName + "')]")
        }

        public static getAddSupplierGroupTextBox() {
            return textbox.byXpath(this.documentDialog + "//input[@type='text']")
        }

        public static getAddSupplierGroupName(groupName: string) {
            return checkbox.byXpath(this.documentDialog + "//div[contains(text(),'" + groupName + "')]/parent::div//input[@type='checkbox']")
        }

    }

    public static getSection(section: string) {
        return label.byXpath("//accord[@ng-reflect--title='" + section + "']")
    }


    public static getUploadFromSectionFor(section: string, projectType: string) {
        var colNumber = 3;
        if (projectType.includes("Nissan")) {
            colNumber = 4;
        }else if(projectType.includes("Mitsubishi")){
            colNumber = 5;
        }
        return button.byXpath(this.getSectionXpath(section) + "//table/tbody//tr/td["+colNumber+"]/span")
    }

    public static getButtonFromSection(section: string, buttonName: string) {
        return button.byXpath(this.getSectionXpath(section) + "//button[text()='" + buttonName + "']")
    }

    public static getButtonFromSubSection(section: string, subSection, buttonName: string) {
        return button.byXpath(this.getSectionXpath(section) + "//*[contains(text(),'" + subSection + "')]/following::div" + "//button[text()='" + buttonName + "']")
    }
    public static getSectionXpath(section: string) {
        return "//accord[@ng-reflect--title='" + section + "']";
    }

    public static getTabFromSection(section: string, tabName: string) {
        return button.byXpath(this.getSectionXpath(section) + "//a[@role='tab' and text()='" + tabName + "']")
    }

    public static getNDAComplianceFromSubSection(section: string, subSection) {
        return checkbox.byXpath(this.getSectionXpath(section) + "//*[contains(text(),'" + subSection + "')]/following::div" + "//input[@type='checkbox']")
    }

    public static getSupplierToSendScenario() {
        return checkbox.byXpath(this.getSectionXpath("Send Scenario") + "//input[@type='checkbox']")
    }

    public static ScenarioContentComplianceStatus(content: string) {
        return label.byXpath("//span[@class='lensText' and text()='" + content + "']//preceding-sibling::span");
    }

}