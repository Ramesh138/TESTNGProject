import { button, link, label, textarea, checkbox } from '../smartest/custom_elements/SmartLocators'

export class SupplierConstants {

    public static supplierPageLoading = button.byXpath("//div[@class='loader isLoading']");

    public static saveScenario = button.byXpath("//header[@class='header']//button[text()='Save']")

    public static sendOffer = button.byXpath("//header[@class='header']//button[text()='Send Offer']")

    public static sendF1 = button.byXpath("//header[@class='header']//button[text()='Send F1']")

    public static navigateToBreadCrum(navigateTo: string) {
        return link.byXpath("//app-breadcrumb/ul/li[contains(text(),'scenario : ARFQ-KP-1201201025-Scenario 1')]")
    }


    public static navigateToBreadCrumScenario() {
        return link.byXpath("//app-breadcrumb/ul/li[contains(text(),'scenario :')]")
    }

    public static getNavigateLink(linkName: string) {
        linkName = linkName.toLowerCase()
        return link.byXpath("//a[contains(@class,'navigation__link') and text()[contains(translate(.,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'" + linkName + "')]]")
    }

    // Tooling Investments
    public static getAppSection(sectionName: string) {
        return label.byXpath("//app-section[@title='" + sectionName + "']")
    }

    public static getAppSectionXpath(sectionName: string) {
        return "//app-section[@title='" + sectionName + "']";
    }

    public static getButtonFromAppSection(sectionName: string, buttonName: string) {
        return button.byXpath("//app-section[@title='" + sectionName + "']//button[text()='" + buttonName + "']")
    }

    public static getCheckBoxFromAppSection(sectionName: string) {
        return checkbox.byXpath("//app-section[@title='" + sectionName + "']//input[@type='checkbox']")
    }

    public static getButtonFromSection(sectionName: string, buttonName: string) {
        return button.byXpath("//section[@id='" + sectionName + "']//button[text()='" + buttonName + "']")
    }

    public static getaddPlusBtnFromAppSection(sectionName: string, buttonName: string) {
        return button.byXpath("//app-section[@title='" + sectionName + "']//button[@class='add-triplet-btn']")
    }

    public static getTextAreaFromSection(section: string) {
        return textarea.byXpath(this.getAppSectionXpath(section) + "//textarea");
    }

}