import { button } from '../smartest/custom_elements/SmartLocators'

export class Constants {

    public static pageLoadingSpinner = button.byXpath("//div[@id='spinner']");


}