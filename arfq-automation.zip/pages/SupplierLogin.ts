import { button, textbox } from '../smartest/custom_elements/SmartLocators'

export class SupplierLogin {

    public static userMail = textbox.byXpath("//input[@type='email']");

    public static submit = button.byXpath("//input[@type='submit']");

}