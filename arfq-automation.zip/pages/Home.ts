import { button, grid } from '../smartest/custom_elements/SmartLocators'
import { Constants } from './Constants';

export class Home {


    public static navigateToTile(tileName) {
        return button.byXpath("//app-tile[@ng-reflect-name='" + tileName + "']")
    }


}