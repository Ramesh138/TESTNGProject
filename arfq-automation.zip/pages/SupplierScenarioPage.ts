import { browser } from 'protractor';
import { button, selectbox, radiobutton } from '../smartest/custom_elements/SmartLocators'
import { SupplierConstants } from './SupplierConstants';

export class SupplierScenarioPage extends SupplierConstants {


    // scenario text is ovelayed or intercepted by following sibling div doneMessage
    public static getAppScenario(scenarioID: string) {
        return button.byXpath("//div[@class='scenario']/div[contains(text(),'" + scenarioID + "')]/following-sibling::div[@class='doneMessage']")
    }

    public static getSectionLinks(section: string) {
        section = section.toLowerCase();
        return button.byXpath("//div[@class='menu-item ng-star-inserted']//div[@class='title' and text()='" + section + "']")
    }

    public static f1AttachFile = button.byXpath("//div[@class='send-f1-button ng-star-inserted']")

    public static cbmChoice = radiobutton.byId("cbmChoice");

    public static moneyChoice = radiobutton.byId("moneyChoice");

    public static currency = selectbox.byId("currency");

    public static addCurrency = button.byXpath("//div[@class='currencyToolbar']/button[text()='Add']");

    public static selectCurrencies(currencies: string) {
        var currArray = currencies.split(",");
        currArray.forEach(curr => {
            this.currency.selectByText(curr);
            browser.sleep(2000)
            this.addCurrency.click();
            this.supplierPageLoading.waitForInvisibility(5000)
        })

    }

}