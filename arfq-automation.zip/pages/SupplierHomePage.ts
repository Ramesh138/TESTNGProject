import { button, textbox } from '../smartest/custom_elements/SmartLocators'
import { SupplierConstants } from './SupplierConstants';

export class SupplierHomePage extends SupplierConstants{

    public static getRFQBook(RFQID: string) {
        return button.byXpath("//div[contains(text(),'" + RFQID + "')]/preceding-sibling::div")
    }
    static documentDilog = class {
        public static documentDialog: string = "//div[@role='document']"

        public static getButton(buttonName: string) {
            return button.byXpath(this.documentDialog + "//button[contains(text(),'" + buttonName + "')]");
        }
    }
}


