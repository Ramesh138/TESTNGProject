const { BeforeAll, After, Status } = require("cucumber");
import { browser } from "protractor";
import { config } from "../../config/conf";
import * as fs from 'fs'
var jsonfile = require('jsonfile')
import { Before, HookScenarioResult, AfterAll, GlobalHookCode } from "cucumber";
import { Constants, Dynamic } from "../constants/Constants";
import { Home } from "../../pages/Home";


BeforeAll({ timeout: 100 * 1000 }, async () => {
    await browser.manage().window().maximize();
    /* await browser.get("https://irs.re7.applis.renault.fr/");
    await Home.popup.waitForVisibility()
    await Home.popup.delayClick(5000) */
});

Before(async (scenario: HookScenarioResult) => {
    const paths = scenario.sourceLocation.uri.split('\\')
    let obj = JSON.parse(fs.readFileSync(Constants.dynamicData).toString())
    const fName = paths[paths.length - 1].split('\.')[0]
    obj[fName] = {}
    Dynamic.currentFeature = fName;
    jsonfile.writeFileSync(Constants.dynamicData, obj)
})


After(async function (scenario: HookScenarioResult) {
    if (scenario.result.status === Status.FAILED) {
        // screenShot is a base-64 encoded PNG
        const screenShot = await browser.takeScreenshot();
        this.attach(screenShot, "image/png");
    }
});

AfterAll({ timeout: 100 * 1000 }, async () => {  
    await browser.quit();
});
