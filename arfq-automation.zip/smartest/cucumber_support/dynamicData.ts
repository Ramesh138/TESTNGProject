import * as fs from "fs"
import { Constants, Dynamic } from "../constants/Constants"

export function getData(key) {
    const obj = JSON.parse(fs.readFileSync(Constants.dynamicData).toString())
    return obj[Dynamic.currentFeature][key];
}