import { ElementFinder, protractor, ElementArrayFinder, browser, ExpectedConditions, by } from "protractor";
import { __ } from 'lodash/fp'
import { Scripts } from "../constants/Scripts";
import { AssertionError } from "assert";

export class Actions {

    public static click(element: ElementFinder, log?: string) {
        return element.click().then(() => {

        })
    }

    public static delayClick(element: ElementFinder, millies: number, log?: string) {
        return browser.sleep(millies).then(() => {
            return element.click().then(() => {

            })
        })
    }

    public static enter(element: ElementFinder, log?: string) {
        return element.sendKeys(protractor.Key.ENTER).then(() => {

        })
    }

    public static space(element: ElementFinder, log?: string) {
        return element.sendKeys(protractor.Key.SPACE).then(() => {

        })
    }

    public static submit(element: ElementFinder, log?: string) {
        return element.submit().then(() => {

        })
    }

    public static jsClick(element: ElementFinder, log?: string) {
        return browser.executeScript(Scripts.jsClick(), element).then(() => {

        })
    }

    public static hover(element: ElementFinder, log?: string) {
        return browser.actions().mouseMove(element).perform().then(() => {

        })
    }

    public static actionClick(element: ElementFinder, log?: string) {
        return browser.actions().click(element).perform().then(() => {

        })
    }

    public static doubleClick(element: ElementFinder, log?: string) {
        return browser.actions().doubleClick(element).perform().then(() => {

        })
    }

    public static highlight(element: ElementFinder, log?: string) {
        browser.executeScript(Scripts.highlight(), element.getWebElement())
        return element
    }

    public static scrollToElement(element: ElementFinder) {
        return browser.executeScript(Scripts.scrollToElement(), element)
    }

    public static clickAndWaitForAlertPresence(element: ElementFinder, log?: string, millies?: number) {
        element.click().then(() => {
            browser.wait(ExpectedConditions.alertIsPresent(), millies).then(() => {

            })
        })
    }

    public static waitForVisibility(element: ElementFinder, millies: number = 30000) {
        return browser.wait(ExpectedConditions.visibilityOf(element), millies)
    }

    public static waitForPresence(element: ElementFinder, millies: number = 30000) {
        return browser.wait(ExpectedConditions.presenceOf(element), millies)
    }

    public static waitForInvisibility(element: ElementFinder, millies: number = 30000) {
        return browser.wait(ExpectedConditions.invisibilityOf(element), millies)
    }

    public static waitForStaleness(element: ElementFinder, millies: number = 30000) {
        return browser.wait(ExpectedConditions.stalenessOf(element), millies)
    }

    public static waitForClickable(element: ElementFinder, millies: number = 30000) {
        return browser.wait(ExpectedConditions.elementToBeClickable(element), millies)
    }

    public static waitForTextToPresentInElement(element: ElementFinder, text: string, millies: number = 30000) {
        return browser.wait(ExpectedConditions.textToBePresentInElement(element, text), millies)
    }

    public static waitForTextToPresentInElementValue(element: ElementFinder, text: string, millies: number = 30000) {
        return browser.wait(ExpectedConditions.textToBePresentInElementValue(element, text), millies)
    }

    public static waitForelementToBeSelected(element: ElementFinder, millies: number = 30000) {
        return browser.wait(ExpectedConditions.elementToBeSelected(element), millies)
    }

    public static waitForTitleIs(title: string, millies: number = 30000) {
        return browser.wait(ExpectedConditions.titleIs(title), millies)
    }

    public static verifyText(element: ElementFinder, text2Verify: string, log?: string) {
        return element.getText().then((text) => {
            if (text.trim() === text2Verify.trim()) {

            } else {
                throw new AssertionError({
                    message: 'Actual text is mismatching with expectation',
                    actual: text,
                    expected: text2Verify
                })
            }
        })
    }

    public static verifyTextContains(element: ElementFinder, text2Verify: string, log?: string) {
        return element.getText().then((text) => {
            if (text.trim().includes(text2Verify.trim())) {

            } else {
                throw new AssertionError({
                    message: text2Verify + ' is missing',
                    actual: text
                })
            }
        })
    }

    public static verifyAttribute(element: ElementFinder, attributeName: string, text2Verify: string, log?: string) {
        return element.getAttribute(attributeName).then((text) => {
            if (text.trim() === text2Verify.trim()) {

            } else {
                throw new AssertionError({
                    message: 'Actual text is mismatching with expectation',
                    actual: text,
                    expected: text2Verify
                })
            }
        })
    }

    public static verifyAttributeContains(element: ElementFinder, attributeName: string, text2Verify: string, log?: string) {
        return element.getAttribute(attributeName).then((text) => {
            if (text.trim().includes(text2Verify.trim())) {
                console.log(text2Verify + " is present")
            } else {
                throw new AssertionError({
                    message: text2Verify + ' is missing',
                    actual: text
                })
            }
        })
    }

    public static printText(element: ElementFinder, preFix: string) {
        return element.getText().then(text => {
            console.log(preFix + text)
        })
    }

    public static printAttibute(element: ElementFinder, attributeName: string, preFix: string) {
        return element.getAttribute(attributeName).then(text => {
            console.log(preFix + text)
        })
    }

    public static selectDropdownByIndex(element: ElementFinder, index: number, log?: string, millies?: number) {
        element.click().then(() => {
            element.all(by.tagName('option')).then(options => {
                options[index].click();
            });
        })
    }


    public static selectDropdownByValue(element: ElementFinder, value: string, log?: string, millies?: number) {
        element.click().then(() => {
            element.all(by.xpath('option')).then(options => {
                options.forEach(ele => {
                    ele.getAttribute('value').then(text => {
                        console.log(text)
                        if (text === value) {
                            ele.click();
                            return false;
                        }
                    })

                })
            });
        })
    }

    public static selectDropdownByText(element: ElementFinder, textToSelect: string, log?: string, millies?: number) {
        element.click().then(() => {
            element.all(by.xpath('option')).then(options => {
                options.forEach(ele => {
                    ele.getText().then(text => {
                        console.log(text)
                        if (text === textToSelect) {
                            ele.click();
                            return false;
                        }
                    })

                })
            });
        })
    }

}