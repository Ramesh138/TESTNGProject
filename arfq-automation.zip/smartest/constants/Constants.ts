export class Constants {

        static xmlOutputPath: string = systemPath() + '/XMLReports'
        static xmlSmarTestReport: string = Constants.xmlOutputPath + '/SmarTestXMLReport.xml'

        static cucumberJson: string = systemPath() + '/report/json/cucumber_report.json'
        static contentJson: string = systemPath() + '/report/json/content.json'

        static reportsFolder: string = systemPath() + '/Reports'
        static staticReportFolder: string = systemPath() + '/Reports/Static'
        static dynamicReportFolder: string = systemPath() + '/Reports/Dynamic'
        static inputType: string = ""
        
        static downloadsPath: string = systemPath() + '/downloads'
        static dynamicData: string = systemPath() + '/dynamic_data/data.json'
        
        static reportTemplateCss: string = systemPath() + '/ngsmartest/templates/Reports/css'
        static reportTemplateImages: string = systemPath() + '/ngsmartest/templates/Reports/Images'
        static reportTemplateJs: string = systemPath() + '/ngsmartest/templates/Reports/js'
        static reportTemplateStaticHtml: string = systemPath() + '/ngsmartest/templates/Reports/static.html'
        static reportTemplateDynamicHtml: string = systemPath() + '/ngsmartest/templates/Reports/dynamic.html'
        static reportTemplate: string = systemPath() + '/ngsmartest/templates/Reports'
        
        static staticJsFolder: string = systemPath() + '/Reports/Static/js'
        static staticScreenShotFolder: string = systemPath() + '/Reports/Static/Current/Screenshots'
        static staticImagesFolder: string = systemPath() + '/Reports/Static/Images'
        static staticCssFolder: string = systemPath() + '/Reports/Static/css'
        static staticHtml: string = 'static.html'
        
        static dynamicJsFolder: string = systemPath() + '/Reports/Dynamic/js'
        static dynamicImagesFolder: string = systemPath() + '/Reports/Dynamic/Images'
        static dynamicCssFolder: string = systemPath() + '/Reports/Dynamic/css'
        static dynamicHtml: string = systemPath() + '/Reports/Dynamic/dynamic.html'
        static dynamicScreenShotFolder: string = systemPath() + '/Reports/Dynamic/Current/Screenshots'

        static contentJsonFile: string = systemPath() + '/Reports/Dynamic/Current/content.json'
        static contentJsonFile1: string = systemPath() + '/Reports/Dynamic/Current/content1.json'
        static contentJsFile: string = 'content.js'
        static previousRunFolderPath: string = systemPath() + '/Reports/Dynamic/PreviousRun'
        static currentFolderPath: string = systemPath() + '/Reports/Dynamic/Current'
        static previousItrnPath: string = systemPath() + '/Reports/Dynamic/PreviousRun/Iteration-'
        static tempFolderPath: string = systemPath() + '/Reports/Dynamic/PreviousRun/Current'
        static screenShotPath: string = systemPath() + '/Reports/Dynamic/Current/Screenshots'

        static contentJsonTemplate: string = systemPath() + '/ngsmartest/templates/content.json'
        static stepJsonTemplate: string = systemPath() + '/ngsmartest/templates/step.json'
        static testCaseJsonTemplate: string = systemPath() + '/ngsmartest/templates/testcase.json'
        static moduleJsonTemplate: string = systemPath() + '/ngsmartest/templates/module.json'
        static tempJson: string = systemPath() + '/ngsmartest/templates/temp.json'
        
        static projectConfigJsonFile: string = systemPath() + '/config/config.json'
        static testSuiteJsonPath: string = systemPath() + '/input/json'
        static labelBasePath: string = systemPath() + '/Labels'
        static testSuiteExcelFile: string = systemPath() + '/input/Testsuite.xlsx'
        static testDataPath: string = systemPath() + '/data'
        static convertedTestDataJsonPath: string = systemPath() + '/data/json'
        
        static contentJsPrefix: string = 'var content = '
        static FORWARD_SLASH: string = '/'
        static BACKWARD_SLASH: string = '\\'
        static JSON: string = 'json'
        static DOT_JSON: string = '.json'
        static DOT_JS: string = '.js'
        static EXCEL: string = 'excel'
        static DOT_XLSX: string = '.xlsx'
        static DOT_JPG: string = '.jpg'
        static SPECNAME: string = 'SpecName'
        static TESTCASEID: string = 'TestCaseID'
        static WEB: string = 'Web'
        static YES: string = 'Yes'
        static MOBILE: string = 'Mobile'
        static HYBRID: string = 'Hybrid'
        static KEYWORD: string = 'Keyword'
        static SPECS: string = 'specs'
        static SCREENSHOTS:string = 'Screenshots'
        static SPACE_PASS:string = ' Pass'
        static SPACE_FAIL:string = ' Fail'
        static SPACE_NoRun:string = ' NoRun'
        static PASS:string = 'Pass'
        static STEP:string = 'step'
        static FAIL:string = 'Fail'
        static NO_EXCEPTION = "No Exception"
}

export class Dynamic {
        static projectConfig: any
        static testDataFileNameBy: string = ""
        static allModules:string[]
        static executableSpecFileList: Map<string, Array<any>> = new Map<string, Array<any>>()
        static moduleWiseExecutableTCList: Map<string, Array<string>> = new Map<string, Array<string>>()
        static executableModulesList: string[] = []
        static testCaseListByModule: string[] = []
        static currentTestDataJSONFilePath: string = ""
        //static currentExecutionLanguage: string = ""
        static labelJSONFilePath: string = ""
        static currentRunDetails: any = {
                testCaseID: "",
                moduleName: "",
        }

        static currentFeature = ''
}

export function systemPath(): string {
        return process.cwd().split("\\bin")[0].trim()
}