import { ElementFinder, ElementArrayFinder, element, by } from 'protractor'
import { Button, Textbox, Checkbox, RadioButton, Link, Grid, Label, Icon, Image, SelectBox, TextArea } from './SmartElements';

export class button {

    public static byText(btnText:string){
        return new Button(element(by.buttonText(btnText)))
    }

    public static byPartialText(partialBtnText:string){
        return new Button(element(by.partialButtonText(partialBtnText)))
    }

    public static byXpath(xpath: string) {
        return new Button(element(by.xpath(xpath)))
    }

    public static byCss(css: string) {
        return new Button(element(by.css(css)))
    }

    public static byId(id: string) {
        return new Button(element(by.id(id)))
    }

    public static byName(name: string) {
        return new Button(element(by.name(name)))
    }

    public static byClassName(className: string) {
        return new Button(element(by.className(className)))
    }

    public static byLinkText(linktext:string){
        return new Button(element(by.linkText(linktext)))
    }

    public static byPartialLinkText(partialLinktext:string){
        return new Button(element(by.partialLinkText(partialLinktext)))
    }

    public static byTagname(tagName: string) {
        return new Button(element(by.tagName(tagName)))
    }

    public static byModel(model: string) {
        return new Button(element(by.model(model)))
    }

    public static byBinding(binding: string) {
        return new Button(element(by.binding(binding)))
    }

    public static byCssContainingText(css: string, text:string) {
        return new Button(element(by.cssContainingText(css, text)))
    }

    public static byElement(element: ElementFinder) {
        return new Button(element)
    }

}

export class selectbox{
    public static byXpath(xpath: string) {
        return new SelectBox(element(by.xpath(xpath)))
    }

    public static byCss(css: string) {
        return new SelectBox(element(by.css(css)))
    }

    public static byId(id: string) {
        return new SelectBox(element(by.id(id)))
    }

    public static byName(name: string) {
        return new SelectBox(element(by.name(name)))
    }

    public static byClassName(className: string) {
        return new SelectBox(element(by.className(className)))
    }
}

export class label {

    public static byXpath(xpath: string) {
        return new Label(element(by.xpath(xpath)))
    }

    public static byCss(css: string) {
        return new Label(element(by.css(css)))
    }

    public static byId(id: string) {
        return new Label(element(by.id(id)))
    }

    public static byName(name: string) {
        return new Label(element(by.name(name)))
    }

    public static byClassName(className: string) {
        return new Label(element(by.className(className)))
    }

    public static byLinkText(linktext:string){
        return new Label(element(by.linkText(linktext)))
    }

    public static byPartialLinkText(partialLinktext:string){
        return new Label(element(by.partialLinkText(partialLinktext)))
    }

    public static byTagname(tagName: string) {
        return new Label(element(by.tagName(tagName)))
    }

    public static byModel(model: string) {
        return new Label(element(by.model(model)))
    }

    public static byBinding(binding: string) {
        return new Label(element(by.binding(binding)))
    }

    public static byCssContainingText(css: string, text:string) {
        return new Label(element(by.cssContainingText(css, text)))
    }

    public static byElement(element: ElementFinder) {
        return new Label(element)
    }

}

export class textbox{
    
    public static byXpath(xpath: string) {
        return new Textbox(element(by.xpath(xpath)))
    }

    public static byCss(css: string) {
        return new Textbox(element(by.css(css)))
    }

    public static byId(id: string) {
        return new Textbox(element(by.id(id)))
    }

    public static byName(name: string) {
        return new Textbox(element(by.name(name)))
    }

    public static byClassName(className: string) {
        return new Textbox(element(by.className(className)))
    }

    public static byTagname(tagName: string) {
        return new Textbox(element(by.tagName(tagName)))
    }

    public static byModel(model: string) {
        return new Textbox(element(by.model(model)))
    }

    public static byBinding(binding: string) {
        return new Textbox(element(by.binding(binding)))
    }

    public static byCssContainingText(css: string, text:string) {
        return new Textbox(element(by.cssContainingText(css, text)))
    }

    public static byElement(element: ElementFinder) {
        return new Textbox(element)
    }
}

export class textarea{
    
    public static byXpath(xpath: string) {
        return new TextArea(element(by.xpath(xpath)))
    }

    public static byCss(css: string) {
        return new TextArea(element(by.css(css)))
    }

    public static byId(id: string) {
        return new TextArea(element(by.id(id)))
    }

    public static byName(name: string) {
        return new TextArea(element(by.name(name)))
    }

    public static byClassName(className: string) {
        return new TextArea(element(by.className(className)))
    }

    public static byTagname(tagName: string) {
        return new TextArea(element(by.tagName(tagName)))
    }

    public static byModel(model: string) {
        return new TextArea(element(by.model(model)))
    }

    public static byBinding(binding: string) {
        return new TextArea(element(by.binding(binding)))
    }

    public static byCssContainingText(css: string, text:string) {
        return new TextArea(element(by.cssContainingText(css, text)))
    }

    public static byElement(element: ElementFinder) {
        return new TextArea(element)
    }
}

export class checkbox{
    
    public static byXpath(xpath: string) {
        return new Checkbox(element(by.xpath(xpath)))
    }

    public static byCss(css: string) {
        return new Checkbox(element(by.css(css)))
    }

    public static byId(id: string) {
        return new Checkbox(element(by.id(id)))
    }

    public static byName(name: string) {
        return new Checkbox(element(by.name(name)))
    }

    public static byClassName(className: string) {
        return new Checkbox(element(by.className(className)))
    }

    public static byTagname(tagName: string) {
        return new Checkbox(element(by.tagName(tagName)))
    }

    public static byModel(model: string) {
        return new Checkbox(element(by.model(model)))
    }

    public static byBinding(binding: string) {
        return new Checkbox(element(by.binding(binding)))
    }

    public static byCssContainingText(css: string, text:string) {
        return new Checkbox(element(by.cssContainingText(css, text)))
    }

    public static byElement(element: ElementFinder) {
        return new Checkbox(element)
    }
}

export class radiobutton{
    
    public static byXpath(xpath: string) {
        return new RadioButton(element(by.xpath(xpath)))
    }

    public static byCss(css: string) {
        return new RadioButton(element(by.css(css)))
    }

    public static byId(id: string) {
        return new RadioButton(element(by.id(id)))
    }

    public static byName(name: string) {
        return new RadioButton(element(by.name(name)))
    }

    public static byClassName(className: string) {
        return new RadioButton(element(by.className(className)))
    }

    public static byTagname(tagName: string) {
        return new RadioButton(element(by.tagName(tagName)))
    }

    public static byModel(model: string) {
        return new RadioButton(element(by.model(model)))
    }

    public static byBinding(binding: string) {
        return new RadioButton(element(by.binding(binding)))
    }

    public static byCssContainingText(css: string, text:string) {
        return new RadioButton(element(by.cssContainingText(css, text)))
    }

    public static byElement(element: ElementFinder) {
        return new RadioButton(element)
    }
}

export class link{
    
    public static byXpath(xpath: string) {
        return new Link(element(by.xpath(xpath)))
    }

    public static byCss(css: string) {
        return new Link(element(by.css(css)))
    }

    public static byId(id: string) {
        return new Link(element(by.id(id)))
    }

    public static byName(name: string) {
        return new Link(element(by.name(name)))
    }

    public static byClassName(className: string) {
        return new Link(element(by.className(className)))
    }

    public static byLinkText(linkText: string) {
        return new Link(element(by.linkText(linkText)))
    }

    public static byPartialLinkText(linkText: string) {
        return new Link(element(by.partialLinkText(linkText)))
    }

    public static byTagname(tagName: string) {
        return new Link(element(by.tagName(tagName)))
    }

    public static byModel(model: string) {
        return new Link(element(by.model(model)))
    }

    public static byBinding(binding: string) {
        return new Link(element(by.binding(binding)))
    }

    public static byCssContainingText(css: string, text:string) {
        return new Link(element(by.cssContainingText(css, text)))
    }

    public static byElement(element: ElementFinder) {
        return new Link(element)
    }
}

export class icon {

    public static byXpath(xpath: string) {
        return new Icon(element(by.xpath(xpath)))
    }

    public static byCss(css: string) {
        return new Icon(element(by.css(css)))
    }

    public static byId(id: string) {
        return new Icon(element(by.id(id)))
    }

    public static byName(name: string) {
        return new Icon(element(by.name(name)))
    }

    public static byClassName(className: string) {
        return new Icon(element(by.className(className)))
    }

    public static byLinkText(linktext:string){
        return new Icon(element(by.linkText(linktext)))
    }

    public static byPartialLinkText(partialLinktext:string){
        return new Icon(element(by.partialLinkText(partialLinktext)))
    }

    public static byTagname(tagName: string) {
        return new Icon(element(by.tagName(tagName)))
    }

    public static byModel(model: string) {
        return new Icon(element(by.model(model)))
    }

    public static byBinding(binding: string) {
        return new Icon(element(by.binding(binding)))
    }

    public static byCssContainingText(css: string, text:string) {
        return new Icon(element(by.cssContainingText(css, text)))
    }

    public static byElement(element: ElementFinder) {
        return new Icon(element)
    }

}

export class image {

    public static byXpath(xpath: string) {
        return new Image(element(by.xpath(xpath)))
    }

    public static byCss(css: string) {
        return new Image(element(by.css(css)))
    }

    public static byId(id: string) {
        return new Image(element(by.id(id)))
    }

    public static byName(name: string) {
        return new Image(element(by.name(name)))
    }

    public static byClassName(className: string) {
        return new Image(element(by.className(className)))
    }

    public static byLinkText(linktext:string){
        return new Image(element(by.linkText(linktext)))
    }

    public static byPartialLinkText(partialLinktext:string){
        return new Image(element(by.partialLinkText(partialLinktext)))
    }

    public static byTagname(tagName: string) {
        return new Image(element(by.tagName(tagName)))
    }

    public static byModel(model: string) {
        return new Image(element(by.model(model)))
    }

    public static byBinding(binding: string) {
        return new Image(element(by.binding(binding)))
    }

    public static byCssContainingText(css: string, text:string) {
        return new Image(element(by.cssContainingText(css, text)))
    }

    public static byElement(element: ElementFinder) {
        return new Image(element)
    }

}

export class grid{
    
    public static byXpath(xpath: string) {
        return new Grid(element.all(by.xpath(xpath)))
    }

    public static byMultipleXpath(parentXpath: string, childXpath:string) {
        return new Grid(element(by.xpath(parentXpath)).all(by.xpath(childXpath)))
    }

    public static byXpathAndTag(xpath: string, tag:string) {
        return new Grid(element(by.xpath(xpath)).all(by.tagName(tag)))
    }
    
    public static byCss(css: string) {
        return new Grid(element.all(by.css(css)))
    }

    public static byId(id: string) {
        return new Grid(element.all(by.id(id)))
    }

    public static byName(name: string) {
        return new Grid(element.all(by.name(name)))
    }

    public static byClassName(className: string) {
        return new Grid(element.all(by.className(className)))
    }

    public static byLinkText(linkText: string) {
        return new Grid(element.all(by.linkText(linkText)))
    }

    public static byPartialLinkText(linkText: string) {
        return new Grid(element.all(by.partialButtonText(linkText)))
    }

    public static byElements(elements: ElementArrayFinder) {
        return new Grid(elements)
    }
}

