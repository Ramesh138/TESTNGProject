import { ElementFinder, ElementArrayFinder, element, by } from "protractor";
import { __ } from 'lodash/fp'
import { Actions } from "../actions/SeleniumActions";
import { button } from "./SmartLocators";

export class Button {

    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public highlight() {
        return Actions.highlight(this.element)
    }

    public scrollToElement() {
        return Actions.scrollToElement(this.element)
    }

    public click(log?: string) {
        return Actions.click(this.element, log)
    }

    public clear(log?: string) {
        return this.element.clear().then(() => {
        })
    }

    public delayClick(millies: number, log?: string) {
        return Actions.delayClick(this.element, millies, log)
    }

    public getText() {
        return this.element.getText()
    }

    public getAttribute(attribute: string) {
        return this.element.getAttribute(attribute)
    }

    public submit(log?: string) {
        return Actions.submit(this.element, log)
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public enter(log?: string) {
        return Actions.enter(this.element, log)
    }

    public hover(log?: string) {
        return Actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return Actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return Actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return Actions.jsClick(this.element, log)
    }

    public verifyText(text2Verify: string, log?: string) {
        return Actions.verifyText(this.element, text2Verify, log)
    }

    public verifyTextContains(text2Verify: string, log?: string) {
        return Actions.verifyTextContains(this.element, text2Verify, log)
    }

    public verifyAttribute(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttribute(this.element, attributeName, text2Verify, log)
    }

    public verifyAttributeContains(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttributeContains(this.element, attributeName, text2Verify, log)
    }


    public getElement() {
        return this.element
    }

    public clickAndWaitForAlertPresence(log?: string, millies?: number) {
        Actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return Actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return Actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return Actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return Actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return Actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }

    public PRINT_TEXT(preFix: string = '') {
        return Actions.printText(this.element, preFix);
    }

}

export class Icon {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement() {
        return Actions.scrollToElement(this.element)
    }

    public highlight() {
        return Actions.highlight(this.element)
    }

    public click(log?: string) {
        return Actions.click(this.element, log)
    }

    public enter(log?: string) {
        return Actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return Actions.submit(this.element, log)
    }

    public getAttribute(attribute: string) {
        return this.element.getAttribute(attribute)
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public hover(log?: string) {
        return Actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return Actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return Actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return Actions.jsClick(this.element, log)
    }

    public clickAfterVisibility(millies?: number) {
        return Actions.waitForInvisibility(this.element, millies).then(() => {
            return this.element.click();
        })
    }


    public verifyText(text2Verify: string, log?: string) {
        return Actions.verifyText(this.element, text2Verify, log)
    }

    public verifyTextContains(text2Verify: string, log?: string) {
        return Actions.verifyTextContains(this.element, text2Verify, log)
    }

    public verifyAttribute(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttribute(this.element, attributeName, text2Verify, log)
    }

    public verifyAttributeContains(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttributeContains(this.element, attributeName, text2Verify, log)
    }

    public getElement() {
        return this.element
    }

    public clickAndWaitForAlertPresence(log?: string, millies?: number) {
        Actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return Actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return Actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return Actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return Actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return Actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }
}

export class Image {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement() {
        return Actions.scrollToElement(this.element)
    }

    public highlight() {
        return Actions.highlight(this.element)
    }

    public getAttribute(attribute: string) {
        return this.element.getAttribute(attribute)
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public click(log?: string) {
        return Actions.click(this.element, log)
    }

    public enter(log?: string) {
        return Actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return Actions.submit(this.element, log)
    }

    public hover(log?: string) {
        return Actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return Actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return Actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return Actions.jsClick(this.element, log)
    }

    public verifyAttribute(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttribute(this.element, attributeName, text2Verify, log)
    }

    public verifyAttributeContains(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttributeContains(this.element, attributeName, text2Verify, log)
    }

    public getElement() {
        return this.element
    }

    public clickAndWaitForAlertPresence(log?: string, millies?: number) {
        Actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return Actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return Actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return Actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return Actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return Actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }

}

export class Label {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement() {
        return Actions.scrollToElement(this.element)
    }

    public highlight() {
        return Actions.highlight(this.element)
    }

    public getText() {
        return this.element.getText()
    }

    public getAttribute(attribute: string) {
        return this.element.getAttribute(attribute)
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public click(log?: string) {
        return Actions.click(this.element, log)
    }

    public enter(log?: string) {
        return Actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return Actions.submit(this.element, log)
    }

    public hover(log?: string) {
        return Actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return Actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return Actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return Actions.jsClick(this.element, log)
    }

    public verifyText(text2Verify: string, log?: string) {
        return Actions.verifyText(this.element, text2Verify, log)
    }

    public verifyTextContains(text2Verify: string, log?: string) {
        return Actions.verifyTextContains(this.element, text2Verify, log)
    }

    public verifyAttribute(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttribute(this.element, attributeName, text2Verify, log)
    }

    public verifyAttributeContains(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttributeContains(this.element, attributeName, text2Verify, log)
    }

    public getElement() {
        return this.element
    }

    public clickAndWaitForAlertPresence(log?: string, millies?: number) {
        Actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return Actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return Actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return Actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return Actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return Actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }

}

export class Textbox {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement() {
        return Actions.scrollToElement(this.element)
    }

    public highlight() {
        return Actions.highlight(this.element)
    }

    public getElement() {
        return this.element
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public send(text: string, log?: string) {
        return this.element.sendKeys(text).then(() => {

        })
    }

    public enter(log?: string) {
        return Actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return Actions.submit(this.element, log)
    }

    public click(log?: string) {
        return this.element.click().then(() => {

        })
    }

    public clear(log?: string) {
        return this.element.clear().then(() => {

        })
    }

    public clearSend(text: string, log?: string) {
        return this.element.clear().then(() => {
            return this.element.sendKeys(text).then(() => {

            })
        })
    }

    public clickSend(text: string, log?: string) {
        return this.element.click().then(() => {
            return this.element.clear().then(() => {
                return this.element.sendKeys(text).then(() => {

                })
            })
        })
    }

    public verifyText(text2Verify: string, log?: string) {
        return Actions.verifyText(this.element, text2Verify, log)
    }

    public verifyTextContains(text2Verify: string, log?: string) {
        return Actions.verifyTextContains(this.element, text2Verify, log)
    }

    public verifyAttribute(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttribute(this.element, attributeName, text2Verify, log)
    }

    public verifyAttributeContains(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttributeContains(this.element, attributeName, text2Verify, log)
    }

    public clickAndWaitForAlertPresence(log?: string, millies?: number) {
        Actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return Actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return Actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return Actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return Actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return Actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }
}
export class TextArea {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement() {
        return Actions.scrollToElement(this.element)
    }

    public highlight() {
        return Actions.highlight(this.element)
    }

    public getElement() {
        return this.element
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public send(text: string, log?: string) {
        return this.element.sendKeys(text).then(() => {

        })
    }

    public enter(log?: string) {
        return Actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return Actions.submit(this.element, log)
    }

    public click(log?: string) {
        return this.element.click().then(() => {

        })
    }

    public clear(log?: string) {
        return this.element.clear().then(() => {

        })
    }

    public clearSend(text: string, log?: string) {
        return this.element.clear().then(() => {
            return this.element.sendKeys(text).then(() => {

            })
        })
    }

    public clickSend(text: string, log?: string) {
        return this.element.click().then(() => {
            return this.element.clear().then(() => {
                return this.element.sendKeys(text).then(() => {

                })
            })
        })
    }

    public verifyText(text2Verify: string, log?: string) {
        return Actions.verifyText(this.element, text2Verify, log)
    }

    public verifyTextContains(text2Verify: string, log?: string) {
        return Actions.verifyTextContains(this.element, text2Verify, log)
    }

    public verifyAttribute(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttribute(this.element, attributeName, text2Verify, log)
    }

    public verifyAttributeContains(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttributeContains(this.element, attributeName, text2Verify, log)
    }

    public clickAndWaitForAlertPresence(log?: string, millies?: number) {
        Actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return Actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return Actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return Actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return Actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return Actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }
}


export class Checkbox {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement() {
        return Actions.scrollToElement(this.element)
    }

    public highlight() {
        return Actions.highlight(this.element)
    }

    public getElement() {
        return this.element
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public enter(log?: string) {
        return Actions.enter(this.element, log)
    }

    public space(log?: string) {
        return Actions.space(this.element, log)
    }

    public submit(log?: string) {
        return Actions.submit(this.element, log)
    }

    public check(log?: string) {
        return this.element.isSelected().then((flag: boolean) => {
            if (!flag)
                this.click(log)
        })
    }

    public unCheck(log?: string) {
        return this.element.isSelected().then((flag: boolean) => {
            if (flag)
                this.click(log)
        })
    }

    public isSelected(log?: string) {
        return this.element.isSelected()
    }

    public click(log?: string) {
        return Actions.click(this.element, log)
    }

    public hover(log?: string) {
        return Actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return Actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return Actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return Actions.jsClick(this.element, log)
    }

    public verifyAttribute(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttribute(this.element, attributeName, text2Verify, log)
    }

    public verifyAttributeContains(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttributeContains(this.element, attributeName, text2Verify, log)
    }

    public clickAndWaitForAlertPresence(log?: string, millies?: number) {
        Actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return Actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return Actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return Actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return Actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return Actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }

    public waitForelementToBeSelected(millies: number = 30000) {
        return Actions.waitForelementToBeSelected(this.element, millies)
    }

}

export class RadioButton {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement() {
        return Actions.scrollToElement(this.element)
    }

    public highlight() {
        return Actions.highlight(this.element)
    }

    public getElement() {
        return this.element
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isSelected() {
        return this.element.isSelected()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public enter(log?: string) {
        return Actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return Actions.submit(this.element, log)
    }

    public click(log?: string) {
        return Actions.click(this.element, log)
    }

    public hover(log?: string) {
        return Actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return Actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return Actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return Actions.jsClick(this.element, log)
    }

    public verifyAttribute(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttribute(this.element, attributeName, text2Verify, log)
    }

    public verifyAttributeContains(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttributeContains(this.element, attributeName, text2Verify, log)
    }

    public clickAndWaitForAlertPresence(log?: string, millies?: number) {
        Actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return Actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return Actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return Actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return Actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return Actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }
}

export class Link {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }

    public scrollToElement() {
        return Actions.scrollToElement(this.element)
    }

    public highlight() {
        return Actions.highlight(this.element)
    }

    public getElement() {
        return this.element
    }

    public isEnabled() {
        return this.element.isEnabled()
    }

    public isDisplayed() {
        return this.element.isDisplayed()
    }

    public isPresent() {
        return this.element.isPresent()
    }

    public enter(log?: string) {
        return Actions.enter(this.element, log)
    }

    public submit(log?: string) {
        return Actions.submit(this.element, log)
    }

    public click(log?: string) {
        return Actions.click(this.element, log)
    }

    public hover(log?: string) {
        return Actions.hover(this.element, log)
    }

    public actionClick(log?: string) {
        return Actions.actionClick(this.element, log)
    }

    public doubleClick(log?: string) {
        return Actions.doubleClick(this.element, log)
    }

    public jsClick(log?: string) {
        return Actions.jsClick(this.element, log)
    }

    public verifyText(text2Verify: string, log?: string) {
        return Actions.verifyText(this.element, text2Verify, log)
    }

    public verifyTextContains(text2Verify: string, log?: string) {
        return Actions.verifyTextContains(this.element, text2Verify, log)
    }

    public verifyAttribute(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttribute(this.element, attributeName, text2Verify, log)
    }

    public verifyAttributeContains(attributeName: string, text2Verify: string, log?: string) {
        return Actions.verifyAttributeContains(this.element, attributeName, text2Verify, log)
    }

    public clickAndWaitForAlertPresence(log?: string, millies?: number) {
        Actions.clickAndWaitForAlertPresence(this.element, log, millies)
    }

    public waitForVisibility(millies?: number) {
        return Actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return Actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return Actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return Actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return Actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }
}

export class Grid {
    private elements: ElementArrayFinder;

    constructor(elements: ElementArrayFinder) {
        this.elements = elements
    }

    public scrollToElement(index: number) {
        return Actions.scrollToElement(this.elements.get(index))
    }

    public highlight(index: number) {
        return Actions.highlight(this.elements.get(index))
    }

    public getElements() {
        return this.elements
    }

    public getElement(index: number) {
        return this.elements.get(index)
    }

    public clickByIndex(index: number) {
        return this.elements.get(index).click()
    }

    public clickByRandom() {
        return this.elements.count().then((count) => {
            var rNo: number = Math.floor((Math.random() * (count - 1)) + 1);
            return this.elements.get(rNo).click()
        })
    }

    public clickWhenAttributeIncludes(attribute, value) {
        return this.elements.filter((elem: ElementFinder) => {
            return elem.getAttribute(attribute).then((text: string) => {
                return text.trim().includes(value.trim())
            });
        }).click();
    }

    public clickWhenAttributeNotIncludes(attribute, value) {
        return this.elements.filter((elem: ElementFinder) => {
            return elem.getAttribute(attribute).then((text: string) => {
                return !text.trim().includes(value.trim())
            });
        }).click();
    }

    public async clickOnMatchingText(textToClick: string) {
        return this.elements.filter((elem: ElementFinder) => {
            return elem.getText().then((text: string) => {
                return text.trim() === textToClick.trim();
            });
        }).first().click();
    }

    public getMatchingElements(textToClick: string) {
        return this.elements.filter((elem: ElementFinder) => {
            return elem.getText().then((text: string) => {
                return text.trim() === textToClick.trim();
            });
        })
    }


    public clickAll() {
        return this.elements.each((elem) => {
            return elem?.click();
        })
    }

    public isEnabled(index: number) {
        return this.elements.get(index).isEnabled()
    }

    public isDisplayed(index: number) {
        return this.elements.get(index).isDisplayed()
    }

    public isPresent(index: number) {
        return this.elements.get(index).isPresent()
    }

    public isSelected(index: number) {
        return this.elements.get(index).isSelected()
    }

    public waitForVisibility(millies?: number) {
        return Actions.waitForVisibility(this.elements.get(0), millies)
    }

}

export class SelectBox {
    private element: ElementFinder;

    constructor(element: ElementFinder) {
        this.element = element
    }


    public selectByIndex(index: number) {
        return Actions.selectDropdownByIndex(this.element, index)
    }

    public selectByValue(value: string) {
        return Actions.selectDropdownByValue(this.element, value)
    }

    public selectByText(value: string) {
        return Actions.selectDropdownByText(this.element, value)
    }

    public scrollToElement() {
        return Actions.scrollToElement(this.element)
    }

    public waitForVisibility(millies?: number) {
        return Actions.waitForVisibility(this.element, millies)
    }

    public waitForPresence(millies?: number) {
        return Actions.waitForPresence(this.element, millies)
    }

    public waitForInvisibility(millies?: number) {
        return Actions.waitForInvisibility(this.element, millies)
    }

    public waitForStaleness(millies?: number) {
        return Actions.waitForStaleness(this.element, millies)
    }

    public waitForClickable(millies?: number) {
        return Actions.waitForClickable(this.element, millies)
    }

    public waitForTextToPresentInElement(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElement(this.element, text, millies)
    }

    public waitForTextToPresentInElementValue(text: string, millies?: number) {
        return Actions.waitForTextToPresentInElementValue(this.element, text, millies)
    }


}