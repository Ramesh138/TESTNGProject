const { HTTP } = require('http-call')

export class ServiceUtils {

    public static async get(url: string, options?: any) {
        if (options) {
            return await HTTP.get(url, options)
        } else {
            return await HTTP.get(url)
        }

    }

    public static async post(url: string, options?: any) {
        if (options) {
            return await HTTP.post(url, options)
        } else {
            return await HTTP.post(url)
        }

    }

} 