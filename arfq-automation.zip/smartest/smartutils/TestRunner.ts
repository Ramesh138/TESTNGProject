import {Jsonutils} from '../commonutils/JsonUtils'
import configutils from './Configurationutils'

var ju = new Jsonutils()
var cu = new configutils()

class Testrunner {
    public executableModules: any = []
}

var tc = new Testrunner()

export function setUp() {
    
    var allModules = cu.createTestSuiteJson()
    tc.executableModules = cu.getExecutableModules(allModules)
    cu.updateExecutableModulesInConfiguration(tc.executableModules)
}

export function getBrowser(): string {
    return cu.browserToExecute()
}

export function getCapabilities(): any {
    return cu.getCapability()
}

export function executableFeatures(): string[] {
    return cu.getExecutableTestCasesFromExecutableModules(tc.executableModules)
}