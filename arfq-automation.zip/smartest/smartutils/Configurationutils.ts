import { Constants, Dynamic } from '../constants/Constants'
import { Jsonutils } from '../commonutils/JsonUtils'
import { Folderutils } from '../commonutils/FolderUtils'

import * as fs from 'fs'
import * as path from 'path'
import * as _ from 'lodash'
import * as XLSX from 'xlsx'

var ju = new Jsonutils()
var fl = new Folderutils()

export default class Configurationutils {

    createTestSuiteJson(): any {

        fl.createDir(Constants.testSuiteJsonPath)

        var moduleNames: any = []
        var workbook = XLSX.readFile(Constants.testSuiteExcelFile);
        var sheet_name_list = workbook.SheetNames;
        sheet_name_list.forEach(function (sName: string) {
            moduleNames.push(sName)
            var moduleObj = XLSX.utils.sheet_to_json(workbook.Sheets[sName])
            var obj = { Module: moduleObj }
            ju.writeJson(Constants.testSuiteJsonPath + "/" + sName + ".json", obj)
        })
        return moduleNames
    }

    updateExecutableModulesInConfiguration(exMods: any) {
        Dynamic.executableModulesList = exMods
    }

    convertExcelTestDataToJSON(mName: string[]) {
        for (var i = 0; i < mName.length; i++) {
            var workbook = XLSX.readFile(Constants.testDataPath + '/' + mName[i] + ".xlsx");
            var sheet_name_list = workbook.SheetNames;
            sheet_name_list.forEach((sName: any) => {
                var moduleObj = XLSX.utils.sheet_to_json(workbook.Sheets[sName])
                var obj = { Testdata: moduleObj }
                fl.createDir(Constants.convertedTestDataJsonPath)
                var path = Constants.convertedTestDataJsonPath + "/" + mName[i]
                fl.createDir(path)
                ju.writeJson(path + "/" + sName + ".json", obj)
            })
        }
    }

    createTestCaseListByModule(exMods: any) {
        var allModules: any = []
        for (const mod of exMods) {
            var _path = Constants.convertedTestDataJsonPath + '/' + mod
            var files = fs.readdirSync(_path)
            for (const file of files) {
                var filePath = _path + '/' + file
                var tcName = path.basename(filePath, path.extname(filePath))
                allModules.push(mod + "|" + tcName)
            }
        }
        Dynamic.testCaseListByModule = allModules
    }

    browserToExecute(): string {
        var pcObj = ju.readJsonFile(Constants.projectConfigJsonFile)
        return pcObj.Browser
    }

    getCapability(): any {
        var pcObj = ju.readJsonFile(Constants.projectConfigJsonFile)
        if (pcObj.Platform === "Web") {
            var cap = pcObj.WebCapabilities
            return cap
        } else if (pcObj.Platform === "Mobile") {
            var cap = pcObj.MobileCapabilities
            return cap
        }
    }

    getExecutableModules(allModules: any): string[] {
        var exMod: any = []
        for (const mod of allModules) {
            var fpath: string = Constants.testSuiteJsonPath + '/' + mod + '.json'
            var obj = ju.readJsonFile(fpath)
            for (var i = 0; i < obj.Module.length; i++) {
                var flag = obj.Module[i].Flag
                var _mod = path.basename(fpath, path.extname(fpath))
                if (flag === 'Yes')
                    exMod.push(_mod)
            }
        }
        exMod = _.uniq(exMod)
        return exMod
    }

    getExecutableTestCasesFromExecutableModules(executableModules: string[]): string[] {
        var specs: any = []
        for (const mod of executableModules) {
            var obj = ju.readJsonFile(Constants.testSuiteJsonPath + '/' + mod + ".json")
            for (var i = 0; i < obj.Module.length; i++) {
                var flag = obj.Module[i].Flag
                var fName = obj.Module[i].FeatureName
                if (flag === 'Yes')
                    specs.push('../../features/' + mod + '/' + fName + '.feature')
            }
        }
        specs = _.uniq(specs)
        return specs
    }

}