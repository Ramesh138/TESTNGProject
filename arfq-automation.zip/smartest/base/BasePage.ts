export function getLabel(key: string): string {
    return '';
}