import { browser, protractor } from "protractor";
import { SupplierScenarioPage } from '../pages/SupplierScenarioPage';
const { When, Then } = require("cucumber");
import { CommonMethods } from '../flows/CommonMethods';
When('I edit the scenario {string}', { timeout: 100 * 15000 }, async (scenario) => {
     await SupplierScenarioPage.getNavigateLink("scenarios").waitForClickable(2000);
     await SupplierScenarioPage.getNavigateLink("scenarios").click();
     // await SupplierScenarioPage.getAppScenario(scenario).waitForClickable(5000);
     await browser.sleep(5000)
     await SupplierScenarioPage.getAppScenario(scenario).click();
});

Then('Select CBM as {string}', { timeout: 100 * 15000 }, async (scenario) => {
     await browser.sleep(2000)
     await SupplierScenarioPage.getNavigateLink("cbm").click();
     await browser.sleep(2000)
     await SupplierScenarioPage.moneyChoice.click();

});

Then('Click on navigate link  {string}', { timeout: 100 * 15000 }, async (navigationLink: string) => {
     await SupplierScenarioPage.getNavigateLink(navigationLink).click();
});

Then('Add currencies {string}', { timeout: 100 * 15000 }, async (currency: string) => {
     await SupplierScenarioPage.getNavigateLink("currencies").click();
     await browser.sleep(2000)
     await SupplierScenarioPage.currency.selectByText(currency);
     await browser.sleep(2000)
     await SupplierScenarioPage.addCurrency.click()
     await SupplierScenarioPage.supplierPageLoading.waitForInvisibility(15000)
});

Then('Navigate to Section {string}', { timeout: 100 * 15000 }, async (section: string) => {
     await SupplierScenarioPage.getNavigateLink("sections").click();
     await browser.sleep(2000)
     await SupplierScenarioPage.getSectionLinks(section).click()
     await browser.sleep(5000)
});

Then('Navigate back to Scenario', { timeout: 100 * 15000 }, async () => {
     await browser.sleep(2000)
     await SupplierScenarioPage.navigateToBreadCrumScenario().click();
     await browser.sleep(1000)
});

Then('Create an Offer', { timeout: 100 * 15000 }, async () => {
     await browser.sleep(2000)
     await SupplierScenarioPage.getNavigateLink("Offers").click();
     await SupplierScenarioPage.getButtonFromAppSection("Offers", "Send").click()
     await browser.sleep(2000)
     await SupplierScenarioPage.getTextAreaFromSection("Detail").send("Offer has been added")
     await SupplierScenarioPage.sendOffer.click()
     await browser.sleep(2000)

     await SupplierScenarioPage.supplierPageLoading.waitForInvisibility(15000)
});

Then('Generate and Send F1', { timeout: 100 * 15000 }, async () => {
     await browser.sleep(2000)
     await SupplierScenarioPage.getNavigateLink("f1").click();
     await SupplierScenarioPage.getButtonFromSection("f1", "Generate f1 Sheet").click()
     await browser.sleep(10000)
     await SupplierScenarioPage.supplierPageLoading.waitForInvisibility(15000)
     await browser.sleep(2000)
     await SupplierScenarioPage.f1AttachFile.click()
     await browser.sleep(2000)
     await SupplierScenarioPage.getTextAreaFromSection("Detail").send("F1 signed and attached")

     await SupplierScenarioPage.getNavigateLink("F1 File").click();
     await browser.sleep(1000)
     await SupplierScenarioPage.getButtonFromAppSection("F1 File", "Add").click()
     await browser.sleep(2000)
     await CommonMethods.runExeFile("C:\\Users\\Public\\MyWork\\GRM\\ARFQ\\automation\\arfq-automation\\input\\autoit\\FileUpload.exe C:\\Users\\Public\\MyWork\\GRM\\ARFQ\\automation\\arfq-automation\\input\\files\\F1_Document.pdf")
     await browser.sleep(10000)
     await browser.sleep(2000)
     await SupplierScenarioPage.getNavigateLink("Agreement").click();
     await browser.sleep(1000)
     await SupplierScenarioPage.getCheckBoxFromAppSection("Agreement").click()
     await browser.sleep(1000)
     await SupplierScenarioPage.sendF1.click()
     await browser.sleep(2000)
     await SupplierScenarioPage.supplierPageLoading.waitForInvisibility(30000)
     await browser.sleep(2000)
});



