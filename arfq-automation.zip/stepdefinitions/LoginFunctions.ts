import { browser, protractor } from "protractor";
import { Home } from '../pages/Home';
import { SupplierLogin } from '../pages/SupplierLogin';
const { Given, When, Then } = require("cucumber");
import { Constants } from '../pages/Constants';
// import { CommonMethods } from '../flows/CommonMethods';
Given('I launch the ARFQ application in {string}', { timeout: 100 * 30000 }, async (environment) => {
     var url = "http://sma-app.dok-re7.intra.renault.fr";
     await console.log(environment)
     if (environment.toUpperCase().includes("DEV")) {
          url = "http://sma-app.dok-dev.intra.renault.fr";
     }
     return await browser.get(url);

});

Given('I launch the Supplier application in {string}', { timeout: 100 * 30000 }, async (environment) => {
     var url = "https://re7.sma.re7.aws.renault.com";
     await console.log(environment)
     if (environment.toUpperCase().includes("DEV")) {
          url = "https://re7.sma.re7.aws.renault.com";
     }
     return await browser.get(url);
});

Given('I navigate to ARFQ application in {string}', { timeout: 100 * 30000 }, async (environment) => {
     var url = "http://sma-app.dok-re7.intra.renault.fr";
     if (environment.toUpperCase().includes("DEV")) {
          url = "http://sma-app.dok-dev.intra.renault.fr";
     }
     return await browser.navigate().to(url);
});

Given('I open new window and launch supplier app', { timeout: 100 * 30000 }, async () => {
     return await browser.executeScript('window.open()').then(function () {
          browser.getAllWindowHandles().then(function (handles) {
               var secondWindow = handles[1];
               browser.switchTo().window(secondWindow).then(function () {
                    return browser.get("https://re7.sma.re7.aws.renault.com/home");
               });
          });
     });
});



When('I Navigate to tile {string}', { timeout: 100 * 10000 }, async (tileName) => {
     await Constants.pageLoadingSpinner.waitForInvisibility(7000)
     await Home.navigateToTile(tileName).waitForClickable()
     await Home.navigateToTile(tileName).click()

});

Given('I login with {string} supplier', { timeout: 100 * 10000 }, async (supplierMail) => {
     await browser.sleep(10000)
     await SupplierLogin.userMail.send(supplierMail)

     
     await SupplierLogin.submit.click()
     await browser.sleep(10000)
});


// When('I Navigate to tile {string}', async function (string) {
//      await Home.createRFQTile().waitForClickable()
//      await Home.createRFQTile().click()
//    });
