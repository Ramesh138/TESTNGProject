import { cpuUsage } from "process";
import { browser, protractor } from "protractor";
import { Constants } from '../pages/Constants';
import { RFQPage } from '../pages/RFQPage';
import { CommonMethods } from '../flows/CommonMethods';
const { Given, When, Then } = require("cucumber");

When('I click on {string}', { timeout: 100 * 7000 }, async (string) => {
     await RFQPage.createRFQbtn.waitForClickable()
     await Constants.pageLoadingSpinner.waitForInvisibility(7000)
     await RFQPage.createRFQbtn.click()
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     
});

When('I Edit existing RFQ {string}', { timeout: 100 * 10000 }, async (RFQID) => {
     await browser.sleep(6000)
     await Constants.pageLoadingSpinner.waitForInvisibility(7000)
     await RFQPage.getExistingRFQID(RFQID).click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(15000)
});

When('I Create a RFQ with AGD as {string} and SAM as {string}', { timeout: 100 * 15000 }, async (AGD, SAM) => {
     await browser.sleep(2000)
     await console.log("waiting")
     await Constants.pageLoadingSpinner.waitForInvisibility(7000)
     await RFQPage.createRFQbtn.waitForClickable()
     await console.log("before clicking")
     await RFQPage.createRFQbtn.click()
     await Constants.pageLoadingSpinner.waitForInvisibility(7000)
     await Constants.pageLoadingSpinner.waitForInvisibility(5000)
     await browser.sleep(4000)
     await RFQPage.documentDilog.getDropDownOf("AGD Perimeter").waitForVisibility()
     await RFQPage.documentDilog.getTextBoxOf("Due Date").send("10-31-2020")
     await RFQPage.documentDilog.getDropDownOf("AGD Perimeter").selectByText(AGD)
     await browser.sleep(1000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     await browser.sleep(1000)
     await RFQPage.documentDilog.getDropDownOf("AGD Perimeter").waitForVisibility()
     await RFQPage.documentDilog.getDropDownOf("SAM Perimeter").selectByText(SAM)
     await browser.sleep(4000)
     await RFQPage.documentDilog.getButton("Create").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(15000)
     await RFQPage.getTextBoxOf("Due Date").verifyAttributeContains("ng-reflect-model","10-31-2020")
});
When('Add a {string} document in Alliance Reference List', { timeout: 100 * 15000 }, async (projectType) => {
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(15000)
     await RFQPage.getSection("Alliance Reference List").scrollToElement();
     await RFQPage.getUploadFromSectionFor("Alliance Reference List", projectType).click()
     await CommonMethods.runExeFile("C:\\Users\\Public\\MyWork\\GRM\\ARFQ\\automation\\arfq-automation\\input\\autoit\\FileUpload.exe C:\\Users\\Public\\MyWork\\GRM\\ARFQ\\automation\\arfq-automation\\input\\files\\RFQPackage-APO_v4.0_Oct2019.doc")
     await browser.sleep(10000)
     await console.log("after upload")
     await Constants.pageLoadingSpinner.waitForInvisibility(60000)
})


When('Add Project Volume Estimation', { timeout: 100 * 15000 }, async () => {
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(15000)
     await RFQPage.getSection("Project Volume Estimation").scrollToElement();
     await RFQPage.getButtonFromSection("Project Volume Estimation", "Add").click()
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     await RFQPage.documentDilog.getButton("Search").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     await browser.sleep(2000)
     await RFQPage.documentDilog.firstRowSearchContent().space()
     await RFQPage.documentDilog.getButton("Add").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(15000)
});


When('Add Project Volume Estimation with {string} brand', { timeout: 100 * 7000 }, async (brand) => {
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(15000)
     await RFQPage.getSection("Project Volume Estimation").scrollToElement();
     await RFQPage.getButtonFromSection("Project Volume Estimation", "Add").click()
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     await RFQPage.documentDilog.getBrandType(brand).click()
     await RFQPage.documentDilog.getButton("Search").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     await browser.sleep(2000)
     await RFQPage.documentDilog.firstRowSearchContent().space()
     await RFQPage.documentDilog.getButton("Add").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
});



When('Add a Part Detail & Mix', { timeout: 100 * 7000 }, async () => {
     await browser.sleep(2000)
     await RFQPage.getSection("Part detail & Mix").scrollToElement();
     await RFQPage.getButtonFromSection("Part detail & Mix", "Add Part").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     await RFQPage.documentDilog.getButton("Search").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(5000)
     await browser.sleep(5000)
     await RFQPage.documentDilog.searchContentTableInput().space()
     await RFQPage.documentDilog.getButton("Add").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(5000)
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(5000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
});

When('Create a Part Detail & Mix for SAM perimeter as SAM as {string}', { timeout: 100 * 7000 }, async (SAM) => {
     await browser.sleep(2000)
     await RFQPage.getSection("Part detail & Mix").scrollToElement();
     await RFQPage.getButtonFromSection("Part detail & Mix", "Create Part").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     await RFQPage.documentDilog.getDropDownOf("SAM Perimeter").selectByText(SAM)
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     await RFQPage.documentDilog.getTextBoxOf("Part Designation").send("Test Part Designation")
     await RFQPage.documentDilog.getDropDownOf("FSA Name").selectByIndex(1)
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)

     await RFQPage.documentDilog.getButton("Save").click()
     await browser.sleep(2000)
     await RFQPage.documentDilog.getButton("OK").click()
     await Constants.pageLoadingSpinner.waitForInvisibility(5000)
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(5000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
});



When('Add {string} as {string} Actor', { timeout: 100 * 7000 }, async (actorName, typeOfActor) => {
     await RFQPage.getSection("Actors").scrollToElement();
     await browser.sleep(2000)
     await RFQPage.getTabFromSection("Actors", typeOfActor).click()
     await RFQPage.getButtonFromSection("Actors", "Add").click()
     await RFQPage.documentDilog.getActorInput().send(actorName)
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(25000)
     await RFQPage.documentDilog.getActorDetailCard(actorName).waitForClickable(5000)
     await RFQPage.documentDilog.getActorDetailCard(actorName).click()
     await browser.sleep(2000)
     await RFQPage.documentDilog.getButton("Add").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(5000)
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(30000)
});

When('Add Consultation Scenario', { timeout: 100 * 7000 }, async () => {
     await RFQPage.getSection("Consultation Scenario").scrollToElement();
     await browser.sleep(2000)
     await RFQPage.getButtonFromSection("Consultation Scenario", "Create").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(15000)

})

When('Add {string} as Suppliers Group and {string} as Supplier Contact', { timeout: 100 * 7000 }, async (groupName, contactName) => {
     await RFQPage.getSection("Suppliers").scrollToElement();
     await browser.sleep(2000)
     await RFQPage.getButtonFromSubSection("Suppliers", "Groups", "Add").click()
     await browser.sleep(2000)
     await RFQPage.documentDilog.getAddSupplierGroupTextBox().send(groupName)
     await Constants.pageLoadingSpinner.waitForInvisibility(25000)
     await browser.sleep(2000)
     await RFQPage.documentDilog.getAddSupplierGroupName(groupName).space()
     await browser.sleep(2000)
     await console.log("before")
     await RFQPage.documentDilog.getButton("Add").enter()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(10000)
     await browser.sleep(2000)
     await RFQPage.getNDAComplianceFromSubSection("Suppliers", "Groups").space()
     await browser.sleep(2000)
     await RFQPage.getButtonFromSubSection("Suppliers", "Contacts", "Add").click()
     await browser.sleep(2000)
     await RFQPage.documentDilog.getAddSupplierGroupTextBox().send(contactName)
     await Constants.pageLoadingSpinner.waitForInvisibility(25000)
     await browser.sleep(2000)
     await RFQPage.documentDilog.getAddSupplierGroupName(contactName).space()
     await browser.sleep(2000)
     await RFQPage.documentDilog.getButton("Add").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(5000)
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(15000)

     await RFQPage.getSection("Send Scenario").waitForVisibility(3000)

});

Then('Verify Scenario is ready to send', { timeout: 100 * 7000 }, async () => {
     await browser.sleep(2000)
     await RFQPage.getSection("Send Scenario").scrollToElement();
     await RFQPage.getSupplierToSendScenario().space()
     await RFQPage.ScenarioContentComplianceStatus("Main buyer").verifyAttributeContains("ng-reflect-ng-class", "sceactive", "Main buyer in active")
});
Then('Send Scenario to supplier', { timeout: 100 * 7000 }, async () => {
     await browser.sleep(2000)
     await RFQPage.getButtonFromSection("Send Scenario", "send to supplier").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(15000)
     await browser.sleep(2000)
     await RFQPage.documentDilog.getElementOf("Comments").send("Automation testing scenario")
     await RFQPage.documentDilog.getButton("Send").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(15000)
     await browser.sleep(2000)
     await RFQPage.documentDilog.getButton("Return").click()
     await browser.sleep(2000)
     await Constants.pageLoadingSpinner.waitForInvisibility(15000)
     await browser.sleep(2000)

});

