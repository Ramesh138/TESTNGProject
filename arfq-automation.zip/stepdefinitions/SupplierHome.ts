import { browser, protractor } from "protractor";
import { SupplierHomePage } from '../pages/SupplierHomePage';
const { Given, When, Then } = require("cucumber");
import { Constants } from '../pages/Constants';

When('I edit the RFQ {string}', { timeout: 100 * 15000 }, async (RFQID) => {
     await SupplierHomePage.getRFQBook(RFQID).waitForClickable(10000)
     await SupplierHomePage.getRFQBook(RFQID).click();
     await browser.sleep(2000)
     await SupplierHomePage.documentDilog.getButton("Edit").click()
     await browser.sleep(2000)
     await SupplierHomePage.supplierPageLoading.waitForInvisibility(10000)
});
