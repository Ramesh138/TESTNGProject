import { browser, protractor } from "protractor";
import { QuotationPage } from '../pages/QuotationPage';
const { Given, When, Then } = require("cucumber");
// import { Constants } from '../pages/Constants';


Then('Add Pricing details', { timeout: 100 * 15000 }, async () => {
     await QuotationPage.getNavigateLink("prices").click();
     await browser.sleep(2000)
     await QuotationPage.getCheckBoxPriceTableRow().click();
     await QuotationPage.getPackagingFromPriceTableRow().send("100")
     await browser.sleep(1000)
     await QuotationPage.getTechnicalFromPriceTableRow().send("100")
     await browser.sleep(1000)
     await QuotationPage.getTransportFromPriceTableRow().send("100")
     await browser.sleep(2000)
     await QuotationPage.getNavigateLink("comment").click();
     await QuotationPage.getTextAreaFromSection("comment").send("Added tooling investement details")
});