var myApp = angular.module("myModule", [])

myApp.filter('unique', function () {
    // we will return a function which will take in a collection
    // and a keyname
    return function (collection, keyname) {
        // we define our output and keys array;
        var output = [],
            keys = [];

        // we utilize angular's foreach function
        // this takes in our original collection and an iterator function
        angular.forEach(collection, function (item) {
            // we check to see whether our object exists
            var key = item[keyname];
            // if it's not already part of our keys array
            if (keys.indexOf(key) === -1) {
                // add it to our keys array
                keys.push(key);
                // push this item to our final output array
                output.push(item);
            }
        });
        // return our array which should be devoid of
        // any duplicates
        return output;
    };
});

myApp.controller("myController", ($scope, $http) => {

    $scope.onloadFun = function () {
        $http.get("json/cucumber_report.json").then((result) => {

            var content = {
                projectName: '  ARFQ',
                data: []
            }

            $scope.featuresInfo = [];
            $scope.featuresInfoDynamic = [];

            for (const c of result.data) {
                const paths = c.uri.split('\\')
                if ($scope.featuresInfo.length === 0) {
                    tempD = {
                        feature: c.name,
                        expand: false,
                        scenario: [{
                            mName: paths[paths.length - 2],
                            specName: paths[paths.length - 1],
                            name: c.elements[0].name,
                            startTime: '0',
                            endTime: '0',
                            status: 'passed'
                        }],
                    }
                    temp = {
                        feature: c.name,
                        expand: false,
                        scenario: [{
                            mName: paths[paths.length - 2],
                            specName: paths[paths.length - 1],
                            name: c.elements[0].name,
                            startTime: '0',
                            endTime: '0',
                            steps: [],
                            status: 'passed'
                        }],
                    }
                    for (let i = 0; i < c.elements[0].steps.length; i++) {
                        const step = {
                            startTime: "0",
                            endTime: "0",
                            stepName: c.elements[0].steps[i].name,
                            logs: [],
                            errorMessage: "",
                            failureStack: "",
                            screenshotPath: "",
                            screenShot: "",
                            status: c.elements[0].steps[i].result.status
                        }
                        const kw = c.elements[0].steps[i].keyword
                        if (kw === 'After' || kw === 'Before') {

                        } else {
                            temp.scenario[0].steps.push(step);
                            const s = c.elements[0].steps[i].result.status
                            recentStepNo = temp.scenario[0].steps.length - 1;
                            if (s === 'failed') {
                                temp.scenario[0].steps[recentStepNo].screenShot = c.elements[0].steps[c.elements[0].steps.length - 2]['embeddings'][0].data
                                temp.scenario[0].status = 'failed'
                                tempD.scenario[0].status = 'failed'
                                temp.scenario[0].steps[recentStepNo].failureStack = c.elements[0].steps[i].result.error_message
                            }
                        }
                    }
                    $scope.featuresInfo.push(temp)
                    $scope.featuresInfoDynamic.push(tempD)
                } else {
                    let flag = false
                    for (let i = 0; i < $scope.featuresInfo.length; i++) {
                        if ($scope.featuresInfo[i].feature === c.name) {
                            tempD1 = {
                                mName: paths[paths.length - 2],
                                specName: paths[paths.length - 1],
                                name: c.elements[0].name,
                                startTime: '0',
                                endTime: '0',
                                steps: [],
                                status: 'passed'
                            }
                            temp1 = {
                                mName: paths[paths.length - 2],
                                specName: paths[paths.length - 1],
                                name: c.elements[0].name,
                                startTime: '0',
                                endTime: '0',
                                steps: [],
                                status: 'passed'
                            }
                            for (let j = 0; j < c.elements[0].steps.length; j++) {
                                const step = {
                                    startTime: "0",
                                    endTime: "0",
                                    stepName: c.elements[0].steps[j].name,
                                    logs: [],
                                    errorMessage: "",
                                    failureStack: "",
                                    screenshotPath: "",
                                    screenShot: "",
                                    status: c.elements[0].steps[j].result.status
                                }
                                const kw = c.elements[0].steps[j].keyword
                                if (kw === 'After' || kw === 'Before') {

                                } else {
                                    temp1.steps.push(step);
                                    const s = c.elements[0].steps[j].result.status
                                    recentStepNo = temp1.steps.length - 1;
                                    if (s === 'failed') {
                                        temp1.steps[recentStepNo].screenShot = c.elements[0].steps[c.elements[0].steps.length - 2]['embeddings'][0].data
                                        temp1.status = 'failed'
                                        tempD1.status = 'failed'
                                        temp1.steps[recentStepNo].failureStack = c.elements[0].steps[j].result.error_message
                                    }
                                }
                            }
                            $scope.featuresInfo[i].scenario.push(temp1)
                            $scope.featuresInfoDynamic[i].scenario.push(tempD1)
                            flag = true;
                        }
                    }
                    if (!flag) {
                        tempD2 = {
                            feature: c.name,
                            expand: false,
                            scenario: [{
                                mName: paths[paths.length - 2],
                                specName: paths[paths.length - 1],
                                name: c.elements[0].name,
                                startTime: '0',
                                endTime: '0',
                                status: 'passed'
                            }],
                        }
                        temp2 = {
                            feature: c.name,
                            expand: false,
                            scenario: [{
                                mName: paths[paths.length - 2],
                                specName: paths[paths.length - 1],
                                name: c.elements[0].name,
                                startTime: '0',
                                endTime: '0',
                                steps: [],
                                status: 'passed'
                            }],
                        }
                        for (let k = 0; k < c.elements[0].steps.length; k++) {
                            const step = {
                                startTime: "0",
                                endTime: "0",
                                stepName: c.elements[0].steps[k].name,
                                logs: [],
                                errorMessage: "",
                                failureStack: "",
                                screenshotPath: "",
                                screenShot: "",
                                status: c.elements[0].steps[k].result.status
                            }
                            const kw = c.elements[0].steps[k].keyword
                            if (kw === 'After' || kw === 'Before') {
                            } else {
                                temp2.scenario[0].steps.push(step);
                                recentStepNo = temp2.scenario[0].steps.length - 1;
                                const s = c.elements[0].steps[k].result.status
                                if (s === 'failed') {
                                    temp2.scenario[0].steps[recentStepNo].screenShot = c.elements[0].steps[c.elements[0].steps.length - 2]['embeddings'][0].data
                                    temp2.scenario[0].status = 'failed'
                                    tempD2.scenario[0].status = 'failed'
                                    temp2.scenario[0].steps[recentStepNo].failureStack = c.elements[0].steps[k].result.error_message
                                }
                            }
                        }
                        $scope.featuresInfo.push(temp2)
                        $scope.featuresInfoDynamic.push(tempD2)
                    }
                }

                let tc = {
                    mName: paths[paths.length - 2],
                    specName: paths[paths.length - 1],
                    tcName: c.elements[0].name,
                    startTime: '0',
                    endTime: '0',
                    steps: [],
                    status: 'passed'
                }

                for (let index = 0; index < c.elements[0].steps.length; index++) {
                    const ts = {
                        startTime: "0",
                        endTime: "0",
                        stepName: c.elements[0].steps[index].name,
                        logs: [],
                        errorMessage: "",
                        failureStack: "",
                        screenshotPath: "",
                        screenShot: "",
                        status: c.elements[0].steps[index].result.status
                    }
                    const kw = c.elements[0].steps[index].keyword
                    if (kw === 'After' || kw === 'Before') {

                    } else {
                        tc.steps.push(ts);
                        const s = c.elements[0].steps[index].result.status
                        if (s === 'failed') {
                            ts.screenShot = c.elements[0].steps[c.elements[0].steps.length - 2]['embeddings'][0].data
                            tc.status = 'failed'
                            ts.failureStack = c.elements[0].steps[index].result.error_message
                        }
                    }
                }
                content.data.push(tc);
            }


            $scope.projectName = content.projectName
            $scope.data = content.data
            $scope.moduleSelected = 'all'
            $scope.testCaseInfo = []
            $scope.passCount = 0
            $scope.failCount = 0
            $scope.skipCount = 0

            $scope.specsPassCount = 0
            $scope.specsFailCount = 0
            $scope.specsSkipCount = 0
            $scope.showExpandButtonFeature = true

            for (let i = 0; i < $scope.data.length; i++) {
                if ($scope.data[i].status === 'passed') {
                    $scope.passCount = $scope.passCount + 1;
                } else if ($scope.data[i].status === 'failed') {
                    $scope.failCount = $scope.failCount + 1;
                } else if ($scope.data[i].status === 'skipped') {
                    $scope.skipCount = $scope.skipCount + 1;
                }
                temp = {
                    tcName: $scope.data[i].tcName,
                    executionTime: $scope.data[i].executionTime,
                    status: $scope.data[i].status,
                }
                $scope.testCaseInfo.push(temp)

                for (let j = 0; j < $scope.data[i].steps.length; j++) {
                    if ($scope.data[i].steps[j].status === 'passed') {
                        $scope.specsPassCount = $scope.specsPassCount + 1;
                    } else if ($scope.data[i].steps[j].status === 'failed') {
                        $scope.specsFailCount = $scope.specsFailCount + 1;
                    } else if ($scope.data[i].steps[j].status === 'disabled') {
                        $scope.specsSkipCount = $scope.specsSkipCount + 1;
                    }
                }
            }
        })
    }

    $scope.moduleSelected = 'all'
    $scope.featuresInfo = []
    $scope.featuresInfoDynamic = []
    $scope.testCaseInfo = []
    $scope.testSteps = []
    $scope.passCount = 0
    $scope.failCount = 0
    $scope.skipCount = 0
    $scope.specsPassCount = 0
    $scope.specsFailCount = 0
    $scope.specsSkipCount = 0
    $scope.tcStartTime = 0
    $scope.tcEndTime = 0
    $scope.showDetails = true;

    $scope.toDetails = function () {
        $scope.showDetails = true;
    }

    $scope.toGraph = function () {
        var chartSc = new CanvasJS.Chart("chartScenario",
            {
                theme: "theme2",
                backgroundColor: "#c0c0c0",
                title: {
                    text: "Scenario resut " + $scope.moduleSelected
                },
                data: [
                    {
                        type: "pie",
                        showInLegend: true,
                        toolTipContent: "{y} - #percent %",
                        yValueFormatString: "{y}",
                        legendText: "{indexLabel}",
                        dataPoints: [
                            { y: $scope.passCount, indexLabel: "Passed", color: "#26b86280" },
                            { y: $scope.failCount, indexLabel: "Failed", color: "#d43c3c80" },
                            { y: $scope.skipCount, indexLabel: "Skipped", color: "#c2bf0a80" },
                        ]
                    }
                ]
            });
        chartSc.render();

        var chartSt = new CanvasJS.Chart("chartSteps",
            {
                theme: "theme2",
                backgroundColor: "#c0c0c0",
                title: {
                    text: "Over all steps resut"
                },
                data: [
                    {
                        type: "pie",
                        showInLegend: true,
                        toolTipContent: "{y} - #percent %",
                        yValueFormatString: "{y}",
                        legendText: "{indexLabel}",
                        dataPoints: [
                            { y: $scope.specsPassCount, indexLabel: "Passed", color: "#26b86280" },
                            { y: $scope.specsFailCount, indexLabel: "Failed", color: "#d43c3c80" },
                            { y: $scope.specsSkipCount, indexLabel: "Skipped", color: "#c2bf0a80" },
                        ]
                    }
                ]
            });
        chartSt.render();
        $scope.showDetails = false;
    }

    $scope.getModuleScenarios = function (module) {
        $scope.featuresInfoDynamic = []
        $scope.testSteps = []
        $scope.moduleSelected = module
        $scope.passCount = 0
        $scope.failCount = 0
        $scope.skipCount = 0
        $scope.tcStartTime = 0
        $scope.tcEndTime = 0
        for (const fi of $scope.featuresInfo) {
            for (let i = 0; i < fi.scenario.length; i++) {
                if (fi.scenario[i].mName === module) {
                    if ($scope.featuresInfoDynamic.length === 0) {
                        temp = {
                            feature: fi.feature,
                            scenario: [fi.scenario[i]]
                        }
                        if (fi.scenario[i].status === 'passed') {
                            $scope.passCount = $scope.passCount + 1;
                        } else if (fi.scenario[i].status === 'failed') {
                            $scope.failCount = $scope.failCount + 1;
                        } else if (fi.scenario[i].status === 'skipped') {
                            $scope.skipCount = $scope.skipCount + 1;
                        }
                        $scope.featuresInfoDynamic.push(temp)
                    } else {
                        let tFlag = false;
                        for (let j = 0; j < $scope.featuresInfoDynamic.length; j++) {
                            if ($scope.featuresInfoDynamic[j].feature === fi.feature) {
                                for (const sc of fi.scenario) {
                                    if (sc.mName === module) {
                                        for (const sc1 of $scope.featuresInfoDynamic[j].scenario) {
                                            if (sc1.name !== sc.name) {
                                                if (sc.status === 'passed') {
                                                    $scope.passCount = $scope.passCount + 1;
                                                } else if (sc.status === 'failed') {
                                                    $scope.failCount = $scope.failCount + 1;
                                                } else if (sc.status === 'skipped') {
                                                    $scope.skipCount = $scope.skipCount + 1;
                                                }
                                                $scope.featuresInfoDynamic[j].scenario.push(sc)
                                            }
                                        }
                                    }
                                }
                                tFlag = true;
                            }
                        }
                        if (!tFlag) {
                            temp1 = {
                                feature: fi.feature,
                                scenario: [fi.scenario[i]]
                            }
                            if (fi.scenario[i].status === 'passed') {
                                $scope.passCount = $scope.passCount + 1;
                            } else if (fi.scenario[i].status === 'failed') {
                                $scope.failCount = $scope.failCount + 1;
                            } else if (fi.scenario[i].status === 'skipped') {
                                $scope.skipCount = $scope.skipCount + 1;
                            }
                            $scope.featuresInfoDynamic.push(temp1)
                        }
                    }
                }
            }
        }
        console.log($scope.featuresInfoDynamic)
    }

    $scope.getScenariosByStatus = function (stat) {
        $scope.featuresInfoDynamic = []
        $scope.testSteps = []
        $scope.tcStartTime = 0
        $scope.tcEndTime = 0

        for (const fi of $scope.featuresInfo) {
            for (let i = 0; i < fi.scenario.length; i++) {
                if ($scope.moduleSelected === 'all') {
                    if (fi.scenario[i].status === stat) {
                        if ($scope.featuresInfoDynamic.length === 0) {
                            temp = {
                                feature: fi.feature,
                                scenario: [fi.scenario[i]]
                            }
                            $scope.featuresInfoDynamic.push(temp)
                        } else {
                            let tFlag = false;
                            for (let j = 0; j < $scope.featuresInfoDynamic.length; j++) {
                                if ($scope.featuresInfoDynamic[j].feature === fi.feature) {
                                    $scope.featuresInfoDynamic[j].scenario.push(fi.scenario[i])
                                    tFlag = true;
                                }
                            }
                            if (!tFlag) {
                                temp1 = {
                                    feature: fi.feature,
                                    scenario: [fi.scenario[i]]
                                }
                                $scope.featuresInfoDynamic.push(temp1)
                            }
                        }
                    }
                } else if (fi.scenario[i].mName === $scope.moduleSelected) {
                    if (fi.scenario[i].status === stat) {
                        if ($scope.featuresInfoDynamic.length === 0) {
                            temp = {
                                feature: fi.feature,
                                scenario: [fi.scenario[i]]
                            }
                            $scope.featuresInfoDynamic.push(temp)
                        } else {
                            let tFlag = false;
                            for (let j = 0; j < $scope.featuresInfoDynamic.length; j++) {
                                if ($scope.featuresInfoDynamic[j].feature === fi.feature) {
                                    $scope.featuresInfoDynamic[j].scenario.push(fi.scenario[i])
                                    tFlag = true;
                                }
                            }
                            if (!tFlag) {
                                temp1 = {
                                    feature: fi.feature,
                                    scenario: [fi.scenario[i]]
                                }
                                $scope.featuresInfoDynamic.push(temp1)
                            }
                        }
                    }
                }
            }
        }
    }

    $scope.getSteps = function (tc) {
        $scope.testSteps = []
        i: for (let i = 0; i < $scope.data.length; i++) {
            if ($scope.data[i].tcName === tc) {
                $scope.tcStartTime = $scope.data[i].startTime
                $scope.tcEndTime = $scope.data[i].endTime
                for (let j = 0; j < $scope.data[i].steps.length; j++) {
                    temp = {
                        expand: false,
                        showLogs: true,
                        showStack: false,
                        showSnap: false,
                        stepName: $scope.data[i].steps[j].stepName,
                        logs: $scope.data[i].steps[j].logs,
                        failureStack: $scope.data[i].steps[j].failureStack,
                        screenShot: $scope.data[i].steps[j].screenShot,
                        screenshotPath: $scope.data[i].steps[j].screenshotPath,
                        status: $scope.data[i].steps[j].status,
                    }
                    $scope.testSteps.push(temp)
                }
                break i;
            }
        }
        $scope.specsPassCount = 0;
        $scope.specsFailCount = 0;
        $scope.specsSkipCount = 0;
        for (const ts of $scope.testSteps) {
            if (ts.status === 'passed') {
                $scope.specsPassCount = $scope.specsPassCount + 1;
            } else if (ts.status === 'failed') {
                $scope.specsFailCount = $scope.specsFailCount + 1;
            } else if (ts.status === 'skipped') {
                $scope.specsSkipCount = $scope.specsSkipCount + 1;
            }
        }
    }

    $scope.expandOrCollapse = function (stepName) {
        for (let index = 0; index < $scope.testSteps.length; index++) {
            if ($scope.testSteps[index].stepName === stepName) {
                $scope.testSteps[index].showLogs = true
                $scope.testSteps[index].showStack = false
                $scope.testSteps[index].showSnap = false
                $scope.testSteps[index].expand = true
            } else {
                $scope.testSteps[index].expand = false
            }
        }
    }

    $scope.expandOrCollapseFeature = function (fn) {
        for (let i = 0; i < $scope.featuresInfoDynamic.length; i++) {
            if ($scope.featuresInfoDynamic[i].feature === fn) {
                $scope.featuresInfoDynamic[i].expand = true
            } else {
                $scope.featuresInfoDynamic[i].expand = false
            }
        }
    }


    $scope.expandAllFeature = function () {
        for (let i = 0; i < $scope.featuresInfoDynamic.length; i++) {
            $scope.featuresInfoDynamic[i].expand = true
            $scope.showExpandButtonFeature = false
        }
    }

    $scope.collapseAllFeature = function () {
        for (let i = 0; i < $scope.featuresInfoDynamic.length; i++) {
            $scope.featuresInfoDynamic[i].expand = false
            $scope.showExpandButtonFeature = true
        }
    }

    $scope.showLogs = function (stepName) {
        for (let index = 0; index < $scope.testSteps.length; index++) {
            if ($scope.testSteps[index].stepName === stepName) {
                $scope.testSteps[index].showStack = false
                $scope.testSteps[index].showSnap = false
                $scope.testSteps[index].showLogs = true
            }
        }
    }

    $scope.showStack = function (stepName) {
        for (let index = 0; index < $scope.testSteps.length; index++) {
            if ($scope.testSteps[index].stepName === stepName) {
                $scope.testSteps[index].showLogs = false
                $scope.testSteps[index].showSnap = false
                $scope.testSteps[index].showStack = true
            }
        }
    }

    $scope.showSnap = function (stepName) {
        for (let index = 0; index < $scope.testSteps.length; index++) {
            if ($scope.testSteps[index].stepName === stepName) {
                $scope.testSteps[index].showStack = false
                $scope.testSteps[index].showLogs = false
                $scope.testSteps[index].showSnap = true
            }
        }
    }

    $scope.loadFeed = function () {
        $scope.testCaseInfo = []
        $scope.passCount = 0
        $scope.failCount = 0
        $scope.skipCount = 0
        for (let i = 0; i < $scope.data.length; i++) {
            if ($scope.data[i].status === 'passed') {
                $scope.passCount = $scope.passCount + 1;
            } else if ($scope.data[i].status === 'failed') {
                $scope.failCount = $scope.failCount + 1;
            } else if ($scope.data[i].status === 'skipped') {
                $scope.skipCount = $scope.skipCount + 1;
            }
            temp = {
                tcName: $scope.data[i].tcName,
                executionTime: $scope.data[i].executionTime,
                status: $scope.data[i].status,
            }
            $scope.testCaseInfo.push(temp)
        }
    }

    $scope.showGraphOverview = function () {

        var diff = {
            Passed: 3,
            Failed: 2,
            Skipped: 1,

        };

        var chart = new CanvasJS.Chart(
            "chartContainer1",
            {
                title: {

                },
                animationEnabled: true,
                data: [{
                    type: "doughnut",
                    startAngle: 60,
                    toolTipContent: "{legendText}: {y} - <strong>#percent% </strong>",
                    showInLegend: false,
                    dataPoints: [{
                        y: diff.Passed,
                        legendText: "Passed",
                        color: "#97CC64"
                    }, {
                        y: diff.Failed,
                        legendText: "Failed",
                        color: "#FD5A3E"
                    }, {
                        y: diff.Skipped,
                        legendText: "Skipped",
                        color: "#d35ebe"
                    }
                    ]
                }]
            });
        chart.render();
    }
})

