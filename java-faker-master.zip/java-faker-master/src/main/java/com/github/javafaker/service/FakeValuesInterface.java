package com.github.javafaker.service;

import java.util.Map;

public interface FakeValuesInterface {
    Map get(String key);
}
