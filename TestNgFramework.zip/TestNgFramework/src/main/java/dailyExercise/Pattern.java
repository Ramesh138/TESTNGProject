package dailyExercise;

public class Pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count = 15;
		for (int i = 5; i > 0; i--) {
			
			count--;
			
			for (int j = count; j > 0; j--) {
				
				System.out.println("*");
				
			}
			
			System.out.println();
		}
		

	}

}
