package pages;

import wrappers.OpentapsWrappers;

public class QualifyLead  extends OpentapsWrappers{
	
	

	
}
